"""
Category 3: Data Structures & Sorting Tasks (19 to 26)
"""

CAT3_TASKS = [
    {
        "id": "ASM8086-SORT-WORDS-19",
        "folder": "19_quicksort_in_memory_words",
        "category": "category_03_data_structures_sorting",
        "title": "In-Place Sorting of 16-Bit Words in Real Mode Memory",
        "difficulty": "hard",
        "cycle_budget": 50000,
        "description": "Sort an array of 16-bit unsigned integers in-place in ascending order. The array begins at DS:0200h, with total number of words at DS:01FEh. Terminate with exit code 0 via DOS INT 21h.",
        "prompt": """# Task: In-Place Sorting of 16-Bit Words

## Problem Description
Sort an array of 16-bit unsigned integers in-place in ascending order.
- Array location: DS:0200h
- Element count: 16-bit word at DS:01FEh
Exit via INT 21h (AH=4Ch, AL=0).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FEh]
    cmp cx, 1
    jbe sort_done

    dec cx

outer_loop:
    push cx
    mov si, 0200h

inner_loop:
    mov ax, [si]
    mov bx, [si + 2]
    cmp ax, bx
    jbe no_swap
    mov [si], bx
    mov [si + 2], ax
no_swap:
    add si, 2
    loop inner_loop

    pop cx
    loop outer_loop

sort_done:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_reverse",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [5]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [500, 400, 300, 200, 100]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0200", "expected_words": [100, 200, 300, 400, 500]}
                    ],
                    "exit_code": 0
                }
            }
        ]
    },
    {
        "id": "ASM8086-BSEARCH-20",
        "folder": "20_binary_search_sorted_word_array",
        "category": "category_03_data_structures_sorting",
        "title": "Binary Search on Sorted Word Array",
        "difficulty": "easy",
        "cycle_budget": 8000,
        "description": "Perform binary search on a sorted array of 16-bit unsigned integers at DS:0200h (count N at DS:01FEh) for key at DS:01FCh. Return 0-based index in word at DS:02F0h (or 0xFFFF if not found).",
        "prompt": """# Task: Binary Search on Sorted Word Array

## Problem Description
Sorted word array at DS:0200h, count N at DS:01FEh, search key at DS:01FCh.
Perform binary search.
Store 0-based matching index into word DS:02F0h, or 0xFFFF if key is absent.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov dx, [01FCh]      ; Key
    mov cx, [01FEh]      ; N
    jcxz not_found

    xor si, si           ; low = 0
    mov di, cx
    dec di               ; high = N - 1

bsearch_loop:
    cmp si, di
    ja not_found

    ; mid = (low + high) / 2
    mov bx, si
    add bx, di
    shr bx, 1            ; BX = mid

    ; load array[mid]
    mov bp, bx
    shl bp, 1            ; byte offset = mid * 2
    mov ax, [0200h + bp]

    cmp ax, dx
    je found
    jb search_right

    ; search left: high = mid - 1
    cmp bx, 0
    je not_found
    mov di, bx
    dec di
    jmp bsearch_loop

search_right:
    ; search right: low = mid + 1
    mov si, bx
    inc si
    jmp bsearch_loop

found:
    mov [02F0h], bx
    jmp done_bsearch

not_found:
    mov word [02F0h], 0FFFFh

done_bsearch:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_present",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [42, 6]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [10, 20, 30, 42, 50, 60]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [3]}
                    ]
                }
            },
            {
                "id": "case_2_absent",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [99, 4]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [10, 20, 30, 40]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [0xFFFF]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-HEAP-INSERT-21",
        "folder": "21_priority_queue_min_heap_insert",
        "category": "category_03_data_structures_sorting",
        "title": "Min-Heap Insertion and Bubble-Up",
        "difficulty": "hard",
        "cycle_budget": 12000,
        "description": "Insert element word from DS:01FCh into 0-indexed binary min-heap array at DS:0200h of current size N (from DS:01FEh). Bubble up into valid min-heap order and increment N to N+1.",
        "prompt": """# Task: Priority Queue Min-Heap Insertion

## Problem Description
Binary min-heap stored at DS:0200h (array of 16-bit words, 0-indexed).
Current element count N is at DS:01FEh.
New element X is at DS:01FCh.
Insert X at index N, bubble it up so that heap[parent] <= heap[child] for all nodes (where parent = (child - 1) / 2).
Update count at DS:01FEh to N + 1.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; N (insertion index)
    mov dx, [01FCh]      ; X

    ; Write X at index N
    mov bx, cx
    shl bx, 1
    mov [0200h + bx], dx

    ; Bubble up: current = N
    mov si, cx

bubble_up:
    cmp si, 0
    jle heap_done

    ; parent = (current - 1) / 2
    mov di, si
    dec di
    shr di, 1

    ; Compare heap[current] with heap[parent]
    mov bx, di
    shl bx, 1
    mov ax, [0200h + bx] ; heap[parent]

    cmp dx, ax           ; compare X with heap[parent]
    jae heap_done        ; if X >= parent, heap property satisfied

    ; Swap heap[current] and heap[parent]
    mov bp, si
    shl bp, 1
    mov [0200h + bp], ax
    mov [0200h + bx], dx

    mov si, di           ; current = parent
    jmp bubble_up

heap_done:
    inc word [01FEh]     ; N = N + 1
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_insert_smallest",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # N = 3, X = 5
                        # heap: [10, 20, 30] -> after inserting 5 -> [5, 10, 30, 20]
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [5, 3]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [10, 20, 30]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [4]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [5, 10, 30, 20]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-LIST-REV-22",
        "folder": "22_linked_list_pointer_reversal",
        "category": "category_03_data_structures_sorting",
        "title": "In-Place Singly Linked List Reversal",
        "difficulty": "hard",
        "cycle_budget": 10000,
        "description": "Reverse a singly linked list in-place. Each node is [next_offset: word, data: word]. Head offset is at DS:01FEh (0000h = NULL). Store new head offset at DS:01FEh.",
        "prompt": """# Task: In-Place Singly Linked List Reversal

## Problem Description
Head offset of a singly linked list is at DS:01FEh.
Each node is 4 bytes:
- Word 0 (+0): Next node offset (or 0000h for NULL)
- Word 1 (+2): Data value
Reverse the list in-place (mutate the next pointers).
Write the new head node offset into DS:01FEh.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov bx, [01FEh]      ; curr = head
    xor dx, dx           ; prev = NULL

rev_loop:
    cmp bx, 0
    je done_rev

    mov si, [bx]         ; next = curr->next
    mov [bx], dx         ; curr->next = prev
    mov dx, bx           ; prev = curr
    mov bx, si           ; curr = next
    jmp rev_loop

done_rev:
    mov [01FEh], dx      ; head = prev
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_three_nodes",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Head at 0200h -> Node 1 at 0200h (next=0210h, val=10)
                        # Node 2 at 0210h (next=0220h, val=20)
                        # Node 3 at 0220h (next=0000h, val=30)
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [0x0200]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x0210, 10]},
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [0x0220, 20]},
                        {"segment": "0x2000", "offset": "0x0220", "data_words": [0x0000, 30]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # New head is 0220h
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [0x0220]},
                        # Node 3 points to Node 2 (0210h)
                        {"segment": "0x2000", "offset": "0x0220", "data_words": [0x0210]},
                        # Node 2 points to Node 1 (0200h)
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [0x0200]},
                        # Node 1 points to 0000h
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x0000]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-RING-BUF-23",
        "folder": "23_circular_ring_buffer_fifo",
        "category": "category_03_data_structures_sorting",
        "title": "Circular FIFO Ring Buffer Enqueue",
        "difficulty": "medium",
        "cycle_budget": 5000,
        "description": "Enqueue 16-bit word from DS:01FCh into circular FIFO buffer at DS:0200h. Buffer control block: [head: word, tail: word, capacity: word, count: word]. Data words follow at DS:0208h.",
        "prompt": """# Task: Circular FIFO Ring Buffer Enqueue

## Problem Description
Control block at DS:0200h:
- Word 0: Head index
- Word 1: Tail index
- Word 2: Capacity
- Word 3: Count
Data array starts at DS:0208h.
Word to enqueue is at DS:01FCh.
Store word at buffer[tail], update tail = (tail + 1) % capacity, and count = count + 1.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov dx, [01FCh]      ; Value to enqueue
    mov bx, [0202h]      ; Tail index
    mov cx, [0204h]      ; Capacity

    ; data[tail] = dx
    mov bp, bx
    shl bp, 1
    mov [0208h + bp], dx

    ; tail = (tail + 1) % capacity
    inc bx
    cmp bx, cx
    jb no_wrap
    xor bx, bx
no_wrap:
    mov [0202h], bx      ; Update tail

    ; count += 1
    inc word [0206h]

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_enqueue_wrap",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Value = 0xAAAA. Head=0, Tail=3, Capacity=4, Count=3
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [0xAAAA]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0, 3, 4, 3]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # Tail wraps to 0, Count=4, data[3]=0xAAAA
                        {"segment": "0x2000", "offset": "0x0202", "data_words": [0, 4, 4]},
                        {"segment": "0x2000", "offset": "0x020E", "data_words": [0xAAAA]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-PAREN-24",
        "folder": "24_balanced_parentheses_stack_check",
        "category": "category_03_data_structures_sorting",
        "title": "Balanced Parentheses Stack Verifier",
        "difficulty": "easy",
        "cycle_budget": 8000,
        "description": "Scan null-terminated ASCII string at DS:0200h for balanced parentheses (), [], {}. Store 01h at DS:02E0h (AX=1, ZF=1) if balanced, 00h (AX=0, ZF=0) if unbalanced. Use hardware stack.",
        "prompt": """# Task: Balanced Parentheses Stack Verifier

## Problem Description
Scan null-terminated string at DS:0200h containing brackets: (), [], {}.
Use the CPU stack to check for proper nesting and balance.
- If balanced: write 01h to byte DS:02E0h, AX = 1, ZF = 1.
- If unbalanced: write 00h to byte DS:02E0h, AX = 0, ZF = 0.
Exit via HLT.
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    hlt
""",
        "solution": """BITS 16
ORG 100h

start:
    mov bp, sp           ; Save original SP
    mov si, 0200h

scan_loop:
    mov al, [si]
    inc si
    cmp al, 0
    je end_string

    ; Check opening brackets
    cmp al, '('
    je push_bracket
    cmp al, '['
    je push_bracket
    cmp al, '{'
    je push_bracket

    ; Check closing brackets
    cmp al, ')'
    je pop_round
    cmp al, ']'
    je pop_square
    cmp al, '}'
    je pop_curly
    jmp scan_loop        ; Ignore other chars

push_bracket:
    xor ah, ah
    push ax
    jmp scan_loop

pop_round:
    cmp sp, bp
    je is_unbalanced
    pop dx
    cmp dl, '('
    jne is_unbalanced
    jmp scan_loop

pop_square:
    cmp sp, bp
    je is_unbalanced
    pop dx
    cmp dl, '['
    jne is_unbalanced
    jmp scan_loop

pop_curly:
    cmp sp, bp
    je is_unbalanced
    pop dx
    cmp dl, '{'
    jne is_unbalanced
    jmp scan_loop

end_string:
    cmp sp, bp
    jne is_unbalanced

is_balanced:
    mov sp, bp
    mov byte [02E0h], 1
    mov ax, 1
    xor bx, bx           ; ZF = 1
    hlt

is_unbalanced:
    mov sp, bp           ; Restore SP
    mov byte [02E0h], 0
    mov ax, 0
    or bl, 1             ; ZF = 0
    hlt
""",
        "test_cases": [
            {
                "id": "case_1_balanced",
                "initial_state": {
                    "registers": {"DS": "0x2000", "SS": "0x3000", "SP": "0xFFFE"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "{[()()]}\u0000"}
                    ]
                },
                "assertions": {
                    "registers": {"AX": "0x0001"},
                    "flags": {"ZF": 1},
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02E0", "expected_bytes": [1]}
                    ]
                }
            },
            {
                "id": "case_2_unbalanced",
                "initial_state": {
                    "registers": {"DS": "0x2000", "SS": "0x3000", "SP": "0xFFFE"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "([)]\u0000"}
                    ]
                },
                "assertions": {
                    "registers": {"AX": "0x0000"},
                    "flags": {"ZF": 0},
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02E0", "expected_bytes": [0]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-MERGE-25",
        "folder": "25_merge_two_sorted_word_arrays",
        "category": "category_03_data_structures_sorting",
        "title": "Merge Two Sorted Word Arrays",
        "difficulty": "medium",
        "cycle_budget": 12000,
        "description": "Merge sorted array A at DS:0200h (len N1 at DS:01FCh) and sorted array B at DS:0240h (len N2 at DS:01FEh) into sorted array at DS:0300h.",
        "prompt": """# Task: Merge Two Sorted Word Arrays

## Problem Description
Array A is at DS:0200h of length N1 (from DS:01FCh).
Array B is at DS:0240h of length N2 (from DS:01FEh).
Both arrays contain 16-bit unsigned integers in ascending order.
Merge them into DS:0300h in ascending order.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FCh]      ; N1
    mov dx, [01FEh]      ; N2
    mov si, 0200h        ; A
    mov di, 0240h        ; B
    mov bx, 0300h        ; Out

merge_loop:
    cmp cx, 0
    je copy_remaining_b
    cmp dx, 0
    je copy_remaining_a

    mov ax, [si]
    mov bp, [di]
    cmp ax, bp
    jbe take_a

take_b:
    mov [bx], bp
    add di, 2
    dec dx
    add bx, 2
    jmp merge_loop

take_a:
    mov [bx], ax
    add si, 2
    dec cx
    add bx, 2
    jmp merge_loop

copy_remaining_a:
    cmp cx, 0
    je done_merge
    mov ax, [si]
    mov [bx], ax
    add si, 2
    add bx, 2
    dec cx
    jmp copy_remaining_a

copy_remaining_b:
    cmp dx, 0
    je done_merge
    mov ax, [di]
    mov [bx], ax
    add di, 2
    add bx, 2
    dec dx
    jmp copy_remaining_b

done_merge:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_merge",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [3, 3]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [10, 30, 50]},
                        {"segment": "0x2000", "offset": "0x0240", "data_words": [20, 40, 60]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0300", "expected_words": [10, 20, 30, 40, 50, 60]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-BST-INORDER-26",
        "folder": "26_bst_inorder_traversal_dump",
        "category": "category_03_data_structures_sorting",
        "title": "Binary Search Tree Inorder Traversal Dump",
        "difficulty": "hard",
        "cycle_budget": 15000,
        "description": "Traverse BST in memory: node = [left_offset: word, right_offset: word, key: word]. Root offset is at DS:01FEh (0000h = NULL). Dump sorted keys into array at DS:0300h. Store count of keys at DS:02FEh.",
        "prompt": """# Task: Binary Search Tree Inorder Traversal Dump

## Problem Description
A binary search tree has root offset at DS:01FEh.
Each node is 6 bytes:
- Offset +0: Left child node offset (0000h = null)
- Offset +2: Right child node offset (0000h = null)
- Offset +4: 16-bit key value
Perform an in-order traversal (left, current, right) using the stack.
Dump keys into sequential words at DS:0300h.
Store total dumped key count at DS:02FEh.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov di, 0300h        ; Output buffer
    xor bp, bp           ; Count
    mov bx, [01FEh]      ; Curr = root
    xor dx, dx           ; Stack sentinel = 0
    push dx

traverse_loop:
    cmp bx, 0
    je pop_and_visit

    ; Push curr, move to curr->left
    push bx
    mov bx, [bx]         ; curr = curr->left
    jmp traverse_loop

pop_and_visit:
    pop bx
    cmp bx, 0
    je done_bst

    ; Visit curr: write curr->key to [di]
    mov ax, [bx + 4]
    mov [di], ax
    add di, 2
    inc bp

    ; curr = curr->right
    mov bx, [bx + 2]
    jmp traverse_loop

done_bst:
    mov [02FEh], bp
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_bst_3_nodes",
                "initial_state": {
                    "registers": {"DS": "0x2000", "SS": "0x3000", "SP": "0xFFFE"},
                    "memory_patches": [
                        # Root at 0200h (key 50, left=0210h, right=0220h)
                        # Left at 0210h (key 25, left=0, right=0)
                        # Right at 0220h (key 75, left=0, right=0)
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [0x0200]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x0210, 0x0220, 50]},
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [0, 0, 25]},
                        {"segment": "0x2000", "offset": "0x0220", "data_words": [0, 0, 75]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02FE", "data_words": [3]},
                        {"segment": "0x2000", "offset": "0x0300", "expected_words": [25, 50, 75]}
                    ]
                }
            }
        ]
    }
]
