"""
Category 6: Low-Level Systems & DOS Tasks (43 to 50)
"""

CAT6_TASKS = [
    {
        "id": "ASM8086-PSP-PARSE-43",
        "folder": "43_dos_psp_command_line_parser",
        "category": "category_06_low_level_systems_dos",
        "title": "DOS PSP Command Line Argument Parser",
        "difficulty": "medium",
        "cycle_budget": 12000,
        "description": "Parse DOS Program Segment Prefix (PSP) command tail at DS:0080h (len byte at 0080h, text at 0081h) into null-terminated token strings at DS:0200h. Store token count at DS:01FEh.",
        "prompt": """# Task: DOS PSP Command Line Argument Parser

## Problem Description
DOS PSP command tail is located at DS:0080h:
- Byte 0080h: Character length L (0..127)
- Bytes 0081h..: Command tail ASCII text
Parse the command line by splitting on spaces (ASCII 20h).
Copy each token as a null-terminated string sequentially into DS:0200h.
Store the total number of parsed tokens as a 16-bit word at DS:01FEh.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cl, [0080h]      ; Length of command tail
    xor ch, ch
    mov si, 0081h
    mov di, 0200h
    xor bp, bp           ; Token count
    jcxz done_parse

parse_loop:
    ; Skip spaces
    cmp cx, 0
    je done_parse
    mov al, [si]
    cmp al, ' '
    jne in_token
    inc si
    dec cx
    jmp parse_loop

in_token:
    ; Found start of a token!
    inc bp

copy_token:
    mov al, [si]
    inc si
    dec cx
    cmp al, ' '
    je end_token
    cmp al, 0Dh          ; Carriage return at end
    je end_token
    mov [di], al
    inc di
    cmp cx, 0
    jne copy_token

end_token:
    mov byte [di], 0     ; Null terminate token
    inc di
    cmp cx, 0
    jne parse_loop

done_parse:
    mov [01FEh], bp
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_two_args",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # " foo  bar\r" -> 10 chars
                        {"segment": "0x2000", "offset": "0x0080", "data_bytes": [10]},
                        {"segment": "0x2000", "offset": "0x0081", "data_ascii": " foo  bar\r"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [2]},
                        {"segment": "0x2000", "offset": "0x0200", "expected_ascii": "foo\u0000bar\u0000"}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-IVT-HOOK-44",
        "folder": "44_interrupt_vector_hook_trap",
        "category": "category_06_low_level_systems_dos",
        "title": "Interrupt Vector Table (IVT) Hooking",
        "difficulty": "hard",
        "cycle_budget": 5000,
        "description": "Hook interrupt vector AL (from DS:01FDh). Save old ISR pointer (offset, segment) to DS:0200h, and write new ISR pointer [offset at DS:01FAh, segment at DS:01F8h] into IVT at 0000h:(AL*4).",
        "prompt": """# Task: Interrupt Vector Table Hooking

## Problem Description
Read target vector number (0..255) from byte DS:01FDh.
Read new ISR address: offset at word DS:01FAh, segment at word DS:01F8h.
The Real Mode IVT begins at 0000:0000h (each entry is 4 bytes: word offset, word segment).
1. Read existing IVT entry for vector and write it to DS:0200h (offset at 0200h, segment at 0202h).
2. Install new ISR pointer into the IVT table at 0000:(vector*4).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov al, [01FDh]      ; Vector
    xor ah, ah
    shl ax, 2            ; Vector * 4 (offset in segment 0000h)
    mov bx, ax

    ; Read old IVT entry from 0000h:BX
    push ds
    xor ax, ax
    mov ds, ax
    mov si, [bx]         ; Old offset
    mov di, [bx + 2]     ; Old segment
    pop ds

    ; Save old ISR to DS:0200h
    mov [0200h], si
    mov [0202h], di

    ; Load new ISR
    mov si, [01FAh]      ; New offset
    mov di, [01F8h]      ; New segment

    ; Write new ISR into 0000h:BX
    push ds
    xor ax, ax
    mov ds, ax
    mov [bx], si
    mov [bx + 2], di
    pop ds

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_hook_int1c",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Vector 1Ch (offset 0000:0070h)
                        {"segment": "0x0000", "offset": "0x0070", "data_words": [0x1234, 0xF000]},
                        # New ISR = 0x2000:0x0500, Vector = 0x1C
                        {"segment": "0x2000", "offset": "0x01F8", "data_words": [0x2000, 0x0500]},
                        {"segment": "0x2000", "offset": "0x01FD", "data_bytes": [0x1C]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # Old saved to DS:0200h
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x1234, 0xF000]},
                        # New written to IVT at 0000:0070h
                        {"segment": "0x0000", "offset": "0x0070", "data_words": [0x0500, 0x2000]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-CORO-SW-45",
        "folder": "45_realmode_cooperative_task_switcher",
        "category": "category_06_low_level_systems_dos",
        "title": "Cooperative Coroutine Stack Switcher",
        "difficulty": "very hard",
        "cycle_budget": 5000,
        "description": "Simulate coroutine context switch: save active SP and BP to DS:0200h [SP: word, BP: word], load new task SP and BP from DS:0204h [SP: word, BP: word].",
        "prompt": """# Task: Cooperative Coroutine Stack Switcher

## Problem Description
Save current task's context (SP and BP) into DS:0200h (SP at 0200h, BP at 0202h).
Load next task's context from DS:0204h (new SP from 0204h, new BP from 0206h).
After loading the new stack pointers, write 0xCAFE to the top of the new stack ([SS:SP]).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    ; Save active SP and BP
    mov [0200h], sp
    mov [0202h], bp

    ; Load new SP and BP
    mov sp, [0204h]
    mov bp, [0206h]

    ; Push 0xCAFE to new stack
    mov ax, 0CAFEh
    push ax

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_switch",
                "initial_state": {
                    "registers": {"DS": "0x2000", "SS": "0x3000", "SP": "0xFFFE", "BP": "0x1234"},
                    "memory_patches": [
                        # Target task has SP = 0x8000, BP = 0x8050
                        {"segment": "0x2000", "offset": "0x0204", "data_words": [0x8000, 0x8050]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # Saved old SP=0xFFFE, BP=0x1234
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0xFFFE, 0x1234]},
                        # New stack at 3000:7FFE has 0xCAFE
                        {"segment": "0x3000", "offset": "0x7FFE", "data_words": [0xCAFE]}
                    ],
                    "registers": {
                        "SP": "0x7FFE",
                        "BP": "0x8050"
                    }
                }
            }
        ]
    },
    {
        "id": "ASM8086-LBA-CHS-46",
        "folder": "46_bios_raw_disk_lba_to_chs_calc",
        "category": "category_06_low_level_systems_dos",
        "title": "Disk LBA to Cylinder/Head/Sector (CHS) Converter",
        "difficulty": "medium",
        "cycle_budget": 5000,
        "description": "Convert 32-bit LBA sector at DS:0200h (low word at 0200h, high word at 0202h) to CHS geometry using Sectors-Per-Track (SPT at DS:0204h) and Heads-Per-Cylinder (HPC at DS:0206h). Store Cylinder (word) at DS:0210h, Head (byte) at DS:0212h, Sector (byte) at DS:0213h.",
        "prompt": """# Task: Disk LBA to CHS Converter

## Problem Description
Convert 32-bit LBA at DS:0200h to CHS:
- LBA: low word at DS:0200h, high word at DS:0202h
- SPT (Sectors Per Track): word at DS:0204h
- HPC (Heads Per Cylinder): word at DS:0206h
Formulas:
- Sector S = (LBA % SPT) + 1
- Temp = LBA / SPT
- Head H = Temp % HPC
- Cylinder C = Temp / HPC
Store:
- Cylinder (16-bit word) at DS:0210h
- Head (8-bit byte) at DS:0212h
- Sector (8-bit byte) at DS:0213h
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    ; 1. LBA / SPT -> Quotient in AX, Remainder in DX
    mov ax, [0200h]      ; LBA low
    mov dx, [0202h]      ; LBA high
    mov bx, [0204h]      ; SPT
    div bx

    ; Sector = remainder + 1
    inc dl
    mov [0213h], dl      ; Save Sector byte

    ; 2. Temp (AX) / HPC -> Quotient in AX (Cylinder), Remainder in DX (Head)
    xor dx, dx
    mov bx, [0206h]      ; HPC
    div bx

    mov [0210h], ax      ; Save Cylinder word
    mov [0212h], dl      ; Save Head byte

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_lba_1000",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # LBA = 1000 (0x03E8, 0x0000), SPT = 63, HPC = 16
                        # 1000 % 63 = 55 -> S = 56
                        # Temp = 1000 / 63 = 15
                        # Head = 15 % 16 = 15
                        # Cylinder = 15 / 16 = 0
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [1000, 0, 63, 16]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [0]},
                        {"segment": "0x2000", "offset": "0x0212", "data_bytes": [15, 56]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-XMS-MOVE-47",
        "folder": "47_simulated_xms_block_transfer",
        "category": "category_06_low_level_systems_dos",
        "title": "Cross-Segment Block Transfer",
        "difficulty": "hard",
        "cycle_budget": 15000,
        "description": "Copy memory block specified by descriptor table at DS:0200h: [count_bytes: word, src_seg: word, src_off: word, dst_seg: word, dst_off: word].",
        "prompt": """# Task: Cross-Segment Block Transfer

## Problem Description
Descriptor table at DS:0200h (five 16-bit words):
- +0: Byte count CX
- +2: Source segment
- +4: Source offset
- +6: Destination segment
- +8: Destination offset
Copy CX bytes from Source Segment:Offset to Destination Segment:Offset.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [0200h]      ; Byte count
    mov ax, [0202h]      ; src_seg
    mov si, [0204h]      ; src_off
    mov dx, [0206h]      ; dst_seg
    mov di, [0208h]      ; dst_off

    mov ds, ax
    mov es, dx
    cld
    rep movsb

    ; Restore DS to 2000h before exit
    mov ax, 2000h
    mov ds, ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_transfer",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Count=4, src=0x2000:0x0300, dst=0x3000:0x0400
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [4, 0x2000, 0x0300, 0x3000, 0x0400]},
                        {"segment": "0x2000", "offset": "0x0300", "data_ascii": "XMS!"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x3000", "offset": "0x0400", "data_ascii": "XMS!"}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-UART-TX-48",
        "folder": "48_software_uart_simulated_tx_rx",
        "category": "category_06_low_level_systems_dos",
        "title": "Software UART 10-Bit Frame Generator",
        "difficulty": "hard",
        "cycle_budget": 5000,
        "description": "Encode 8-bit byte at DS:0200h into 10-bit serial frame (1 start bit = 0, 8 data bits LSB first, 1 stop bit = 1). Store 10 output bytes (each 0 or 1) at DS:0210h.",
        "prompt": """# Task: Software UART 10-Bit Frame Generator

## Problem Description
Load byte to transmit from DS:0200h.
Generate standard 10-bit asynchronous serial frame:
- Bit 0: Start bit = 0
- Bits 1..8: 8 data bits (LSB first)
- Bit 9: Stop bit = 1
Write each of the 10 bits as individual bytes (00h or 01h) sequentially to DS:0210h..DS:0219h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov al, [0200h]      ; Data byte
    mov di, 0210h

    ; 1. Start bit = 0
    mov byte [di], 0
    inc di

    ; 2. 8 data bits (LSB first)
    mov cx, 8
bit_loop:
    mov bl, al
    and bl, 1
    mov [di], bl
    inc di
    shr al, 1
    loop bit_loop

    ; 3. Stop bit = 1
    mov byte [di], 1

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_char_a",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 'A' = 0x41 = 0100 0001b
                        # Frame: Start(0), 1, 0, 0, 0, 0, 0, 1, 0, Stop(1)
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [0x41]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0210", "data_bytes": [0, 1, 0, 0, 0, 0, 0, 1, 0, 1]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-RAM-DIAG-49",
        "folder": "49_parity_memory_diagnostic_scanner",
        "category": "category_06_low_level_systems_dos",
        "title": "RAM Alternating Pattern Diagnostic Scanner",
        "difficulty": "medium",
        "cycle_budget": 15000,
        "description": "Perform memory diagnostic on N words at DS:0300h (N at DS:01FEh). Test pattern 55AAh then AA55h, restoring 0000h. Store 0001h at DS:02F0h if passed, 0000h if fault detected.",
        "prompt": """# Task: RAM Alternating Pattern Diagnostic Scanner

## Problem Description
Memory test region is at DS:0300h of length N words (from DS:01FEh).
For each word:
1. Write 55AAh and verify immediately. If mismatch -> fail.
2. Write AA55h and verify immediately. If mismatch -> fail.
3. Write 0000h to clean up.
If all words pass, write 0001h to DS:02F0h (AX=1).
If any word fails, write 0000h to DS:02F0h (AX=0).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; N
    mov si, 0300h
    jcxz pass_diag

diag_loop:
    ; Pattern 1: 55AAh
    mov word [si], 55AAh
    cmp word [si], 55AAh
    jne fail_diag

    ; Pattern 2: AA55h
    mov word [si], 0AA55h
    cmp word [si], 0AA55h
    jne fail_diag

    ; Clean up
    mov word [si], 0000h

    add si, 2
    loop diag_loop

pass_diag:
    mov word [02F0h], 1
    mov ax, 4C00h
    int 21h

fail_diag:
    mov word [02F0h], 0
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_pass_4_words",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [4]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [1]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-RELOC-50",
        "folder": "50_executable_relocator_table_patcher",
        "category": "category_06_low_level_systems_dos",
        "title": "DOS MZ Executable Relocation Table Fixup Patcher",
        "difficulty": "very hard",
        "cycle_budget": 15000,
        "description": "Apply DOS relocation fixups: relocation table at DS:0200h contains N entries (count at DS:01FCh). Each entry is [target_offset: word, target_seg_delta: word]. Add relocation delta DX (from DS:01FEh) to word at (DS + target_seg_delta):target_offset.",
        "prompt": """# Task: DOS MZ Executable Relocation Table Fixup Patcher

## Problem Description
Relocation table starts at DS:0200h with N entries (word at DS:01FCh).
Base segment delta DX is at DS:01FEh.
Each relocation entry is 4 bytes:
- Word 0 (+0): Offset of word to fix up
- Word 1 (+2): Segment offset relative to DS
For each relocation entry:
  Fixup physical location is segment (DS + target_seg_delta), offset target_offset.
  Add delta DX to the 16-bit word at that location.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FCh]      ; N entries
    mov dx, [01FEh]      ; Delta
    mov si, 0200h        ; Reloc table
    jcxz done_reloc

reloc_loop:
    mov di, [si]         ; Target offset
    mov ax, [si + 2]     ; Target segment delta
    add si, 4

    ; Calculate target segment = DS + AX
    mov bx, ds
    add ax, bx
    mov es, ax

    ; Apply fixup: ES:[DI] += DX
    mov ax, es:[di]
    add ax, dx
    mov es:[di], ax

    loop reloc_loop

done_reloc:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_two_fixups",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # N = 2, Delta = 0x1000
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [2, 0x1000]},
                        # Entry 1: offset 0x0100, seg_delta 0x0000 -> target 0x2000:0x0100
                        # Entry 2: offset 0x0200, seg_delta 0x0100 -> target 0x2100:0x0200
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x0100, 0x0000, 0x0200, 0x0100]},
                        # Target words to be relocated
                        {"segment": "0x2000", "offset": "0x0100", "data_words": [0x0020]},
                        {"segment": "0x2100", "offset": "0x0200", "data_words": [0x0040]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # Relocated: 0x0020 + 0x1000 = 0x1020
                        {"segment": "0x2000", "offset": "0x0100", "data_words": [0x1020]},
                        # Relocated: 0x0040 + 0x1000 = 0x1040
                        {"segment": "0x2100", "offset": "0x0200", "data_words": [0x1040]}
                    ]
                }
            }
        ]
    }
]
