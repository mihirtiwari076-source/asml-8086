"""
Category 2: Memory & Strings Tasks (09 to 18)
"""

CAT2_TASKS = [
    {
        "id": "ASM8086-REV-STR-09",
        "folder": "09_inplace_string_reverse",
        "category": "category_02_memory_and_strings",
        "title": "In-Place String Reversal in Real Mode Memory",
        "difficulty": "easy",
        "cycle_budget": 15000,
        "description": "Reverse a null-terminated ASCII string starting at DS:0200h in-place. The null-terminator must remain at the exact same ending offset. Terminate with ZF = 1.",
        "prompt": """# Task: In-Place String Reversal in Real Mode Memory

## Problem Description
Reverse a null-terminated ASCII string starting at DS:0200h in-place.
The null terminator (00h) must remain at its ending position.
Ensure ZF = 1 upon completion.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov si, 0200h
    mov di, si

find_end:
    cmp byte [di], 0
    je found_end
    inc di
    jmp find_end

found_end:
    cmp di, si
    jbe done_reverse
    dec di

reverse_loop:
    cmp si, di
    jae done_reverse
    mov al, [si]
    mov bl, [di]
    mov [si], bl
    mov [di], al
    inc si
    dec di
    jmp reverse_loop

done_reverse:
    xor cx, cx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_antigravity",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "Antigravity8086\u0000"}
                    ]
                },
                "assertions": {
                    "flags": {"ZF": 1},
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0200", "expected_ascii": "6808ytivargitnA\u0000"}
                    ]
                }
            },
            {
                "id": "case_2_even",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "HELLO!\u0000"}
                    ]
                },
                "assertions": {
                    "flags": {"ZF": 1},
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0200", "expected_ascii": "!OLLEH\u0000"}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-MEMMOVE-10",
        "folder": "10_memory_block_move_overlap_safe",
        "category": "category_02_memory_and_strings",
        "title": "Overlap-Safe Memory Block Transfer",
        "difficulty": "hard",
        "cycle_budget": 15000,
        "description": "Copy CX bytes from DS:SI to ES:DI safely even when source and destination buffers overlap. SI is at DS:01FEh, DI is at DS:01FCh, CX is at DS:01FAh.",
        "prompt": """# Task: Overlap-Safe Memory Block Transfer (Memmove)

## Problem Description
Source offset SI is at DS:01FEh, destination offset DI is at DS:01FCh, byte count CX is at DS:01FAh.
Copy CX bytes from DS:SI to ES:DI.
If DI > SI and DI < SI + CX, perform backward copy (STD).
Else perform forward copy (CLD).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov si, [01FEh]
    mov di, [01FCh]
    mov cx, [01FAh]
    jcxz done_move

    cmp di, si
    jbe forward_copy

    mov ax, si
    add ax, cx
    cmp di, ax
    jae forward_copy

backward_copy:
    add si, cx
    dec si
    add di, cx
    dec di
    std
    rep movsb
    cld
    jmp done_move

forward_copy:
    cld
    rep movsb

done_move:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_overlapping_backward",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FA", "data_words": [8, 0x0204, 0x0200]},
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [1, 2, 3, 4, 5, 6, 7, 8]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0204", "data_bytes": [1, 2, 3, 4, 5, 6, 7, 8]}
                    ]
                }
            },
            {
                "id": "case_2_non_overlapping_forward",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FA", "data_words": [5, 0x0300, 0x0200]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "ABCDE"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0300", "data_ascii": "ABCDE"}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-TOKEN-COUNT-11",
        "folder": "11_string_token_count_scasb",
        "category": "category_02_memory_and_strings",
        "title": "String Token Counting via SCASB",
        "difficulty": "medium",
        "cycle_budget": 10000,
        "description": "Count the number of tokens separated by delimiter AL (at DS:01FDh) in string at ES:0200h of length CX (at DS:01FEh). Write token count to word at DS:02E0h.",
        "prompt": """# Task: String Token Counting via SCASB

## Problem Description
Buffer at ES:0200h of length CX (from DS:01FEh).
Delimiter byte in AL from DS:01FDh.
Count non-empty tokens separated by the delimiter.
Store the token count as a 16-bit word at DS:02E0h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    cld
    mov di, 0200h
    mov cx, [01FEh]
    mov al, [01FDh]
    xor dx, dx           ; Token count
    xor bx, bx           ; In-token flag (0 = outside, 1 = inside)
    jcxz save_count

scan_loop:
    mov ah, es:[di]
    inc di
    cmp ah, al
    je is_delim

    ; In token
    cmp bx, 0
    jne continue_scan
    inc dx               ; New token started
    mov bx, 1
    jmp continue_scan

is_delim:
    mov bx, 0            ; Left token

continue_scan:
    loop scan_loop

save_count:
    mov [02E0h], dx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_three_words",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        # Delimiter ' ' (0x20) at 01FDh, len 15 at 01FEh
                        {"segment": "0x2000", "offset": "0x01FD", "data_bytes": [0x20, 15, 0]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "foo  bar   baz "}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02E0", "data_words": [3]}
                    ]
                }
            },
            {
                "id": "case_2_commas",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        # Delimiter ',' (0x2C), len 11
                        {"segment": "0x2000", "offset": "0x01FD", "data_bytes": [0x2C, 11, 0]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "a,b,c,d,e,f"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02E0", "data_words": [6]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-WHITESPACE-12",
        "folder": "12_whitespace_compression_in_place",
        "category": "category_02_memory_and_strings",
        "title": "In-Place Whitespace Compression",
        "difficulty": "medium",
        "cycle_budget": 12000,
        "description": "Compress multiple consecutive spaces (ASCII 20h) into a single space in a null-terminated string at DS:0200h in-place. The string must remain null-terminated.",
        "prompt": """# Task: In-Place Whitespace Compression

## Problem Description
Compress runs of consecutive spaces (' ', 20h) into a single space in the null-terminated string starting at DS:0200h.
The compressed string must be written in-place and terminated with 00h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    cld
    mov si, 0200h
    mov di, si
    xor bl, bl           ; Space seen flag (0 = false, 1 = true)

compress_loop:
    lodsb
    cmp al, 0
    je finish_compress

    cmp al, 20h
    jne not_space

    ; Char is space
    cmp bl, 1
    je skip_char         ; Duplicate space, do not copy
    stosb
    mov bl, 1
    jmp compress_loop

not_space:
    stosb
    mov bl, 0
    jmp compress_loop

skip_char:
    jmp compress_loop

finish_compress:
    stosb                ; Write null terminator
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_multi_spaces",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "Hello   world   from   8086!\u0000"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0200", "expected_ascii": "Hello world from 8086!\u0000"}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-STRCMP-13",
        "folder": "13_case_insensitive_strcmp",
        "category": "category_02_memory_and_strings",
        "title": "Case-Insensitive String Comparison",
        "difficulty": "easy",
        "cycle_budget": 8000,
        "description": "Compare two null-terminated ASCII strings at DS:0200h and DS:0250h ignoring letter casing. Set AX = 0 (ZF=1) if equal, AX = 1 if Str1 > Str2, AX = 0xFFFF if Str1 < Str2.",
        "prompt": """# Task: Case-Insensitive String Comparison

## Problem Description
Compare String 1 at DS:0200h and String 2 at DS:0250h (both null-terminated).
Convert lowercase characters ('a'-'z') to uppercase before comparing.
- If equal: AX = 0, ZF = 1
- If Str1 > Str2: AX = 1, ZF = 0
- If Str1 < Str2: AX = 0xFFFF, ZF = 0
Store result word into DS:02F0h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov si, 0200h
    mov di, 0250h

compare_loop:
    mov al, [si]
    mov bl, [di]
    inc si
    inc di

    ; Convert al to uppercase
    cmp al, 'a'
    jb check_bl
    cmp al, 'z'
    ja check_bl
    sub al, 32

check_bl:
    cmp bl, 'a'
    jb do_compare
    cmp bl, 'z'
    ja do_compare
    sub bl, 32

do_compare:
    cmp al, bl
    jb str1_less
    ja str1_greater
    cmp al, 0
    je strings_equal
    jmp compare_loop

strings_equal:
    xor ax, ax           ; AX = 0, ZF = 1
    jmp done_cmp

str1_less:
    mov ax, 0FFFFh
    or al, 1             ; ZF = 0
    mov ax, 0FFFFh
    jmp done_cmp

str1_greater:
    mov ax, 1
    or al, 1             ; ZF = 0
    mov ax, 1

done_cmp:
    mov [02F0h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_equal_ignore_case",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "Antigravity\u0000"},
                        {"segment": "0x2000", "offset": "0x0250", "data_ascii": "ANTIGRAVITY\u0000"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [0]}
                    ]
                }
            },
            {
                "id": "case_2_greater",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "beta\u0000"},
                        {"segment": "0x2000", "offset": "0x0250", "data_ascii": "Alpha\u0000"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [1]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-SUBSEARCH-14",
        "folder": "14_boyer_moore_horspool_subsearch",
        "category": "category_02_memory_and_strings",
        "title": "Substring Search in Memory Buffer",
        "difficulty": "very hard",
        "cycle_budget": 20000,
        "description": "Find the first occurrence of needle pattern at DS:0280h (len at DS:01FEh) within haystack at DS:0200h (len at DS:01FCh). Write 0-based index to DS:02F0h, or FFFFh if not found.",
        "prompt": """# Task: Substring Search in Memory Buffer

## Problem Description
Haystack is at DS:0200h with length at DS:01FCh.
Needle is at DS:0280h with length at DS:01FEh.
Find the first 0-based offset of Needle in Haystack.
Store the 16-bit offset into DS:02F0h (or 0xFFFF if not found).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FCh]      ; Haystack len
    mov dx, [01FEh]      ; Needle len
    cmp dx, cx
    ja not_found
    cmp dx, 0
    je not_found

    ; Max index = Haystack len - Needle len
    mov bp, cx
    sub bp, dx           ; BP = max index

    xor bx, bx           ; i = 0

outer_scan:
    cmp bx, bp
    ja not_found

    ; Compare needle with haystack at i
    push bx
    mov si, 0280h        ; Needle
    mov di, 0200h
    add di, bx           ; Haystack + i
    mov cx, dx           ; compare len bytes
    cld

inner_cmp:
    mov al, [si]
    mov ah, [di]
    inc si
    inc di
    cmp al, ah
    jne mismatch
    loop inner_cmp

    ; Match found!
    pop bx
    mov [02F0h], bx
    jmp finish_search

mismatch:
    pop bx
    inc bx
    jmp outer_scan

not_found:
    mov word [02F0h], 0FFFFh

finish_search:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_match",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [14, 4]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "ABCDEF8086XYZW"},
                        {"segment": "0x2000", "offset": "0x0280", "data_ascii": "8086"}
                    ]
                },
                "assertions": {
                    "memory": [
                        # "8086" starts at index 6
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [6]}
                    ]
                }
            },
            {
                "id": "case_2_no_match",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [10, 3]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "ABCDEFGHIJ"},
                        {"segment": "0x2000", "offset": "0x0280", "data_ascii": "XYZ"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [0xFFFF]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-RLE-ENC-15",
        "folder": "15_run_length_encoding_compress",
        "category": "category_02_memory_and_strings",
        "title": "Run-Length Encoding (RLE) Compression",
        "difficulty": "medium",
        "cycle_budget": 12000,
        "description": "Compress byte stream at DS:0200h (len at DS:01FEh) into [count: byte, value: byte] packets at DS:0300h. Write total compressed byte length to word at DS:02FEh.",
        "prompt": """# Task: Run-Length Encoding Compression

## Problem Description
Input byte buffer at DS:0200h of length CX (from DS:01FEh).
Compress contiguous runs of identical bytes into [count: byte, value: byte] pairs at DS:0300h (maximum run count 255).
Store total compressed size in bytes at word DS:02FEh.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; Input len
    mov si, 0200h        ; Input pointer
    mov di, 0300h        ; Output pointer
    xor bp, bp           ; Compressed size
    jcxz done_rle

rle_outer:
    mov al, [si]         ; Current byte
    mov bl, 1            ; Count = 1
    inc si
    dec cx
    jcxz write_packet

count_run:
    cmp [si], al
    jne write_packet
    cmp bl, 255
    je write_packet
    inc bl
    inc si
    loop count_run

write_packet:
    mov [di], bl
    mov [di+1], al
    add di, 2
    add bp, 2
    cmp cx, 0
    jne rle_outer

done_rle:
    mov [02FEh], bp
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_runs",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [8]},
                        # AAAA BBB C -> 4 'A', 3 'B', 1 'C'
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [0x41, 0x41, 0x41, 0x41, 0x42, 0x42, 0x42, 0x43]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02FE", "data_words": [6]},
                        {"segment": "0x2000", "offset": "0x0300", "data_bytes": [4, 0x41, 3, 0x42, 1, 0x43]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-RLE-DEC-16",
        "folder": "16_run_length_decoding_decompress",
        "category": "category_02_memory_and_strings",
        "title": "Run-Length Decoding (RLE) Decompress",
        "difficulty": "medium",
        "cycle_budget": 12000,
        "description": "Decompress [count: byte, value: byte] packets from DS:0200h (len bytes at DS:01FEh) into output buffer at DS:0300h. Write total decompressed byte count to word at DS:02FEh.",
        "prompt": """# Task: Run-Length Decoding Decompress

## Problem Description
Input is an array of [count: byte, value: byte] pairs at DS:0200h. Total input length in bytes is at DS:01FEh.
Decompress by repeating each byte according to count, writing output stream to DS:0300h.
Write total decompressed length (words) to DS:02FEh.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; Compressed bytes count
    mov si, 0200h
    mov di, 0300h
    xor bp, bp           ; Decompressed count
    jcxz done_dec

dec_loop:
    mov bl, [si]         ; Count
    mov al, [si+1]       ; Byte
    add si, 2
    sub cx, 2

expand_run:
    cmp bl, 0
    je next_packet
    mov [di], al
    inc di
    inc bp
    dec bl
    jmp expand_run

next_packet:
    cmp cx, 0
    jne dec_loop

done_dec:
    mov [02FEh], bp
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_decompress",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [6]},
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [4, 0x41, 3, 0x42, 1, 0x43]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02FE", "data_words": [8]},
                        {"segment": "0x2000", "offset": "0x0300", "data_bytes": [0x41, 0x41, 0x41, 0x41, 0x42, 0x42, 0x42, 0x43]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-LEVENSHTEIN-17",
        "folder": "17_zero_terminated_levenshtein_distance",
        "category": "category_02_memory_and_strings",
        "title": "Levenshtein Edit Distance Matrix",
        "difficulty": "very hard",
        "cycle_budget": 25000,
        "description": "Compute the Levenshtein distance between two short strings at DS:0200h (len M at DS:01FCh) and DS:0220h (len N at DS:01FEh). Store result word at DS:02F0h.",
        "prompt": """# Task: Levenshtein Edit Distance Matrix

## Problem Description
String 1 is at DS:0200h with length M at DS:01FCh.
String 2 is at DS:0220h with length N at DS:01FEh.
Compute minimum edit distance (insert, delete, replace).
Store the distance as a 16-bit word at DS:02F0h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

; DP Table located at DS:0300h
; Row 0 initialized to 0, 1, 2, ... N
start:
    mov cx, [01FCh]      ; M (rows)
    mov dx, [01FEh]      ; N (cols)

    ; Initialize DP row 0: dp[0][j] = j
    mov di, 0300h
    xor ax, ax           ; j = 0
init_r0:
    mov [di], al
    inc di
    inc ax
    cmp ax, dx
    jbe init_r0

    ; For i = 1 to M:
    mov bp, 1            ; i = 1
outer_dp:
    cmp bp, cx
    ja done_dp

    ; Compute row i in buffer at 0320h
    mov di, 0320h
    mov ax, bp
    mov [di], al         ; dp[i][0] = i
    inc di

    ; j = 1 to N
    mov bx, 1            ; j = 1
inner_dp:
    cmp bx, dx
    ja copy_row

    ; cost = (s1[i-1] == s2[j-1]) ? 0 : 1
    mov si, 0200h
    add si, bp
    dec si
    mov al, [si]         ; s1[i-1]

    mov si, 0220h
    add si, bx
    dec si
    mov ah, [si]         ; s2[j-1]

    xor dl, dl
    cmp al, ah
    je no_sub_cost
    mov dl, 1            ; cost = 1
no_sub_cost:

    ; del_cost = prev_row[j] + 1
    mov si, 0300h
    add si, bx
    mov al, [si]
    inc al

    ; ins_cost = cur_row[j-1] + 1
    mov si, di
    dec si
    mov ah, [si]
    inc ah

    ; min(del_cost, ins_cost) in AL
    cmp ah, al
    jae not_ins_min
    mov al, ah
not_ins_min:

    ; sub_cost = prev_row[j-1] + cost
    mov si, 0300h
    add si, bx
    dec si
    mov ah, [si]
    add ah, dl

    ; min with sub_cost
    cmp ah, al
    jae not_sub_min
    mov al, ah
not_sub_min:

    mov [di], al
    inc di
    inc bx
    mov dx, [01FEh]      ; Restore N
    jmp inner_dp

copy_row:
    ; Copy 0320h to 0300h for next iteration
    push cx
    mov si, 0320h
    mov di, 0300h
    mov cx, dx
    inc cx
    cld
    rep movsb
    pop cx

    inc bp
    jmp outer_dp

done_dp:
    ; Result is at 0300h + N
    mov si, 0300h
    add si, dx
    mov al, [si]
    xor ah, ah
    mov [02F0h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_kitten_sitting",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # "kitten" (len 6) vs "sitting" (len 7) -> distance = 3
                        {"segment": "0x2000", "offset": "0x01FC", "data_words": [6, 7]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "kitten"},
                        {"segment": "0x2000", "offset": "0x0220", "data_ascii": "sitting"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [3]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-REPLACE-18",
        "folder": "18_memory_pattern_find_and_replace",
        "category": "category_02_memory_and_strings",
        "title": "Byte Pattern Find and Replace",
        "difficulty": "medium",
        "cycle_budget": 8000,
        "description": "Replace all occurrences of target byte AL (at DS:01FCh) with replacement byte BL (at DS:01FDh) in buffer at DS:0200h of length CX (at DS:01FEh). Write count of replacements to word at DS:02E0h.",
        "prompt": """# Task: Byte Pattern Find and Replace

## Problem Description
Target byte is at DS:01FCh, replacement byte is at DS:01FDh. Buffer length CX is at DS:01FEh.
Scan buffer at DS:0200h and replace every match of target with replacement byte.
Store the total count of replaced bytes in word at DS:02E0h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov al, [01FCh]      ; Target byte
    mov bl, [01FDh]      ; Replacement byte
    mov cx, [01FEh]      ; Length
    mov si, 0200h
    xor dx, dx           ; Count
    jcxz done_replace

rep_loop:
    cmp [si], al
    jne skip_rep
    mov [si], bl
    inc dx
skip_rep:
    inc si
    loop rep_loop

done_replace:
    mov [02E0h], dx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_replace_x",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Target 'X', Replacement 'Y', len 7
                        {"segment": "0x2000", "offset": "0x01FC", "data_bytes": [ord('X'), ord('Y')]},
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [7]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "AXBXCXD"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02E0", "data_words": [3]},
                        {"segment": "0x2000", "offset": "0x0200", "expected_ascii": "AYBYCYD"}
                    ]
                }
            }
        ]
    }
]
