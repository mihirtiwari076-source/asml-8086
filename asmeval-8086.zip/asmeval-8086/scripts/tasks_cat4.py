"""
Category 4: Cryptography, Hashing & Math Tasks (27 to 34)
"""

CAT4_TASKS = [
    {
        "id": "ASM8086-CRC16-27",
        "folder": "27_crc16_ccitt_calculator",
        "category": "category_04_crypto_hashing_math",
        "title": "CRC-16-CCITT Checksum Calculation",
        "difficulty": "medium",
        "cycle_budget": 50000,
        "description": "Compute the 16-bit CRC-CCITT (polynomial 0x1021, initial value 0xFFFF) over a byte buffer starting at DS:0200h with length given as a 16-bit word at DS:01FEh. Store final CRC-16 checksum as a 16-bit word at DS:02F0h.",
        "prompt": """# Task: CRC-16-CCITT Checksum Calculation

## Problem Description
Compute CRC-16-CCITT over buffer at DS:0200h (length word at DS:01FEh).
- Polynomial: 0x1021
- Initial CRC: 0xFFFF
Store the 16-bit CRC word at DS:02F0h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, 0FFFFh
    mov si, 0200h
    mov cx, [01FEh]
    jcxz done_crc

byte_loop:
    mov bh, [si]
    mov bl, 0
    xor ax, bx

    mov dx, 8

bit_loop:
    test ax, 8000h
    jz shift_only
    shl ax, 1
    xor ax, 1021h
    jmp next_bit
shift_only:
    shl ax, 1
next_bit:
    dec dx
    jnz bit_loop

    inc si
    loop byte_loop

done_crc:
    mov [02F0h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_123456789",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [9]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "123456789"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [10673]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-CRC32-28",
        "folder": "28_crc32_ieee802_slice_by_one",
        "category": "category_04_crypto_hashing_math",
        "title": "32-bit CRC-32 IEEE 802.3 Calculation",
        "difficulty": "hard",
        "cycle_budget": 60000,
        "description": "Compute standard 32-bit CRC (polynomial 0xEDB88320, init 0xFFFFFFFF, inverted at end) over byte buffer at DS:0200h (len CX at DS:01FEh). Write 32-bit CRC (low word at DS:02F0h, high word at DS:02F2h).",
        "prompt": """# Task: 32-bit CRC-32 Calculation

## Problem Description
Compute CRC-32 over buffer at DS:0200h with length at DS:01FEh.
Initial CRC: FFFFFFFFh.
Reflected polynomial: 0xEDB88320.
Bitwise slice-by-one:
For each byte B:
  CRC ^= B
  Repeat 8 times:
    if CRC bit 0 == 1:
      CRC = (CRC >> 1) ^ 0xEDB88320
    else:
      CRC = CRC >> 1
Final CRC ^= 0xFFFFFFFF.
Store 32-bit CRC at DS:02F0h (low word at 02F0h, high word at 02F2h).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    ; CRC low word in AX, CRC high word in DX
    mov ax, 0FFFFh
    mov dx, 0FFFFh

    mov si, 0200h
    mov cx, [01FEh]
    jcxz done_crc32

byte_loop:
    mov bl, [si]
    xor bh, bh
    xor ax, bx           ; CRC low ^= byte

    mov bp, 8            ; 8 bits

bit_loop:
    ; Test bit 0 of CRC (AX bit 0)
    test ax, 1
    jz no_poly

    ; CRC = (CRC >> 1) ^ 0xEDB88320
    ; 0xEDB88320 -> High word 0xEDB8, Low word 0x8320
    shr dx, 1
    rcr ax, 1
    xor dx, 0EDB8h
    xor ax, 8320h
    jmp next_bit

no_poly:
    shr dx, 1
    rcr ax, 1

next_bit:
    dec bp
    jnz bit_loop

    inc si
    loop byte_loop

done_crc32:
    not ax
    not dx
    mov [02F0h], ax
    mov [02F2h], dx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_123456789",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # "123456789" -> CRC32 = 0xCBF43926
                        # Low word = 0x3926, High word = 0xCBF4
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [9]},
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "123456789"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [0x3926, 0xCBF4]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-MD5-STEP-29",
        "folder": "29_md5_compression_round_single",
        "category": "category_04_crypto_hashing_math",
        "title": "MD5 Compression Round Primitive",
        "difficulty": "very hard",
        "cycle_budget": 8000,
        "description": "Compute single 16-bit modular MD5 F-step: A = B + rol16(A + ((B & C) | (~B & D)) + X + T, S). Parameters at DS:0200h [A, B, C, D, X, T, S (all 16-bit words)]. Write updated A to DS:0220h.",
        "prompt": """# Task: MD5 Compression Round Primitive

## Problem Description
Parameters at DS:0200h (seven 16-bit words):
- +0: A
- +2: B
- +4: C
- +6: D
- +8: X (message block word)
- +10: T (constant word)
- +12: S (shift amount 1..15)
F(B, C, D) = (B & C) | ((~B) & D).
Sum = A + F(B, C, D) + X + T.
Rot = (Sum rol S).
New_A = B + Rot.
Store New_A (16-bit word) at DS:0220h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov bx, [0202h]      ; B
    mov cx, [0204h]      ; C
    mov dx, [0206h]      ; D

    ; F(B, C, D) = (B & C) | (~B & D)
    mov ax, bx
    and ax, cx           ; AX = B & C

    mov si, bx
    not si
    and si, dx           ; SI = ~B & D
    or ax, si            ; AX = F(B, C, D)

    ; Add A + X + T
    add ax, [0200h]      ; + A
    add ax, [0208h]      ; + X
    add ax, [020Ah]      ; + T

    ; rol AX, S
    mov cx, [020Ch]      ; S
    rol ax, cl

    ; Add B
    add ax, bx           ; New_A = B + Rot

    mov [0220h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_step",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # A=0x1111, B=0x2222, C=0x3333, D=0x4444, X=0x5555, T=0x6666, S=3
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x1111, 0x2222, 0x3333, 0x4444, 0x5555, 0x6666, 3]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # Let's verify: B & C = 0x2222 & 0x3333 = 0x2222
                        # ~B & D = 0xDDDD & 0x4444 = 0x4444 -> F = 0x6666
                        # Sum = 0x1111 + 0x6666 + 0x5555 + 0x6666 = 0x3332
                        # 0x3332 rol 3 = 0x9991
                        # New_A = 0x2222 + 0x9991 = 0xBBB3
                        {"segment": "0x2000", "offset": "0x0220", "data_words": [0xBBB3]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-LFSR-30",
        "folder": "30_lfsr_pseudo_random_number_gen",
        "category": "category_04_crypto_hashing_math",
        "title": "16-bit Galois LFSR Pseudorandom Generator",
        "difficulty": "easy",
        "cycle_budget": 8000,
        "description": "Advance a 16-bit Galois Linear Feedback Shift Register (polynomial 0xACE1) by K steps (from DS:01FEh). Initial state word at DS:0200h. Store final state word at DS:0200h.",
        "prompt": """# Task: 16-bit Galois LFSR Generator

## Problem Description
State word is at DS:0200h. Step count K (16-bit word) is at DS:01FEh.
Polynomial: 0xACE1.
For each step:
  lsb = state & 1
  state >>= 1
  if lsb == 1:
    state ^= 0xACE1
Store resulting state word at DS:0200h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; State
    mov cx, [01FEh]      ; K
    jcxz done_lfsr

lfsr_step:
    shr ax, 1            ; Shift right, CF = shifted out LSB
    jnc no_xor
    xor ax, 0ACE1h
no_xor:
    loop lfsr_step

done_lfsr:
    mov [0200h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_four_steps",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # State = 1, K = 4
                        # step 1: 1 >> 1 = 0, xor ACE1 = ACE1 (1010 1100 1110 0001)
                        # step 2: LSB 1 -> (ACE1 >> 1) ^ ACE1 = 5670 ^ ACE1 = FA91
                        # step 3: LSB 1 -> (FA91 >> 1) ^ ACE1 = 7D48 ^ ACE1 = D1A9
                        # step 4: LSB 1 -> (D1A9 >> 1) ^ ACE1 = 68D4 ^ ACE1 = C435
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [4]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [1]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0xC435]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-CHACHA-QR-31",
        "folder": "31_chacha_quarter_round_primitive",
        "category": "category_04_crypto_hashing_math",
        "title": "ChaCha Quarter-Round 16-Bit Primitive",
        "difficulty": "hard",
        "cycle_budget": 8000,
        "description": "Perform 16-bit ChaCha quarter-round on four words [a, b, c, d] at DS:0200h. Update words in-place at DS:0200h.",
        "prompt": """# Task: ChaCha Quarter-Round 16-Bit Primitive

## Problem Description
Four 16-bit words at DS:0200h: a (+0), b (+2), c (+4), d (+6).
Perform operations:
1. a += b; d ^= a; d rol 8
2. c += d; b ^= c; b rol 7
3. a += b; d ^= a; d rol 8
4. c += d; b ^= c; b rol 7
Store updated words in-place at DS:0200h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; a
    mov bx, [0202h]      ; b
    mov cx, [0204h]      ; c
    mov dx, [0206h]      ; d

    ; Step 1: a += b; d ^= a; d rol 8
    add ax, bx
    xor dx, ax
    rol dx, 8

    ; Step 2: c += d; b ^= c; b rol 7
    add cx, dx
    xor bx, cx
    rol bx, 7

    ; Step 3: a += b; d ^= a; d rol 8
    add ax, bx
    xor dx, ax
    rol dx, 8

    ; Step 4: c += d; b ^= c; b rol 7
    add cx, dx
    xor bx, cx
    rol bx, 7

    mov [0200h], ax
    mov [0202h], bx
    mov [0204h], cx
    mov [0206h], dx

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_round",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x1111, 0x2222, 0x3333, 0x4444]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # Hand trace or computed:
                        # 1: a=3333, d=4444^3333=7777 -> rol 8 -> 7777
                        # 2: c=3333+7777=AAAA, b=2222^AAAA=8888 -> rol 7 = 4444
                        # 3: a=3333+4444=7777, d=7777^7777=0000 -> rol 8 -> 0000
                        # 4: c=AAAA+0=AAAA, b=4444^AAAA=EEEE -> rol 7 = 7777
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x7777, 0x7777, 0xAAAA, 0x0000]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-MODEXP-32",
        "folder": "32_big_integer_mod_exp_128bit",
        "category": "category_04_crypto_hashing_math",
        "title": "Modular Product Primitive",
        "difficulty": "very hard",
        "cycle_budget": 5000,
        "description": "Compute (A * B) % M for 16-bit unsigned integers: A at DS:0200h, B at DS:0202h, M at DS:0204h. Write remainder to word at DS:0206h.",
        "prompt": """# Task: Modular Product Primitive

## Problem Description
Compute (A * B) mod M.
- A (16-bit word) at DS:0200h
- B (16-bit word) at DS:0202h
- M (16-bit word) at DS:0204h
Compute 32-bit product with MUL, then divide by M with DIV to obtain remainder.
Store remainder (16-bit word) at DS:0206h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]
    mov bx, [0202h]
    mul bx               ; DX:AX = A * B
    mov bx, [0204h]      ; M
    div bx               ; AX = quotient, DX = remainder
    mov [0206h], dx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_mod",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # (12345 * 6789) % 10007 = 83810205 % 10007 = 5122
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [12345, 6789, 10007]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0206", "data_words": [5122]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-ISQRT-33",
        "folder": "33_integer_square_root_isqrt",
        "category": "category_04_crypto_hashing_math",
        "title": "Integer Square Root (isqrt)",
        "difficulty": "medium",
        "cycle_budget": 8000,
        "description": "Compute integer square root floor(sqrt(X)) for 16-bit unsigned integer X at DS:0200h. Write result word to DS:0202h.",
        "prompt": """# Task: Integer Square Root

## Problem Description
Unsigned 16-bit integer X is at DS:0200h.
Compute floor(sqrt(X)).
Store the resulting 16-bit word at DS:0202h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [0200h]      ; X
    xor bx, bx           ; r = 0

isqrt_loop:
    mov ax, bx
    inc ax
    mul ax               ; DX:AX = (r+1)^2
    cmp dx, 0
    jne found_root
    cmp ax, cx
    ja found_root
    inc bx
    jmp isqrt_loop

found_root:
    mov [0202h], bx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_perfect_square",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # sqrt(144) = 12
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [144]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "data_words": [12]}
                    ]
                }
            },
            {
                "id": "case_2_non_perfect",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # sqrt(1000) = 31 (31^2 = 961 <= 1000 < 32^2 = 1024)
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [1000]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "data_words": [31]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-FFT-BUTTERFLY-34",
        "folder": "34_fast_fourier_butterfly_radix2",
        "category": "category_04_crypto_hashing_math",
        "title": "FFT Radix-2 Complex Butterfly Primitive",
        "difficulty": "very hard",
        "cycle_budget": 5000,
        "description": "Perform complex Radix-2 butterfly on complex inputs A=(Ar, Ai) and B=(Br, Bi) at DS:0200h [Ar, Ai, Br, Bi (16-bit signed words)]. Compute A' = A + B, B' = A - B and store [A'r, A'i, B'r, B'i] at DS:0210h.",
        "prompt": """# Task: FFT Radix-2 Complex Butterfly Primitive

## Problem Description
Input complex numbers at DS:0200h (four 16-bit signed words):
- +0: Ar
- +2: Ai
- +4: Br
- +6: Bi
Compute:
A'r = Ar + Br
A'i = Ai + Bi
B'r = Ar - Br
B'i = Ai - Bi
Store [A'r, A'i, B'r, B'i] at DS:0210h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; Ar
    mov bx, [0204h]      ; Br
    mov cx, ax
    add cx, bx           ; A'r = Ar + Br
    sub ax, bx           ; B'r = Ar - Br

    mov [0210h], cx
    mov [0214h], ax

    mov ax, [0202h]      ; Ai
    mov bx, [0206h]      ; Bi
    mov cx, ax
    add cx, bx           ; A'i = Ai + Bi
    sub ax, bx           ; B'i = Ai - Bi

    mov [0212h], cx
    mov [0216h], ax

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_butterfly",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Ar=10, Ai=20, Br=4, Bi=6
                        # A'r = 14, A'i = 26, B'r = 6, B'i = 14
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [10, 20, 4, 6]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [14, 26, 6, 14]}
                    ]
                }
            }
        ]
    }
]
