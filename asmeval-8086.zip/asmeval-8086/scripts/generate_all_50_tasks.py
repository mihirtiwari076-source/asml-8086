"""
Generator and Verifier for all 50 Benchmark Tasks of asmeval-8086.
"""

import json
import shutil
from pathlib import Path

from scripts.tasks_cat1 import CAT1_TASKS
from scripts.tasks_cat2 import CAT2_TASKS
from scripts.tasks_cat3 import CAT3_TASKS
from scripts.tasks_cat4 import CAT4_TASKS
from scripts.tasks_cat5 import CAT5_TASKS
from scripts.tasks_cat6 import CAT6_TASKS

from asmeval.harness.task_loader import load_all_tasks
from asmeval.harness.runner import TaskRunner

ALL_TASKS = (
    CAT1_TASKS +
    CAT2_TASKS +
    CAT3_TASKS +
    CAT4_TASKS +
    CAT5_TASKS +
    CAT6_TASKS
)


def main():
    repo_root = Path(__file__).resolve().parent.parent
    tasks_dir = repo_root / "tasks"

    print(f"Total task specifications defined: {len(ALL_TASKS)}")
    assert len(ALL_TASKS) == 50, f"Expected 50 tasks, found {len(ALL_TASKS)}"

    # Remove old flat task directories if present
    for old_name in [
        "01_bcd_multibyte_addition",
        "02_inplace_string_reverse",
        "03_crc16_ccitt_calculator",
        "04_palindrome_memory_verifier",
        "05_quicksort_in_memory_words",
    ]:
        p = tasks_dir / old_name
        if p.exists() and p.is_dir():
            shutil.rmtree(p)

    # Write all 50 tasks
    for t in ALL_TASKS:
        cat_dir = tasks_dir / t["category"]
        t_dir = cat_dir / t["folder"]
        t_dir.mkdir(parents=True, exist_ok=True)

        # 1. task.json
        task_meta = {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "task_id": t["id"],
            "category": t["category"],
            "title": t["title"],
            "difficulty": t["difficulty"],
            "cycle_budget": t.get("cycle_budget", 15000),
            "memory_budget_bytes": 128,
            "description": t["description"],
            "scoring_weights": {
                "correctness": 0.70,
                "cycle_efficiency": 0.20,
                "code_density": 0.10
            },
            "environment": {
                "initial_registers": {
                    "DS": "0x2000",
                    "ES": "0x2000",
                    "SS": "0x3000",
                    "SP": "0xFFFE",
                    "CS": "0x1000",
                    "IP": "0x0100"
                },
                "clobber_policy": {
                    "allowed_to_modify": ["AX", "BX", "CX", "DX", "SI", "DI", "BP", "FLAGS"],
                    "must_preserve": ["SS", "CS"]
                }
            },
            "initial_state": t["test_cases"][0]["initial_state"],
            "assertions": t["test_cases"][0]["assertions"]
        }
        (t_dir / "task.json").write_text(json.dumps(task_meta, indent=2), encoding="utf-8")

        # 2. prompt.md
        (t_dir / "prompt.md").write_text(t["prompt"].strip() + "\n", encoding="utf-8")

        # 3. template.asm
        (t_dir / "template.asm").write_text(t["template"].strip() + "\n", encoding="utf-8")

        # 4. solution.asm
        (t_dir / "solution.asm").write_text(t["solution"].strip() + "\n", encoding="utf-8")

        # 5. test_cases.json
        (t_dir / "test_cases.json").write_text(json.dumps(t["test_cases"], indent=2), encoding="utf-8")

    print("All 50 task directories generated successfully.")

    # Validate loading
    loaded_tasks = load_all_tasks(tasks_dir)
    print(f"Loaded {len(loaded_tasks)} tasks via task_loader.")
    assert len(loaded_tasks) == 50

    # Execute all 50 tasks with TaskRunner
    runner = TaskRunner()
    passed = 0
    failed = []

    for idx, lt in enumerate(loaded_tasks, 1):
        sol_file = lt.directory / "solution.asm"
        report = runner.run_task(lt, sol_file)
        if report.status == "PASSED":
            passed += 1
            print(f"[{idx:02d}/50] [PASS] {lt.task_id} ({report.cycles_elapsed} cycles)")
        else:
            failed.append((lt.task_id, report.status, report.errors, report.memory_diffs))
            print(f"[{idx:02d}/50] [FAIL] {lt.task_id} - status: {report.status}")

    print("=" * 60)
    print(f"Verification Summary: {passed}/50 PASSED")
    if failed:
        print("Failures:")
        for fid, stat, errs, mem_diffs in failed:
            print(f"  {fid}: status={stat}, errors={errs}, mem_diffs={mem_diffs}")
    assert passed == 50, f"Only {passed}/50 tasks passed!"


if __name__ == "__main__":
    main()
