"""
Category 1: Arithmetic & BCD Tasks (01 to 08)
"""

CAT1_TASKS = [
    {
        "id": "ASM8086-BCD-ADD-01",
        "folder": "01_bcd_multibyte_addition",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Multi-Byte Packed BCD Addition in Real Mode",
        "difficulty": "medium",
        "cycle_budget": 10000,
        "description": "Perform 4-byte packed Binary Coded Decimal (BCD) addition of two 8-digit decimal numbers using the DAA instruction. Operands are in little-endian byte order at DS:0200h and DS:0204h. Write the 4-byte BCD sum to DS:0208h and the final carry byte (00h or 01h) to DS:020Ch.",
        "prompt": """# Task: Multi-Byte Packed BCD Addition in 8086 Real Mode

## Problem Description
Implement a 16-bit Intel 8086 assembly program that performs multi-byte packed Binary-Coded Decimal (BCD) addition.

### Specifications:
- Operand A: 4 bytes located at DS:0200h (little-endian byte order).
- Operand B: 4 bytes located at DS:0204h.
- Result Buffer: Store the 4-byte packed BCD result at DS:0208h.
- Carry-Out: Store the final carry out (00h or 01h) as a single byte at DS:020Ch.
- Terminate via DOS INT 21h (AH=4Ch) or HLT.
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    cld
    mov si, 0200h
    mov di, 0204h
    mov bx, 0208h
    mov cx, 4
    clc

bcd_loop:
    mov al, [si]
    adc al, [di]
    daa
    mov [bx], al
    inc si
    inc di
    inc bx
    loop bcd_loop

    mov al, 0
    adc al, 0
    mov [020Ch], al

    cmp al, 1
    je set_c
    clc
    jmp done
set_c:
    stc
done:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_carry",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_hex": "12 34 56 78"},
                        {"segment": "0x2000", "offset": "0x0204", "data_hex": "88 65 43 21"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0208", "expected_hex": "00 00 00 00"},
                        {"segment": "0x2000", "offset": "0x020C", "expected_bytes": [1]}
                    ],
                    "flags": {"CF": 1}
                }
            },
            {
                "id": "case_2_no_carry",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_hex": "78 56 34 12"},
                        {"segment": "0x2000", "offset": "0x0204", "data_hex": "11 11 11 11"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0208", "expected_hex": "89 67 45 23"},
                        {"segment": "0x2000", "offset": "0x020C", "expected_bytes": [0]}
                    ],
                    "flags": {"CF": 0}
                }
            },
            {
                "id": "case_3_zeros",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_hex": "00 00 00 00"},
                        {"segment": "0x2000", "offset": "0x0204", "data_hex": "00 00 00 00"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0208", "expected_hex": "00 00 00 00"},
                        {"segment": "0x2000", "offset": "0x020C", "expected_bytes": [0]}
                    ],
                    "flags": {"CF": 0}
                }
            }
        ]
    },
    {
        "id": "ASM8086-BCD-SUB-02",
        "folder": "02_bcd_multibyte_subtraction",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Multi-Byte Packed BCD Subtraction in Real Mode",
        "difficulty": "medium",
        "cycle_budget": 10000,
        "description": "Subtract two 4-byte packed BCD numbers using DAS and SBB. Minuend at DS:0200h, Subtrahend at DS:0204h. Write 4-byte difference to DS:0208h and borrow byte (00h or 01h) to DS:020Ch.",
        "prompt": """# Task: Multi-Byte Packed BCD Subtraction

## Problem Description
Compute Minuend - Subtrahend for 4-byte packed BCD numbers at DS:0200h and DS:0204h.
Write the 4-byte difference to DS:0208h and borrow (01h if borrow out, else 00h) to DS:020Ch.
Use the DAS instruction. Terminate with INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    cld
    mov si, 0200h
    mov di, 0204h
    mov bx, 0208h
    mov cx, 4
    clc

sub_loop:
    mov al, [si]
    sbb al, [di]
    das
    mov [bx], al
    inc si
    inc di
    inc bx
    loop sub_loop

    mov al, 0
    adc al, 0
    mov [020Ch], al

    cmp al, 1
    je set_c
    clc
    jmp done
set_c:
    stc
done:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_no_borrow",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_hex": "50 82 45 67"},
                        {"segment": "0x2000", "offset": "0x0204", "data_hex": "25 27 12 34"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0208", "expected_hex": "25 55 33 33"},
                        {"segment": "0x2000", "offset": "0x020C", "expected_bytes": [0]}
                    ],
                    "flags": {"CF": 0}
                }
            },
            {
                "id": "case_2_borrow_out",
                "initial_state": {
                    "registers": {"DS": "0x2000", "ES": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_hex": "10 00 00 00"},
                        {"segment": "0x2000", "offset": "0x0204", "data_hex": "20 00 00 00"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0208", "expected_hex": "90 99 99 99"},
                        {"segment": "0x2000", "offset": "0x020C", "expected_bytes": [1]}
                    ],
                    "flags": {"CF": 1}
                }
            }
        ]
    },
    {
        "id": "ASM8086-BCD-MUL-03",
        "folder": "03_bcd_ascii_multiplication_aam",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Unpacked BCD Multiplication with AAM",
        "difficulty": "hard",
        "cycle_budget": 5000,
        "description": "Multiply two single-digit unpacked BCD numbers stored at DS:0200h and DS:0201h. Adjust using AAM and store 2-digit unpacked BCD product at DS:0202h (low digit) and DS:0203h (high digit).",
        "prompt": """# Task: Unpacked BCD Multiplication with AAM

## Problem Description
Read two 1-byte unpacked BCD digits from DS:0200h and DS:0201h.
Multiply them using MUL, adjust the product into unpacked BCD using AAM,
and store the 2-digit result at DS:0202h (low digit) and DS:0203h (high digit).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov al, [0200h]
    mov bl, [0201h]
    mul bl
    aam
    mov [0202h], al
    mov [0203h], ah
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_7_times_8",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [7, 8]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "expected_bytes": [6, 5]}
                    ]
                }
            },
            {
                "id": "case_2_9_times_9",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [9, 9]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "expected_bytes": [1, 8]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-BCD-DIV-04",
        "folder": "04_bcd_ascii_division_aad",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Unpacked BCD Division with AAD",
        "difficulty": "hard",
        "cycle_budget": 5000,
        "description": "Divide a 2-digit unpacked BCD number at DS:0200h (low digit) and DS:0201h (high digit) by an unpacked divisor at DS:0202h using AAD and DIV. Store quotient at DS:0203h and remainder at DS:0204h.",
        "prompt": """# Task: Unpacked BCD Division with AAD

## Problem Description
Load high digit into AH from DS:0201h and low digit into AL from DS:0200h.
Load divisor into BL from DS:0202h.
Use AAD to convert AH:AL into binary, execute DIV BL, and store:
- Quotient byte at DS:0203h
- Remainder byte at DS:0204h
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov al, [0200h]
    mov ah, [0201h]
    mov bl, [0202h]
    aad
    div bl
    mov [0203h], al
    mov [0204h], ah
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_75_div_8",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [5, 7, 8]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0203", "expected_bytes": [9, 3]}
                    ]
                }
            },
            {
                "id": "case_2_42_div_7",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [2, 4, 7]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0203", "expected_bytes": [6, 0]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-IDIV-32-05",
        "folder": "05_signed_32bit_by_16bit_idiv",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Signed 32-bit by 16-bit Division",
        "difficulty": "medium",
        "cycle_budget": 5000,
        "description": "Perform signed division of 32-bit integer in DX:AX (DX at DS:0202h, AX at DS:0200h) by 16-bit divisor in BX (at DS:0204h). Store 16-bit quotient at DS:0206h and remainder at DS:0208h.",
        "prompt": """# Task: Signed 32-bit by 16-bit Division

## Problem Description
Load low word of dividend from DS:0200h into AX, high word from DS:0202h into DX.
Load 16-bit signed divisor from DS:0204h into BX.
Execute IDIV BX.
Store signed 16-bit quotient into DS:0206h and signed 16-bit remainder into DS:0208h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]
    mov dx, [0202h]
    mov bx, [0204h]
    idiv bx
    mov [0206h], ax
    mov [0208h], dx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_neg_dividend",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # -100,000 in 32-bit hex: 0xFFFE7960 -> AX = 0x7960, DX = 0xFFFE
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x7960, 0xFFFE, 300]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # Quotient: -333 (0xFEB3), Remainder: -100 (0xFF9C)
                        {"segment": "0x2000", "offset": "0x0206", "data_words": [0xFEB3, 0xFF9C]}
                    ]
                }
            },
            {
                "id": "case_2_pos_division",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 50,000 / 12 -> AX=50000 (0xC350), DX=0, Divisor=12
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [50000, 0, 12]}
                    ]
                },
                "assertions": {
                    "memory": [
                        # 50000 // 12 = 4166 (0x1046), rem = 8
                        {"segment": "0x2000", "offset": "0x0206", "data_words": [4166, 8]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-ADD-64-06",
        "folder": "06_unsigned_64bit_addition_chain",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Unsigned 64-bit Addition Chain",
        "difficulty": "easy",
        "cycle_budget": 5000,
        "description": "Add two 64-bit unsigned integers represented as four 16-bit little-endian words at DS:0200h and DS:0208h. Write 64-bit sum to DS:0210h and carry-out byte to DS:0218h.",
        "prompt": """# Task: Unsigned 64-bit Addition Chain

## Problem Description
Add 64-bit Operand A at DS:0200h (4 words) and Operand B at DS:0208h (4 words).
Write the 4-word sum to DS:0210h.
Write the carry out (01h or 00h) to byte DS:0218h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov si, 0200h
    mov di, 0208h
    mov bx, 0210h

    mov ax, [si]
    add ax, [di]
    mov [bx], ax

    mov ax, [si+2]
    adc ax, [di+2]
    mov [bx+2], ax

    mov ax, [si+4]
    adc ax, [di+4]
    mov [bx+4], ax

    mov ax, [si+6]
    adc ax, [di+6]
    mov [bx+6], ax

    mov al, 0
    adc al, 0
    mov [0218h], al

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_chain_carry",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0xFFFF, 0xFFFF, 0xFFFF, 0xFFFF]},
                        {"segment": "0x2000", "offset": "0x0208", "data_words": [1, 0, 0, 0]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [0, 0, 0, 0]},
                        {"segment": "0x2000", "offset": "0x0218", "expected_bytes": [1]}
                    ]
                }
            },
            {
                "id": "case_2_simple_sum",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [100, 200, 300, 400]},
                        {"segment": "0x2000", "offset": "0x0208", "data_words": [50, 60, 70, 80]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [150, 260, 370, 480]},
                        {"segment": "0x2000", "offset": "0x0218", "expected_bytes": [0]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-FIXED-MUL-07",
        "folder": "07_fixed_point_16_16_multiply",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Signed Q8.8 Fixed-Point Multiplication",
        "difficulty": "hard",
        "cycle_budget": 5000,
        "description": "Multiply two signed Q8.8 fixed-point numbers at DS:0200h and DS:0202h. Scale by shifting right 8 bits and store 16-bit Q8.8 result at DS:0204h.",
        "prompt": """# Task: Signed Q8.8 Fixed-Point Multiplication

## Problem Description
Load signed 16-bit Q8.8 values from DS:0200h and DS:0202h.
Multiply with IMUL to yield a 32-bit product in DX:AX.
Shift DX:AX right by 8 bits to rescale back to Q8.8 format:
(AX = (DX << 8) | (AX >> 8)).
Store the 16-bit Q8.8 result at DS:0204h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]
    mov bx, [0202h]
    imul bx
    ; Rescale (DX:AX) >> 8 into AX
    mov al, ah
    mov ah, dl
    mov [0204h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_two_times_three",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 2.0 = 0x0200, 3.5 = 0x0380 -> Product = 7.0 = 0x0700
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x0200, 0x0380]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0204", "data_words": [0x0700]}
                    ]
                }
            },
            {
                "id": "case_2_half_times_four",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 0.5 = 0x0080, 4.0 = 0x0400 -> Product = 2.0 = 0x0200
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x0080, 0x0400]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0204", "data_words": [0x0200]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-HORNER-08",
        "folder": "08_fast_polynomial_horner_eval",
        "category": "category_01_arithmetic_and_bcd",
        "title": "Polynomial Evaluation via Horner's Rule",
        "difficulty": "hard",
        "cycle_budget": 10000,
        "description": "Evaluate polynomial P(x) = a_N*x^N + ... + a_0 using Horner's rule. Degree N at DS:0200h, X at DS:0202h, coefficients a_N ... a_0 at DS:0204h. Write 16-bit result to DS:0220h.",
        "prompt": """# Task: Polynomial Evaluation via Horner's Rule

## Problem Description
Evaluate polynomial P(x) = (...(a_N * x + a_{N-1}) * x + ...) + a_0.
- Degree N (word) at DS:0200h
- Value x (word) at DS:0202h
- Coefficients (N+1 words) starting at DS:0204h from highest degree a_N down to a_0.
Store resulting 16-bit word at DS:0220h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [0200h]      ; N
    mov bx, [0202h]      ; x
    mov si, 0204h        ; Pointer to coeffs

    mov ax, [si]         ; Accumulator = a_N
    add si, 2
    jcxz done_horner

horner_loop:
    mul bx               ; DX:AX = Accumulator * x
    add ax, [si]         ; Accumulator += a_{i}
    add si, 2
    loop horner_loop

done_horner:
    mov [0220h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_quadratic",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # P(x) = 2x^2 + 3x + 5 for x = 4 -> 2(16) + 12 + 5 = 49
                        # N = 2, x = 4, coeffs = [2, 3, 5]
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [2, 4, 2, 3, 5]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0220", "data_words": [49]}
                    ]
                }
            },
            {
                "id": "case_2_linear",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # P(x) = 5x + 7 for x = 10 -> 57
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [1, 10, 5, 7]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0220", "data_words": [57]}
                    ]
                }
            }
        ]
    }
]
