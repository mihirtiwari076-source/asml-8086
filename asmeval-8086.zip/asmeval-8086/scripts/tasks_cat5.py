"""
Category 5: Bit Manipulation & Codecs Tasks (35 to 42)
"""

CAT5_TASKS = [
    {
        "id": "ASM8086-BASE64-ENC-35",
        "folder": "35_base64_stream_encoder",
        "category": "category_05_bit_manipulation_codecs",
        "title": "3-Byte to 4-Character Base64 Block Encoder",
        "difficulty": "medium",
        "cycle_budget": 8000,
        "description": "Encode 3 raw bytes at DS:0200h into 4 Base64 ASCII characters at DS:0250h using standard Base64 alphabet table.",
        "prompt": """# Task: 3-Byte to 4-Character Base64 Block Encoder

## Problem Description
Three raw bytes are located at DS:0200h (B0, B1, B2).
Encode them into 4 Base64 ASCII characters using alphabet:
'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
Write the 4 ASCII characters to DS:0250h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    ; Load 3 bytes: b0, b1, b2
    mov al, [0200h]      ; b0
    mov ah, [0201h]      ; b1
    mov dl, [0202h]      ; b2

    ; Index 0: b0 >> 2 (top 6 bits of b0)
    mov bl, al
    shr bl, 2
    and bx, 003Fh
    call get_b64_char
    mov [0250h], al

    ; Index 1: ((b0 & 3) << 4) | (b1 >> 4)
    mov al, [0200h]
    and al, 3
    shl al, 4
    mov bl, ah
    shr bl, 4
    or al, bl
    mov bl, al
    and bx, 003Fh
    call get_b64_char
    mov [0251h], al

    ; Index 2: ((b1 & 0x0F) << 2) | (b2 >> 6)
    mov al, [0201h]
    and al, 0Fh
    shl al, 2
    mov bl, dl
    shr bl, 6
    or al, bl
    mov bl, al
    and bx, 003Fh
    call get_b64_char
    mov [0252h], al

    ; Index 3: b2 & 0x3F
    mov bl, dl
    and bx, 003Fh
    call get_b64_char
    mov [0253h], al

    mov ax, 4C00h
    int 21h

get_b64_char:
    ; Input: BX (0..63). Output: AL (ASCII char)
    mov al, [b64_table + bx]
    ret

b64_table:
    db 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
""",
        "test_cases": [
            {
                "id": "case_1_man",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # "Man" (0x4D, 0x61, 0x6E) -> "TWFu"
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [0x4D, 0x61, 0x6E]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0250", "data_ascii": "TWFu"}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-BASE64-DEC-36",
        "folder": "36_base64_stream_decoder",
        "category": "category_05_bit_manipulation_codecs",
        "title": "4-Character to 3-Byte Base64 Block Decoder",
        "difficulty": "hard",
        "cycle_budget": 8000,
        "description": "Decode 4 Base64 ASCII characters from DS:0200h into 3 raw bytes at DS:0250h.",
        "prompt": """# Task: 4-Character to 3-Byte Base64 Block Decoder

## Problem Description
Four Base64 ASCII characters are located at DS:0200h.
Decode them back into 3 raw bytes:
- Byte 0: (idx0 << 2) | (idx1 >> 4)
- Byte 1: ((idx1 & 0xF) << 4) | (idx2 >> 2)
- Byte 2: ((idx2 & 3) << 6) | idx3
Write the 3 raw bytes to DS:0250h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    ; Decode char 0
    mov al, [0200h]
    call decode_char
    mov [0210h], al      ; idx0

    ; Decode char 1
    mov al, [0201h]
    call decode_char
    mov [0211h], al      ; idx1

    ; Decode char 2
    mov al, [0202h]
    call decode_char
    mov [0212h], al      ; idx2

    ; Decode char 3
    mov al, [0203h]
    call decode_char
    mov [0213h], al      ; idx3

    ; Byte 0: (idx0 << 2) | (idx1 >> 4)
    mov al, [0210h]
    shl al, 2
    mov bl, [0211h]
    shr bl, 4
    or al, bl
    mov [0250h], al

    ; Byte 1: ((idx1 & 0x0F) << 4) | (idx2 >> 2)
    mov al, [0211h]
    and al, 0Fh
    shl al, 4
    mov bl, [0212h]
    shr bl, 2
    or al, bl
    mov [0251h], al

    ; Byte 2: ((idx2 & 3) << 6) | idx3
    mov al, [0212h]
    and al, 3
    shl al, 6
    mov bl, [0213h]
    or al, bl
    mov [0252h], al

    mov ax, 4C00h
    int 21h

decode_char:
    cmp al, 'A'
    jb check_digits
    cmp al, 'Z'
    ja check_lower
    sub al, 'A'
    ret
check_lower:
    cmp al, 'a'
    jb check_plus
    cmp al, 'z'
    ja check_plus
    sub al, 'a'
    add al, 26
    ret
check_digits:
    cmp al, '0'
    jb check_plus
    cmp al, '9'
    ja check_plus
    sub al, '0'
    add al, 52
    ret
check_plus:
    cmp al, '+'
    jne is_slash
    mov al, 62
    ret
is_slash:
    mov al, 63
    ret
""",
        "test_cases": [
            {
                "id": "case_1_twfu",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        {"segment": "0x2000", "offset": "0x0200", "data_ascii": "TWFu"}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0250", "data_bytes": [0x4D, 0x61, 0x6E]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-BITMAP-37",
        "folder": "37_bitmap_find_first_free_bit",
        "category": "category_05_bit_manipulation_codecs",
        "title": "Bitmap Scan for First Free Bit (0)",
        "difficulty": "easy",
        "cycle_budget": 12000,
        "description": "Scan 128-byte allocation bitmap at DS:0200h (1024 bits, bit 0 is LSB of byte 0) to find index of first 0-bit. Store 16-bit index at DS:02F0h (or 0xFFFF if all bits are 1).",
        "prompt": """# Task: Bitmap Scan for First Free Bit

## Problem Description
128 bytes (1024 bits) bitmap at DS:0200h.
Find the first clear bit (0-bit).
Bit indexing:
- Bit 0 is bit 0 of byte 0
- Bit 7 is bit 7 of byte 0
- Bit 8 is bit 0 of byte 1, etc.
Store the 0-based bit index (16-bit word) at DS:02F0h (or 0xFFFF if all bits are 1).
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov si, 0200h
    xor cx, cx           ; Byte offset 0..127

byte_scan:
    cmp cx, 128
    jae none_free

    mov al, [si]
    cmp al, 0FFh
    jne found_byte_with_zero

    inc si
    inc cx
    jmp byte_scan

found_byte_with_zero:
    ; Find which bit in AL is 0
    xor bx, bx           ; bit 0..7

bit_scan:
    test al, 1
    jz found_bit
    shr al, 1
    inc bx
    jmp bit_scan

found_bit:
    ; Total bit index = (cx * 8) + bx
    mov ax, cx
    shl ax, 3
    add ax, bx
    mov [02F0h], ax
    jmp done_bitmap

none_free:
    mov word [02F0h], 0FFFFh

done_bitmap:
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_bit_19",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Fill first 16 bytes with 0xFF, but byte 2 (offset 0202h) has bit 3 clear:
                        # 0xFF, 0xFF, 0xF7 -> 0xF7 = 1111 0111b (bit 3 is 0)
                        # Total index = 2 * 8 + 3 = 19
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [0xFF, 0xFF, 0xF7, 0xFF]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [19]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-POPCNT-38",
        "folder": "38_population_count_popcnt_words",
        "category": "category_05_bit_manipulation_codecs",
        "title": "Population Count (PopCount) Across Word Array",
        "difficulty": "easy",
        "cycle_budget": 15000,
        "description": "Count total number of set 1-bits across an array of N 16-bit words at DS:0200h (N at DS:01FEh). Write total count word to DS:02F0h.",
        "prompt": """# Task: Population Count Across Word Array

## Problem Description
Array of N 16-bit words at DS:0200h (N from DS:01FEh).
Count the total number of bits set to 1 across the entire array.
Store the 16-bit count at DS:02F0h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; N
    mov si, 0200h
    xor dx, dx           ; Total 1-bits counter
    jcxz done_popcnt

word_loop:
    mov ax, [si]
    add si, 2

bit_loop:
    cmp ax, 0
    je next_word
    ; Brian Kernighan bit trick: ax &= (ax - 1) clears lowest set bit
    mov bx, ax
    dec bx
    and ax, bx
    inc dx
    jmp bit_loop

next_word:
    loop word_loop

done_popcnt:
    mov [02F0h], dx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_popcnt",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 3 words: 0x000F (4 bits), 0x00F0 (4 bits), 0x5555 (8 bits) -> total 16
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [3]},
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x000F, 0x00F0, 0x5555]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x02F0", "data_words": [16]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-BITREV-39",
        "folder": "39_bit_reversal_16bit_word",
        "category": "category_05_bit_manipulation_codecs",
        "title": "16-Bit Word Bit Reversal",
        "difficulty": "easy",
        "cycle_budget": 5000,
        "description": "Reverse the 16 bits of word at DS:0200h (bit 15 becomes bit 0, etc.). Store reversed word at DS:0202h.",
        "prompt": """# Task: 16-Bit Word Bit Reversal

## Problem Description
Load 16-bit word from DS:0200h.
Reverse its bit order so that MSB becomes LSB and LSB becomes MSB.
Store the 16-bit reversed word at DS:0202h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]
    xor bx, bx           ; Result
    mov cx, 16

rev_bit_loop:
    shr ax, 1            ; Shift LSB into CF
    rcl bx, 1            ; Shift CF into LSB of BX (will end up at MSB)
    loop rev_bit_loop

    mov [0202h], bx
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_pattern",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 0x8001 (1000 0000 0000 0001) -> reversed is 0x8001
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x8001]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "data_words": [0x8001]}
                    ]
                }
            },
            {
                "id": "case_2_asym",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 0x000F (0000 0000 0000 1111) -> 0xF000 (1111 0000 0000 0000)
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [0x000F]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "data_words": [0xF000]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-HUFFMAN-40",
        "folder": "40_huffman_bitstream_unpack",
        "category": "category_05_bit_manipulation_codecs",
        "title": "Huffman Bitstream Prefix Code Unpack",
        "difficulty": "very hard",
        "cycle_budget": 15000,
        "description": "Decode prefix bitstream at DS:0200h: code '0' -> 'A', '10' -> 'B', '11' -> 'C'. Number of symbols to decode at DS:01FEh. Write decoded ASCII string to DS:0250h.",
        "prompt": """# Task: Huffman Bitstream Prefix Code Unpack

## Problem Description
Decode prefix bitstream starting at DS:0200h (MSB first within each byte).
Prefix code table:
- '0'     -> 'A' (41h)
- '10'    -> 'B' (42h)
- '11'    -> 'C' (43h)
Number of symbols to decode is at DS:01FEh.
Write decoded characters sequentially to DS:0250h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; Number of symbols
    mov si, 0200h        ; Input bitstream
    mov di, 0250h        ; Output buffer
    jcxz done_huff

    mov ah, [si]         ; Current byte
    inc si
    mov dl, 8            ; Bits remaining in AH

decode_symbol:
    ; Read next bit into CF
    call get_next_bit
    jnc symbol_a         ; Bit was 0 -> 'A'

    ; Bit was 1, read next bit
    call get_next_bit
    jnc symbol_b         ; '10' -> 'B'

symbol_c:                ; '11' -> 'C'
    mov byte [di], 'C'
    inc di
    loop decode_symbol
    jmp done_huff

symbol_b:
    mov byte [di], 'B'
    inc di
    loop decode_symbol
    jmp done_huff

symbol_a:
    mov byte [di], 'A'
    inc di
    loop decode_symbol

done_huff:
    mov ax, 4C00h
    int 21h

get_next_bit:
    ; Shifts MSB of AH into CF. Refills from [SI] if empty.
    cmp dl, 0
    jne do_shift
    mov ah, [si]
    inc si
    mov dl, 8
do_shift:
    shl ah, 1
    dec dl
    ret
""",
        "test_cases": [
            {
                "id": "case_1_abcba",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # "A B C B A":
                        # A = 0, B = 10, C = 11, B = 10, A = 0
                        # Bitstream: 0 10 11 10 0 = 0101 1100 = 0x5C
                        {"segment": "0x2000", "offset": "0x01FE", "data_words": [5]},
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [0x5C]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0250", "data_ascii": "ABCBA"}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-GRAY-41",
        "folder": "41_gray_code_to_binary_converter",
        "category": "category_05_bit_manipulation_codecs",
        "title": "Gray Code to Binary Converter",
        "difficulty": "easy",
        "cycle_budget": 5000,
        "description": "Convert 16-bit Gray code value at DS:0200h to standard binary representation (B = G ^ (G>>1) ^ (G>>2) ...). Write binary word to DS:0202h.",
        "prompt": """# Task: Gray Code to Binary Converter

## Problem Description
Load 16-bit Gray code value from DS:0200h.
Convert it to standard binary:
while (shift > 0):
  val ^= (val >> shift)
Store the 16-bit binary result at DS:0202h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; Gray code

    ; B = G ^ (G >> 1) ^ (G >> 2) ^ ...
    mov bx, ax
    shr bx, 1
    xor ax, bx

    mov bx, ax
    shr bx, 2
    xor ax, bx

    mov bx, ax
    shr bx, 4
    xor ax, bx

    mov bx, ax
    shr bx, 8
    xor ax, bx

    mov [0202h], ax
    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_seven",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Binary 7 = 0111 -> Gray = 0100 (4)
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [4]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "data_words": [7]}
                    ]
                }
            },
            {
                "id": "case_2_fifteen",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # Binary 15 = 1111 -> Gray = 1010 (10)
                        {"segment": "0x2000", "offset": "0x0200", "data_words": [10]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0202", "data_words": [15]}
                    ]
                }
            }
        ]
    },
    {
        "id": "ASM8086-VARINT-42",
        "folder": "42_varint_protobuf_decoder",
        "category": "category_05_bit_manipulation_codecs",
        "title": "Variable-Length Integer (LEB128/Varint) Decoder",
        "difficulty": "medium",
        "cycle_budget": 5000,
        "description": "Decode unsigned LEB128 Varint from DS:0200h. Write decoded 16-bit word to DS:0210h and number of bytes consumed to word DS:0212h.",
        "prompt": """# Task: Variable-Length Integer (LEB128/Varint) Decoder

## Problem Description
Decode unsigned LEB128/Protobuf Varint at DS:0200h:
For each byte:
  val |= (byte & 0x7F) << shift
  shift += 7
  if (byte & 0x80) == 0: break
Store decoded 16-bit value at DS:0210h.
Store count of bytes consumed at DS:0212h.
Exit via INT 21h (AH=4Ch).
""",
        "template": """BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
""",
        "solution": """BITS 16
ORG 100h

start:
    mov si, 0200h
    xor dx, dx           ; Decoded accumulator
    xor cx, cx           ; Shift amount
    xor bp, bp           ; Bytes consumed

decode_loop:
    mov al, [si]
    inc si
    inc bp

    ; extract 7 bits
    mov bl, al
    and bl, 7Fh
    xor bh, bh

    ; bl << cl
    push cx
    shl bx, cl
    pop cx
    or dx, bx

    add cl, 7
    test al, 80h
    jnz decode_loop

    mov [0210h], dx
    mov [0212h], bp

    mov ax, 4C00h
    int 21h
""",
        "test_cases": [
            {
                "id": "case_1_300",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 300 in varint: 0xAC, 0x02
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [0xAC, 0x02]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [300, 2]}
                    ]
                }
            },
            {
                "id": "case_2_single_byte",
                "initial_state": {
                    "registers": {"DS": "0x2000"},
                    "memory_patches": [
                        # 127 in varint: 0x7F
                        {"segment": "0x2000", "offset": "0x0200", "data_bytes": [0x7F]}
                    ]
                },
                "assertions": {
                    "memory": [
                        {"segment": "0x2000", "offset": "0x0210", "data_words": [127, 1]}
                    ]
                }
            }
        ]
    }
]
