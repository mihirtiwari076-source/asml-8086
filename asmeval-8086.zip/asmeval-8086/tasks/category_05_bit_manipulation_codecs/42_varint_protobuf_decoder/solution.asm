BITS 16
ORG 100h

start:
    mov si, 0200h
    xor dx, dx           ; Decoded accumulator
    xor cx, cx           ; Shift amount
    xor bp, bp           ; Bytes consumed

decode_loop:
    mov al, [si]
    inc si
    inc bp

    ; extract 7 bits
    mov bl, al
    and bl, 7Fh
    xor bh, bh

    ; bl << cl
    push cx
    shl bx, cl
    pop cx
    or dx, bx

    add cl, 7
    test al, 80h
    jnz decode_loop

    mov [0210h], dx
    mov [0212h], bp

    mov ax, 4C00h
    int 21h
