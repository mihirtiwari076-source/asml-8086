# Task: Variable-Length Integer (LEB128/Varint) Decoder

## Problem Description
Decode unsigned LEB128/Protobuf Varint at DS:0200h:
For each byte:
  val |= (byte & 0x7F) << shift
  shift += 7
  if (byte & 0x80) == 0: break
Store decoded 16-bit value at DS:0210h.
Store count of bytes consumed at DS:0212h.
Exit via INT 21h (AH=4Ch).
