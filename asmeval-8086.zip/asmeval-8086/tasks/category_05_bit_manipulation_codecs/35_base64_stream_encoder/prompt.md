# Task: 3-Byte to 4-Character Base64 Block Encoder

## Problem Description
Three raw bytes are located at DS:0200h (B0, B1, B2).
Encode them into 4 Base64 ASCII characters using alphabet:
'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
Write the 4 ASCII characters to DS:0250h.
Exit via INT 21h (AH=4Ch).
