BITS 16
ORG 100h

start:
    ; Load 3 bytes: b0, b1, b2
    mov al, [0200h]      ; b0
    mov ah, [0201h]      ; b1
    mov dl, [0202h]      ; b2

    ; Index 0: b0 >> 2 (top 6 bits of b0)
    mov bl, al
    shr bl, 2
    and bx, 003Fh
    call get_b64_char
    mov [0250h], al

    ; Index 1: ((b0 & 3) << 4) | (b1 >> 4)
    mov al, [0200h]
    and al, 3
    shl al, 4
    mov bl, ah
    shr bl, 4
    or al, bl
    mov bl, al
    and bx, 003Fh
    call get_b64_char
    mov [0251h], al

    ; Index 2: ((b1 & 0x0F) << 2) | (b2 >> 6)
    mov al, [0201h]
    and al, 0Fh
    shl al, 2
    mov bl, dl
    shr bl, 6
    or al, bl
    mov bl, al
    and bx, 003Fh
    call get_b64_char
    mov [0252h], al

    ; Index 3: b2 & 0x3F
    mov bl, dl
    and bx, 003Fh
    call get_b64_char
    mov [0253h], al

    mov ax, 4C00h
    int 21h

get_b64_char:
    ; Input: BX (0..63). Output: AL (ASCII char)
    mov al, [b64_table + bx]
    ret

b64_table:
    db 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
