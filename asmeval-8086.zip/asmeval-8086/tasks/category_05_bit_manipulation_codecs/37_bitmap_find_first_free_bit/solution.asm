BITS 16
ORG 100h

start:
    mov si, 0200h
    xor cx, cx           ; Byte offset 0..127

byte_scan:
    cmp cx, 128
    jae none_free

    mov al, [si]
    cmp al, 0FFh
    jne found_byte_with_zero

    inc si
    inc cx
    jmp byte_scan

found_byte_with_zero:
    ; Find which bit in AL is 0
    xor bx, bx           ; bit 0..7

bit_scan:
    test al, 1
    jz found_bit
    shr al, 1
    inc bx
    jmp bit_scan

found_bit:
    ; Total bit index = (cx * 8) + bx
    mov ax, cx
    shl ax, 3
    add ax, bx
    mov [02F0h], ax
    jmp done_bitmap

none_free:
    mov word [02F0h], 0FFFFh

done_bitmap:
    mov ax, 4C00h
    int 21h
