# Task: Bitmap Scan for First Free Bit

## Problem Description
128 bytes (1024 bits) bitmap at DS:0200h.
Find the first clear bit (0-bit).
Bit indexing:
- Bit 0 is bit 0 of byte 0
- Bit 7 is bit 7 of byte 0
- Bit 8 is bit 0 of byte 1, etc.
Store the 0-based bit index (16-bit word) at DS:02F0h (or 0xFFFF if all bits are 1).
Exit via INT 21h (AH=4Ch).
