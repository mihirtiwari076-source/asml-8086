BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; N
    mov si, 0200h
    xor dx, dx           ; Total 1-bits counter
    jcxz done_popcnt

word_loop:
    mov ax, [si]
    add si, 2

bit_loop:
    cmp ax, 0
    je next_word
    ; Brian Kernighan bit trick: ax &= (ax - 1) clears lowest set bit
    mov bx, ax
    dec bx
    and ax, bx
    inc dx
    jmp bit_loop

next_word:
    loop word_loop

done_popcnt:
    mov [02F0h], dx
    mov ax, 4C00h
    int 21h
