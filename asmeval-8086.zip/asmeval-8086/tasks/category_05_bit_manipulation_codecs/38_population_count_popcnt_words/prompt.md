# Task: Population Count Across Word Array

## Problem Description
Array of N 16-bit words at DS:0200h (N from DS:01FEh).
Count the total number of bits set to 1 across the entire array.
Store the 16-bit count at DS:02F0h.
Exit via INT 21h (AH=4Ch).
