BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; Gray code

    ; B = G ^ (G >> 1) ^ (G >> 2) ^ ...
    mov bx, ax
    shr bx, 1
    xor ax, bx

    mov bx, ax
    shr bx, 2
    xor ax, bx

    mov bx, ax
    shr bx, 4
    xor ax, bx

    mov bx, ax
    shr bx, 8
    xor ax, bx

    mov [0202h], ax
    mov ax, 4C00h
    int 21h
