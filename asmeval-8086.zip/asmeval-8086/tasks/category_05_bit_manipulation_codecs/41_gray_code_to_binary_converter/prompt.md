# Task: Gray Code to Binary Converter

## Problem Description
Load 16-bit Gray code value from DS:0200h.
Convert it to standard binary:
while (shift > 0):
  val ^= (val >> shift)
Store the 16-bit binary result at DS:0202h.
Exit via INT 21h (AH=4Ch).
