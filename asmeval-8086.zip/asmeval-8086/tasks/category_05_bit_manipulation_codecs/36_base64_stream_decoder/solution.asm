BITS 16
ORG 100h

start:
    ; Decode char 0
    mov al, [0200h]
    call decode_char
    mov [0210h], al      ; idx0

    ; Decode char 1
    mov al, [0201h]
    call decode_char
    mov [0211h], al      ; idx1

    ; Decode char 2
    mov al, [0202h]
    call decode_char
    mov [0212h], al      ; idx2

    ; Decode char 3
    mov al, [0203h]
    call decode_char
    mov [0213h], al      ; idx3

    ; Byte 0: (idx0 << 2) | (idx1 >> 4)
    mov al, [0210h]
    shl al, 2
    mov bl, [0211h]
    shr bl, 4
    or al, bl
    mov [0250h], al

    ; Byte 1: ((idx1 & 0x0F) << 4) | (idx2 >> 2)
    mov al, [0211h]
    and al, 0Fh
    shl al, 4
    mov bl, [0212h]
    shr bl, 2
    or al, bl
    mov [0251h], al

    ; Byte 2: ((idx2 & 3) << 6) | idx3
    mov al, [0212h]
    and al, 3
    shl al, 6
    mov bl, [0213h]
    or al, bl
    mov [0252h], al

    mov ax, 4C00h
    int 21h

decode_char:
    cmp al, 'A'
    jb check_digits
    cmp al, 'Z'
    ja check_lower
    sub al, 'A'
    ret
check_lower:
    cmp al, 'a'
    jb check_plus
    cmp al, 'z'
    ja check_plus
    sub al, 'a'
    add al, 26
    ret
check_digits:
    cmp al, '0'
    jb check_plus
    cmp al, '9'
    ja check_plus
    sub al, '0'
    add al, 52
    ret
check_plus:
    cmp al, '+'
    jne is_slash
    mov al, 62
    ret
is_slash:
    mov al, 63
    ret
