# Task: 4-Character to 3-Byte Base64 Block Decoder

## Problem Description
Four Base64 ASCII characters are located at DS:0200h.
Decode them back into 3 raw bytes:
- Byte 0: (idx0 << 2) | (idx1 >> 4)
- Byte 1: ((idx1 & 0xF) << 4) | (idx2 >> 2)
- Byte 2: ((idx2 & 3) << 6) | idx3
Write the 3 raw bytes to DS:0250h.
Exit via INT 21h (AH=4Ch).
