BITS 16
ORG 100h

start:
    mov ax, [0200h]
    xor bx, bx           ; Result
    mov cx, 16

rev_bit_loop:
    shr ax, 1            ; Shift LSB into CF
    rcl bx, 1            ; Shift CF into LSB of BX (will end up at MSB)
    loop rev_bit_loop

    mov [0202h], bx
    mov ax, 4C00h
    int 21h
