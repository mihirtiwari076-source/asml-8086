# Task: 16-Bit Word Bit Reversal

## Problem Description
Load 16-bit word from DS:0200h.
Reverse its bit order so that MSB becomes LSB and LSB becomes MSB.
Store the 16-bit reversed word at DS:0202h.
Exit via INT 21h (AH=4Ch).
