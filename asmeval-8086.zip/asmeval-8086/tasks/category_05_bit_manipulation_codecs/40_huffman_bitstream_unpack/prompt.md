# Task: Huffman Bitstream Prefix Code Unpack

## Problem Description
Decode prefix bitstream starting at DS:0200h (MSB first within each byte).
Prefix code table:
- '0'     -> 'A' (41h)
- '10'    -> 'B' (42h)
- '11'    -> 'C' (43h)
Number of symbols to decode is at DS:01FEh.
Write decoded characters sequentially to DS:0250h.
Exit via INT 21h (AH=4Ch).
