BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; Number of symbols
    mov si, 0200h        ; Input bitstream
    mov di, 0250h        ; Output buffer
    jcxz done_huff

    mov ah, [si]         ; Current byte
    inc si
    mov dl, 8            ; Bits remaining in AH

decode_symbol:
    ; Read next bit into CF
    call get_next_bit
    jnc symbol_a         ; Bit was 0 -> 'A'

    ; Bit was 1, read next bit
    call get_next_bit
    jnc symbol_b         ; '10' -> 'B'

symbol_c:                ; '11' -> 'C'
    mov byte [di], 'C'
    inc di
    loop decode_symbol
    jmp done_huff

symbol_b:
    mov byte [di], 'B'
    inc di
    loop decode_symbol
    jmp done_huff

symbol_a:
    mov byte [di], 'A'
    inc di
    loop decode_symbol

done_huff:
    mov ax, 4C00h
    int 21h

get_next_bit:
    ; Shifts MSB of AH into CF. Refills from [SI] if empty.
    cmp dl, 0
    jne do_shift
    mov ah, [si]
    inc si
    mov dl, 8
do_shift:
    shl ah, 1
    dec dl
    ret
