# Task: Unpacked BCD Multiplication with AAM

## Problem Description
Read two 1-byte unpacked BCD digits from DS:0200h and DS:0201h.
Multiply them using MUL, adjust the product into unpacked BCD using AAM,
and store the 2-digit result at DS:0202h (low digit) and DS:0203h (high digit).
Exit via INT 21h (AH=4Ch).
