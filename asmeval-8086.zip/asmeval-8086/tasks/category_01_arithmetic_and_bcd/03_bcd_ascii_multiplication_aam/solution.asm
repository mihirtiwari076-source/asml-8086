BITS 16
ORG 100h

start:
    mov al, [0200h]
    mov bl, [0201h]
    mul bl
    aam
    mov [0202h], al
    mov [0203h], ah
    mov ax, 4C00h
    int 21h
