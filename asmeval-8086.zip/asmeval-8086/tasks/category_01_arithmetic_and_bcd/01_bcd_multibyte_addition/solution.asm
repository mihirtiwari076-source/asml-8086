BITS 16
ORG 100h

start:
    cld
    mov si, 0200h
    mov di, 0204h
    mov bx, 0208h
    mov cx, 4
    clc

bcd_loop:
    mov al, [si]
    adc al, [di]
    daa
    mov [bx], al
    inc si
    inc di
    inc bx
    loop bcd_loop

    mov al, 0
    adc al, 0
    mov [020Ch], al

    cmp al, 1
    je set_c
    clc
    jmp done
set_c:
    stc
done:
    mov ax, 4C00h
    int 21h
