BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    mov ax, 4C00h
    int 21h
