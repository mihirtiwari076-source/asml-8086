# Task: Multi-Byte Packed BCD Addition in 8086 Real Mode

## Problem Description
Implement a 16-bit Intel 8086 assembly program that performs multi-byte packed Binary-Coded Decimal (BCD) addition.

### Specifications:
- Operand A: 4 bytes located at DS:0200h (little-endian byte order).
- Operand B: 4 bytes located at DS:0204h.
- Result Buffer: Store the 4-byte packed BCD result at DS:0208h.
- Carry-Out: Store the final carry out (00h or 01h) as a single byte at DS:020Ch.
- Terminate via DOS INT 21h (AH=4Ch) or HLT.
