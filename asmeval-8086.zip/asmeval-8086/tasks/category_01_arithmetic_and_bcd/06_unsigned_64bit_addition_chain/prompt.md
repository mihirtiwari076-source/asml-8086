# Task: Unsigned 64-bit Addition Chain

## Problem Description
Add 64-bit Operand A at DS:0200h (4 words) and Operand B at DS:0208h (4 words).
Write the 4-word sum to DS:0210h.
Write the carry out (01h or 00h) to byte DS:0218h.
Exit via INT 21h (AH=4Ch).
