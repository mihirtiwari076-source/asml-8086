BITS 16
ORG 100h

start:
    mov si, 0200h
    mov di, 0208h
    mov bx, 0210h

    mov ax, [si]
    add ax, [di]
    mov [bx], ax

    mov ax, [si+2]
    adc ax, [di+2]
    mov [bx+2], ax

    mov ax, [si+4]
    adc ax, [di+4]
    mov [bx+4], ax

    mov ax, [si+6]
    adc ax, [di+6]
    mov [bx+6], ax

    mov al, 0
    adc al, 0
    mov [0218h], al

    mov ax, 4C00h
    int 21h
