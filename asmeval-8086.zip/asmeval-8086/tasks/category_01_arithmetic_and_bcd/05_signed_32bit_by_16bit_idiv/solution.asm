BITS 16
ORG 100h

start:
    mov ax, [0200h]
    mov dx, [0202h]
    mov bx, [0204h]
    idiv bx
    mov [0206h], ax
    mov [0208h], dx
    mov ax, 4C00h
    int 21h
