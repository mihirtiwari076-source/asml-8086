# Task: Signed 32-bit by 16-bit Division

## Problem Description
Load low word of dividend from DS:0200h into AX, high word from DS:0202h into DX.
Load 16-bit signed divisor from DS:0204h into BX.
Execute IDIV BX.
Store signed 16-bit quotient into DS:0206h and signed 16-bit remainder into DS:0208h.
Exit via INT 21h (AH=4Ch).
