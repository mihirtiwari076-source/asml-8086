# Task: Multi-Byte Packed BCD Subtraction

## Problem Description
Compute Minuend - Subtrahend for 4-byte packed BCD numbers at DS:0200h and DS:0204h.
Write the 4-byte difference to DS:0208h and borrow (01h if borrow out, else 00h) to DS:020Ch.
Use the DAS instruction. Terminate with INT 21h (AH=4Ch).
