# Task: Polynomial Evaluation via Horner's Rule

## Problem Description
Evaluate polynomial P(x) = (...(a_N * x + a_{N-1}) * x + ...) + a_0.
- Degree N (word) at DS:0200h
- Value x (word) at DS:0202h
- Coefficients (N+1 words) starting at DS:0204h from highest degree a_N down to a_0.
Store resulting 16-bit word at DS:0220h.
Exit via INT 21h (AH=4Ch).
