BITS 16
ORG 100h

start:
    mov cx, [0200h]      ; N
    mov bx, [0202h]      ; x
    mov si, 0204h        ; Pointer to coeffs

    mov ax, [si]         ; Accumulator = a_N
    add si, 2
    jcxz done_horner

horner_loop:
    mul bx               ; DX:AX = Accumulator * x
    add ax, [si]         ; Accumulator += a_{i}
    add si, 2
    loop horner_loop

done_horner:
    mov [0220h], ax
    mov ax, 4C00h
    int 21h
