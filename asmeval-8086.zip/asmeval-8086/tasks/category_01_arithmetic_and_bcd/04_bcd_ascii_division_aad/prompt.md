# Task: Unpacked BCD Division with AAD

## Problem Description
Load high digit into AH from DS:0201h and low digit into AL from DS:0200h.
Load divisor into BL from DS:0202h.
Use AAD to convert AH:AL into binary, execute DIV BL, and store:
- Quotient byte at DS:0203h
- Remainder byte at DS:0204h
Exit via INT 21h (AH=4Ch).
