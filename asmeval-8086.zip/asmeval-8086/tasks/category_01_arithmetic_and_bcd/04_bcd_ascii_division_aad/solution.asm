BITS 16
ORG 100h

start:
    mov al, [0200h]
    mov ah, [0201h]
    mov bl, [0202h]
    aad
    div bl
    mov [0203h], al
    mov [0204h], ah
    mov ax, 4C00h
    int 21h
