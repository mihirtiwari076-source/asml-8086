BITS 16
ORG 100h

start:
    mov ax, [0200h]
    mov bx, [0202h]
    imul bx
    ; Rescale (DX:AX) >> 8 into AX
    mov al, ah
    mov ah, dl
    mov [0204h], ax
    mov ax, 4C00h
    int 21h
