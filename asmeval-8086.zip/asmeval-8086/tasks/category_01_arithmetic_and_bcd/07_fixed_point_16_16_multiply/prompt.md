# Task: Signed Q8.8 Fixed-Point Multiplication

## Problem Description
Load signed 16-bit Q8.8 values from DS:0200h and DS:0202h.
Multiply with IMUL to yield a 32-bit product in DX:AX.
Shift DX:AX right by 8 bits to rescale back to Q8.8 format:
(AX = (DX << 8) | (AX >> 8)).
Store the 16-bit Q8.8 result at DS:0204h.
Exit via INT 21h (AH=4Ch).
