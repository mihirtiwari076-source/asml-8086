BITS 16
ORG 100h

start:
    ; Save active SP and BP
    mov [0200h], sp
    mov [0202h], bp

    ; Load new SP and BP
    mov sp, [0204h]
    mov bp, [0206h]

    ; Push 0xCAFE to new stack
    mov ax, 0CAFEh
    push ax

    mov ax, 4C00h
    int 21h
