# Task: Cooperative Coroutine Stack Switcher

## Problem Description
Save current task's context (SP and BP) into DS:0200h (SP at 0200h, BP at 0202h).
Load next task's context from DS:0204h (new SP from 0204h, new BP from 0206h).
After loading the new stack pointers, write 0xCAFE to the top of the new stack ([SS:SP]).
Exit via INT 21h (AH=4Ch).
