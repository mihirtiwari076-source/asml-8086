BITS 16
ORG 100h

start:
    mov cx, [01FCh]      ; N entries
    mov dx, [01FEh]      ; Delta
    mov si, 0200h        ; Reloc table
    jcxz done_reloc

reloc_loop:
    mov di, [si]         ; Target offset
    mov ax, [si + 2]     ; Target segment delta
    add si, 4

    ; Calculate target segment = DS + AX
    mov bx, ds
    add ax, bx
    mov es, ax

    ; Apply fixup: ES:[DI] += DX
    mov ax, es:[di]
    add ax, dx
    mov es:[di], ax

    loop reloc_loop

done_reloc:
    mov ax, 4C00h
    int 21h
