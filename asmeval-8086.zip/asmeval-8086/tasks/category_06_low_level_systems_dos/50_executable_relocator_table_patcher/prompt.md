# Task: DOS MZ Executable Relocation Table Fixup Patcher

## Problem Description
Relocation table starts at DS:0200h with N entries (word at DS:01FCh).
Base segment delta DX is at DS:01FEh.
Each relocation entry is 4 bytes:
- Word 0 (+0): Offset of word to fix up
- Word 1 (+2): Segment offset relative to DS
For each relocation entry:
  Fixup physical location is segment (DS + target_seg_delta), offset target_offset.
  Add delta DX to the 16-bit word at that location.
Exit via INT 21h (AH=4Ch).
