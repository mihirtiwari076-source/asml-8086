BITS 16
ORG 100h

start:
    ; 1. LBA / SPT -> Quotient in AX, Remainder in DX
    mov ax, [0200h]      ; LBA low
    mov dx, [0202h]      ; LBA high
    mov bx, [0204h]      ; SPT
    div bx

    ; Sector = remainder + 1
    inc dl
    mov [0213h], dl      ; Save Sector byte

    ; 2. Temp (AX) / HPC -> Quotient in AX (Cylinder), Remainder in DX (Head)
    xor dx, dx
    mov bx, [0206h]      ; HPC
    div bx

    mov [0210h], ax      ; Save Cylinder word
    mov [0212h], dl      ; Save Head byte

    mov ax, 4C00h
    int 21h
