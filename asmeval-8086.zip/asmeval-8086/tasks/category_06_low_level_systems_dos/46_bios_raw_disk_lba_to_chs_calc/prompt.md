# Task: Disk LBA to CHS Converter

## Problem Description
Convert 32-bit LBA at DS:0200h to CHS:
- LBA: low word at DS:0200h, high word at DS:0202h
- SPT (Sectors Per Track): word at DS:0204h
- HPC (Heads Per Cylinder): word at DS:0206h
Formulas:
- Sector S = (LBA % SPT) + 1
- Temp = LBA / SPT
- Head H = Temp % HPC
- Cylinder C = Temp / HPC
Store:
- Cylinder (16-bit word) at DS:0210h
- Head (8-bit byte) at DS:0212h
- Sector (8-bit byte) at DS:0213h
Exit via INT 21h (AH=4Ch).
