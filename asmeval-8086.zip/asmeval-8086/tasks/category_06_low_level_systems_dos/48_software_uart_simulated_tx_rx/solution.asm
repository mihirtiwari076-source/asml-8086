BITS 16
ORG 100h

start:
    mov al, [0200h]      ; Data byte
    mov di, 0210h

    ; 1. Start bit = 0
    mov byte [di], 0
    inc di

    ; 2. 8 data bits (LSB first)
    mov cx, 8
bit_loop:
    mov bl, al
    and bl, 1
    mov [di], bl
    inc di
    shr al, 1
    loop bit_loop

    ; 3. Stop bit = 1
    mov byte [di], 1

    mov ax, 4C00h
    int 21h
