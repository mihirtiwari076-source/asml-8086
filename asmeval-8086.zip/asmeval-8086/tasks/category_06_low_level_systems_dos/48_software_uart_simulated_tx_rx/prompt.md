# Task: Software UART 10-Bit Frame Generator

## Problem Description
Load byte to transmit from DS:0200h.
Generate standard 10-bit asynchronous serial frame:
- Bit 0: Start bit = 0
- Bits 1..8: 8 data bits (LSB first)
- Bit 9: Stop bit = 1
Write each of the 10 bits as individual bytes (00h or 01h) sequentially to DS:0210h..DS:0219h.
Exit via INT 21h (AH=4Ch).
