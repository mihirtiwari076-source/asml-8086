# Task: Cross-Segment Block Transfer

## Problem Description
Descriptor table at DS:0200h (five 16-bit words):
- +0: Byte count CX
- +2: Source segment
- +4: Source offset
- +6: Destination segment
- +8: Destination offset
Copy CX bytes from Source Segment:Offset to Destination Segment:Offset.
Exit via INT 21h (AH=4Ch).
