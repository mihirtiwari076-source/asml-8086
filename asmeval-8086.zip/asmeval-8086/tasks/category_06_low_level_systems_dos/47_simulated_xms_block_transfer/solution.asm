BITS 16
ORG 100h

start:
    mov cx, [0200h]      ; Byte count
    mov ax, [0202h]      ; src_seg
    mov si, [0204h]      ; src_off
    mov dx, [0206h]      ; dst_seg
    mov di, [0208h]      ; dst_off

    mov ds, ax
    mov es, dx
    cld
    rep movsb

    ; Restore DS to 2000h before exit
    mov ax, 2000h
    mov ds, ax
    mov ax, 4C00h
    int 21h
