BITS 16
ORG 100h

start:
    mov al, [01FDh]      ; Vector
    xor ah, ah
    shl ax, 2            ; Vector * 4 (offset in segment 0000h)
    mov bx, ax

    ; Read old IVT entry from 0000h:BX
    push ds
    xor ax, ax
    mov ds, ax
    mov si, [bx]         ; Old offset
    mov di, [bx + 2]     ; Old segment
    pop ds

    ; Save old ISR to DS:0200h
    mov [0200h], si
    mov [0202h], di

    ; Load new ISR
    mov si, [01FAh]      ; New offset
    mov di, [01F8h]      ; New segment

    ; Write new ISR into 0000h:BX
    push ds
    xor ax, ax
    mov ds, ax
    mov [bx], si
    mov [bx + 2], di
    pop ds

    mov ax, 4C00h
    int 21h
