# Task: Interrupt Vector Table Hooking

## Problem Description
Read target vector number (0..255) from byte DS:01FDh.
Read new ISR address: offset at word DS:01FAh, segment at word DS:01F8h.
The Real Mode IVT begins at 0000:0000h (each entry is 4 bytes: word offset, word segment).
1. Read existing IVT entry for vector and write it to DS:0200h (offset at 0200h, segment at 0202h).
2. Install new ISR pointer into the IVT table at 0000:(vector*4).
Exit via INT 21h (AH=4Ch).
