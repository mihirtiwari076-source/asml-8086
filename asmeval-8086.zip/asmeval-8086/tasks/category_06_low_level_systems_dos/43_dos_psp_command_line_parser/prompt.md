# Task: DOS PSP Command Line Argument Parser

## Problem Description
DOS PSP command tail is located at DS:0080h:
- Byte 0080h: Character length L (0..127)
- Bytes 0081h..: Command tail ASCII text
Parse the command line by splitting on spaces (ASCII 20h).
Copy each token as a null-terminated string sequentially into DS:0200h.
Store the total number of parsed tokens as a 16-bit word at DS:01FEh.
Exit via INT 21h (AH=4Ch).
