BITS 16
ORG 100h

start:
    mov cl, [0080h]      ; Length of command tail
    xor ch, ch
    mov si, 0081h
    mov di, 0200h
    xor bp, bp           ; Token count
    jcxz done_parse

parse_loop:
    ; Skip spaces
    cmp cx, 0
    je done_parse
    mov al, [si]
    cmp al, ' '
    jne in_token
    inc si
    dec cx
    jmp parse_loop

in_token:
    ; Found start of a token!
    inc bp

copy_token:
    mov al, [si]
    inc si
    dec cx
    cmp al, ' '
    je end_token
    cmp al, 0Dh          ; Carriage return at end
    je end_token
    mov [di], al
    inc di
    cmp cx, 0
    jne copy_token

end_token:
    mov byte [di], 0     ; Null terminate token
    inc di
    cmp cx, 0
    jne parse_loop

done_parse:
    mov [01FEh], bp
    mov ax, 4C00h
    int 21h
