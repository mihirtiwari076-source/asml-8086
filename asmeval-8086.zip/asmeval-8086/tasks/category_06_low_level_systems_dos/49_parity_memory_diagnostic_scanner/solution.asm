BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; N
    mov si, 0300h
    jcxz pass_diag

diag_loop:
    ; Pattern 1: 55AAh
    mov word [si], 55AAh
    cmp word [si], 55AAh
    jne fail_diag

    ; Pattern 2: AA55h
    mov word [si], 0AA55h
    cmp word [si], 0AA55h
    jne fail_diag

    ; Clean up
    mov word [si], 0000h

    add si, 2
    loop diag_loop

pass_diag:
    mov word [02F0h], 1
    mov ax, 4C00h
    int 21h

fail_diag:
    mov word [02F0h], 0
    mov ax, 4C00h
    int 21h
