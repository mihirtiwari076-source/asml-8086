# Task: RAM Alternating Pattern Diagnostic Scanner

## Problem Description
Memory test region is at DS:0300h of length N words (from DS:01FEh).
For each word:
1. Write 55AAh and verify immediately. If mismatch -> fail.
2. Write AA55h and verify immediately. If mismatch -> fail.
3. Write 0000h to clean up.
If all words pass, write 0001h to DS:02F0h (AX=1).
If any word fails, write 0000h to DS:02F0h (AX=0).
Exit via INT 21h (AH=4Ch).
