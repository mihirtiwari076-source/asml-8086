# Task: In-Place String Reversal in Real Mode Memory

## Problem Description
Reverse a null-terminated ASCII string starting at DS:0200h in-place.
The null terminator (00h) must remain at its ending position.
Ensure ZF = 1 upon completion.
Exit via INT 21h (AH=4Ch).
