BITS 16
ORG 100h

start:
    mov si, 0200h
    mov di, si

find_end:
    cmp byte [di], 0
    je found_end
    inc di
    jmp find_end

found_end:
    cmp di, si
    jbe done_reverse
    dec di

reverse_loop:
    cmp si, di
    jae done_reverse
    mov al, [si]
    mov bl, [di]
    mov [si], bl
    mov [di], al
    inc si
    dec di
    jmp reverse_loop

done_reverse:
    xor cx, cx
    mov ax, 4C00h
    int 21h
