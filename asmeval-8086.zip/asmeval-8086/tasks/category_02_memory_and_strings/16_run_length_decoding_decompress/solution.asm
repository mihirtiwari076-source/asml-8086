BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; Compressed bytes count
    mov si, 0200h
    mov di, 0300h
    xor bp, bp           ; Decompressed count
    jcxz done_dec

dec_loop:
    mov bl, [si]         ; Count
    mov al, [si+1]       ; Byte
    add si, 2
    sub cx, 2

expand_run:
    cmp bl, 0
    je next_packet
    mov [di], al
    inc di
    inc bp
    dec bl
    jmp expand_run

next_packet:
    cmp cx, 0
    jne dec_loop

done_dec:
    mov [02FEh], bp
    mov ax, 4C00h
    int 21h
