# Task: Run-Length Decoding Decompress

## Problem Description
Input is an array of [count: byte, value: byte] pairs at DS:0200h. Total input length in bytes is at DS:01FEh.
Decompress by repeating each byte according to count, writing output stream to DS:0300h.
Write total decompressed length (words) to DS:02FEh.
Exit via INT 21h (AH=4Ch).
