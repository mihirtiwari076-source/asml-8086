BITS 16
ORG 100h

start:
    cld
    mov di, 0200h
    mov cx, [01FEh]
    mov al, [01FDh]
    xor dx, dx           ; Token count
    xor bx, bx           ; In-token flag (0 = outside, 1 = inside)
    jcxz save_count

scan_loop:
    mov ah, es:[di]
    inc di
    cmp ah, al
    je is_delim

    ; In token
    cmp bx, 0
    jne continue_scan
    inc dx               ; New token started
    mov bx, 1
    jmp continue_scan

is_delim:
    mov bx, 0            ; Left token

continue_scan:
    loop scan_loop

save_count:
    mov [02E0h], dx
    mov ax, 4C00h
    int 21h
