# Task: String Token Counting via SCASB

## Problem Description
Buffer at ES:0200h of length CX (from DS:01FEh).
Delimiter byte in AL from DS:01FDh.
Count non-empty tokens separated by the delimiter.
Store the token count as a 16-bit word at DS:02E0h.
Exit via INT 21h (AH=4Ch).
