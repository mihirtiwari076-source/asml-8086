BITS 16
ORG 100h

start:
    mov al, [01FCh]      ; Target byte
    mov bl, [01FDh]      ; Replacement byte
    mov cx, [01FEh]      ; Length
    mov si, 0200h
    xor dx, dx           ; Count
    jcxz done_replace

rep_loop:
    cmp [si], al
    jne skip_rep
    mov [si], bl
    inc dx
skip_rep:
    inc si
    loop rep_loop

done_replace:
    mov [02E0h], dx
    mov ax, 4C00h
    int 21h
