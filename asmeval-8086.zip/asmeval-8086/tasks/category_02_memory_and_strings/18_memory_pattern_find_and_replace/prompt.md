# Task: Byte Pattern Find and Replace

## Problem Description
Target byte is at DS:01FCh, replacement byte is at DS:01FDh. Buffer length CX is at DS:01FEh.
Scan buffer at DS:0200h and replace every match of target with replacement byte.
Store the total count of replaced bytes in word at DS:02E0h.
Exit via INT 21h (AH=4Ch).
