BITS 16
ORG 100h

start:
    mov cx, [01FCh]      ; Haystack len
    mov dx, [01FEh]      ; Needle len
    cmp dx, cx
    ja not_found
    cmp dx, 0
    je not_found

    ; Max index = Haystack len - Needle len
    mov bp, cx
    sub bp, dx           ; BP = max index

    xor bx, bx           ; i = 0

outer_scan:
    cmp bx, bp
    ja not_found

    ; Compare needle with haystack at i
    push bx
    mov si, 0280h        ; Needle
    mov di, 0200h
    add di, bx           ; Haystack + i
    mov cx, dx           ; compare len bytes
    cld

inner_cmp:
    mov al, [si]
    mov ah, [di]
    inc si
    inc di
    cmp al, ah
    jne mismatch
    loop inner_cmp

    ; Match found!
    pop bx
    mov [02F0h], bx
    jmp finish_search

mismatch:
    pop bx
    inc bx
    jmp outer_scan

not_found:
    mov word [02F0h], 0FFFFh

finish_search:
    mov ax, 4C00h
    int 21h
