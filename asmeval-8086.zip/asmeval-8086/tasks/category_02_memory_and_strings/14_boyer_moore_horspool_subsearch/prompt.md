# Task: Substring Search in Memory Buffer

## Problem Description
Haystack is at DS:0200h with length at DS:01FCh.
Needle is at DS:0280h with length at DS:01FEh.
Find the first 0-based offset of Needle in Haystack.
Store the 16-bit offset into DS:02F0h (or 0xFFFF if not found).
Exit via INT 21h (AH=4Ch).
