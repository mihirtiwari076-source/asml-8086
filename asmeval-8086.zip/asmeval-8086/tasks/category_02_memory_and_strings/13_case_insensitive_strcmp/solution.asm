BITS 16
ORG 100h

start:
    mov si, 0200h
    mov di, 0250h

compare_loop:
    mov al, [si]
    mov bl, [di]
    inc si
    inc di

    ; Convert al to uppercase
    cmp al, 'a'
    jb check_bl
    cmp al, 'z'
    ja check_bl
    sub al, 32

check_bl:
    cmp bl, 'a'
    jb do_compare
    cmp bl, 'z'
    ja do_compare
    sub bl, 32

do_compare:
    cmp al, bl
    jb str1_less
    ja str1_greater
    cmp al, 0
    je strings_equal
    jmp compare_loop

strings_equal:
    xor ax, ax           ; AX = 0, ZF = 1
    jmp done_cmp

str1_less:
    mov ax, 0FFFFh
    or al, 1             ; ZF = 0
    mov ax, 0FFFFh
    jmp done_cmp

str1_greater:
    mov ax, 1
    or al, 1             ; ZF = 0
    mov ax, 1

done_cmp:
    mov [02F0h], ax
    mov ax, 4C00h
    int 21h
