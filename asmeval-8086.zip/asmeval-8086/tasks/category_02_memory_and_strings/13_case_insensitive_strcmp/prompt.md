# Task: Case-Insensitive String Comparison

## Problem Description
Compare String 1 at DS:0200h and String 2 at DS:0250h (both null-terminated).
Convert lowercase characters ('a'-'z') to uppercase before comparing.
- If equal: AX = 0, ZF = 1
- If Str1 > Str2: AX = 1, ZF = 0
- If Str1 < Str2: AX = 0xFFFF, ZF = 0
Store result word into DS:02F0h.
Exit via INT 21h (AH=4Ch).
