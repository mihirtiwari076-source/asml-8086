BITS 16
ORG 100h

start:
    cld
    mov si, 0200h
    mov di, si
    xor bl, bl           ; Space seen flag (0 = false, 1 = true)

compress_loop:
    lodsb
    cmp al, 0
    je finish_compress

    cmp al, 20h
    jne not_space

    ; Char is space
    cmp bl, 1
    je skip_char         ; Duplicate space, do not copy
    stosb
    mov bl, 1
    jmp compress_loop

not_space:
    stosb
    mov bl, 0
    jmp compress_loop

skip_char:
    jmp compress_loop

finish_compress:
    stosb                ; Write null terminator
    mov ax, 4C00h
    int 21h
