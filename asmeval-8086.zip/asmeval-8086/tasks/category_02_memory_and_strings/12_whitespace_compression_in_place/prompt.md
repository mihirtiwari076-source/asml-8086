# Task: In-Place Whitespace Compression

## Problem Description
Compress runs of consecutive spaces (' ', 20h) into a single space in the null-terminated string starting at DS:0200h.
The compressed string must be written in-place and terminated with 00h.
Exit via INT 21h (AH=4Ch).
