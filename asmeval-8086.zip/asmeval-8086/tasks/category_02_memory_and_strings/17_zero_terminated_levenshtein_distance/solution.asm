BITS 16
ORG 100h

; DP Table located at DS:0300h
; Row 0 initialized to 0, 1, 2, ... N
start:
    mov cx, [01FCh]      ; M (rows)
    mov dx, [01FEh]      ; N (cols)

    ; Initialize DP row 0: dp[0][j] = j
    mov di, 0300h
    xor ax, ax           ; j = 0
init_r0:
    mov [di], al
    inc di
    inc ax
    cmp ax, dx
    jbe init_r0

    ; For i = 1 to M:
    mov bp, 1            ; i = 1
outer_dp:
    cmp bp, cx
    ja done_dp

    ; Compute row i in buffer at 0320h
    mov di, 0320h
    mov ax, bp
    mov [di], al         ; dp[i][0] = i
    inc di

    ; j = 1 to N
    mov bx, 1            ; j = 1
inner_dp:
    cmp bx, dx
    ja copy_row

    ; cost = (s1[i-1] == s2[j-1]) ? 0 : 1
    mov si, 0200h
    add si, bp
    dec si
    mov al, [si]         ; s1[i-1]

    mov si, 0220h
    add si, bx
    dec si
    mov ah, [si]         ; s2[j-1]

    xor dl, dl
    cmp al, ah
    je no_sub_cost
    mov dl, 1            ; cost = 1
no_sub_cost:

    ; del_cost = prev_row[j] + 1
    mov si, 0300h
    add si, bx
    mov al, [si]
    inc al

    ; ins_cost = cur_row[j-1] + 1
    mov si, di
    dec si
    mov ah, [si]
    inc ah

    ; min(del_cost, ins_cost) in AL
    cmp ah, al
    jae not_ins_min
    mov al, ah
not_ins_min:

    ; sub_cost = prev_row[j-1] + cost
    mov si, 0300h
    add si, bx
    dec si
    mov ah, [si]
    add ah, dl

    ; min with sub_cost
    cmp ah, al
    jae not_sub_min
    mov al, ah
not_sub_min:

    mov [di], al
    inc di
    inc bx
    mov dx, [01FEh]      ; Restore N
    jmp inner_dp

copy_row:
    ; Copy 0320h to 0300h for next iteration
    push cx
    mov si, 0320h
    mov di, 0300h
    mov cx, dx
    inc cx
    cld
    rep movsb
    pop cx

    inc bp
    jmp outer_dp

done_dp:
    ; Result is at 0300h + N
    mov si, 0300h
    add si, dx
    mov al, [si]
    xor ah, ah
    mov [02F0h], ax
    mov ax, 4C00h
    int 21h
