# Task: Levenshtein Edit Distance Matrix

## Problem Description
String 1 is at DS:0200h with length M at DS:01FCh.
String 2 is at DS:0220h with length N at DS:01FEh.
Compute minimum edit distance (insert, delete, replace).
Store the distance as a 16-bit word at DS:02F0h.
Exit via INT 21h (AH=4Ch).
