BITS 16
ORG 100h

start:
    mov si, [01FEh]
    mov di, [01FCh]
    mov cx, [01FAh]
    jcxz done_move

    cmp di, si
    jbe forward_copy

    mov ax, si
    add ax, cx
    cmp di, ax
    jae forward_copy

backward_copy:
    add si, cx
    dec si
    add di, cx
    dec di
    std
    rep movsb
    cld
    jmp done_move

forward_copy:
    cld
    rep movsb

done_move:
    mov ax, 4C00h
    int 21h
