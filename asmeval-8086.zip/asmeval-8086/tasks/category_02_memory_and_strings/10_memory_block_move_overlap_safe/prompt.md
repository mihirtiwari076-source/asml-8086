# Task: Overlap-Safe Memory Block Transfer (Memmove)

## Problem Description
Source offset SI is at DS:01FEh, destination offset DI is at DS:01FCh, byte count CX is at DS:01FAh.
Copy CX bytes from DS:SI to ES:DI.
If DI > SI and DI < SI + CX, perform backward copy (STD).
Else perform forward copy (CLD).
Exit via INT 21h (AH=4Ch).
