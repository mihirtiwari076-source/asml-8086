BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; Input len
    mov si, 0200h        ; Input pointer
    mov di, 0300h        ; Output pointer
    xor bp, bp           ; Compressed size
    jcxz done_rle

rle_outer:
    mov al, [si]         ; Current byte
    mov bl, 1            ; Count = 1
    inc si
    dec cx
    jcxz write_packet

count_run:
    cmp [si], al
    jne write_packet
    cmp bl, 255
    je write_packet
    inc bl
    inc si
    loop count_run

write_packet:
    mov [di], bl
    mov [di+1], al
    add di, 2
    add bp, 2
    cmp cx, 0
    jne rle_outer

done_rle:
    mov [02FEh], bp
    mov ax, 4C00h
    int 21h
