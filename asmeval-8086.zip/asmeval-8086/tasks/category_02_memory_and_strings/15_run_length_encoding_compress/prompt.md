# Task: Run-Length Encoding Compression

## Problem Description
Input byte buffer at DS:0200h of length CX (from DS:01FEh).
Compress contiguous runs of identical bytes into [count: byte, value: byte] pairs at DS:0300h (maximum run count 255).
Store total compressed size in bytes at word DS:02FEh.
Exit via INT 21h (AH=4Ch).
