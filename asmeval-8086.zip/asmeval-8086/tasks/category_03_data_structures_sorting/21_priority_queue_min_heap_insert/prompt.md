# Task: Priority Queue Min-Heap Insertion

## Problem Description
Binary min-heap stored at DS:0200h (array of 16-bit words, 0-indexed).
Current element count N is at DS:01FEh.
New element X is at DS:01FCh.
Insert X at index N, bubble it up so that heap[parent] <= heap[child] for all nodes (where parent = (child - 1) / 2).
Update count at DS:01FEh to N + 1.
Exit via INT 21h (AH=4Ch).
