BITS 16
ORG 100h

start:
    mov cx, [01FEh]      ; N (insertion index)
    mov dx, [01FCh]      ; X

    ; Write X at index N
    mov bx, cx
    shl bx, 1
    mov [0200h + bx], dx

    ; Bubble up: current = N
    mov si, cx

bubble_up:
    cmp si, 0
    jle heap_done

    ; parent = (current - 1) / 2
    mov di, si
    dec di
    shr di, 1

    ; Compare heap[current] with heap[parent]
    mov bx, di
    shl bx, 1
    mov ax, [0200h + bx] ; heap[parent]

    cmp dx, ax           ; compare X with heap[parent]
    jae heap_done        ; if X >= parent, heap property satisfied

    ; Swap heap[current] and heap[parent]
    mov bp, si
    shl bp, 1
    mov [0200h + bp], ax
    mov [0200h + bx], dx

    mov si, di           ; current = parent
    jmp bubble_up

heap_done:
    inc word [01FEh]     ; N = N + 1
    mov ax, 4C00h
    int 21h
