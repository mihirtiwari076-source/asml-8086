# Task: Balanced Parentheses Stack Verifier

## Problem Description
Scan null-terminated string at DS:0200h containing brackets: (), [], {}.
Use the CPU stack to check for proper nesting and balance.
- If balanced: write 01h to byte DS:02E0h, AX = 1, ZF = 1.
- If unbalanced: write 00h to byte DS:02E0h, AX = 0, ZF = 0.
Exit via HLT.
