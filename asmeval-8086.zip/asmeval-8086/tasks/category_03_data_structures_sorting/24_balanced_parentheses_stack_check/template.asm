BITS 16
ORG 100h

start:
    ; YOUR CODE HERE
    hlt
