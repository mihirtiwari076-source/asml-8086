BITS 16
ORG 100h

start:
    mov bp, sp           ; Save original SP
    mov si, 0200h

scan_loop:
    mov al, [si]
    inc si
    cmp al, 0
    je end_string

    ; Check opening brackets
    cmp al, '('
    je push_bracket
    cmp al, '['
    je push_bracket
    cmp al, '{'
    je push_bracket

    ; Check closing brackets
    cmp al, ')'
    je pop_round
    cmp al, ']'
    je pop_square
    cmp al, '}'
    je pop_curly
    jmp scan_loop        ; Ignore other chars

push_bracket:
    xor ah, ah
    push ax
    jmp scan_loop

pop_round:
    cmp sp, bp
    je is_unbalanced
    pop dx
    cmp dl, '('
    jne is_unbalanced
    jmp scan_loop

pop_square:
    cmp sp, bp
    je is_unbalanced
    pop dx
    cmp dl, '['
    jne is_unbalanced
    jmp scan_loop

pop_curly:
    cmp sp, bp
    je is_unbalanced
    pop dx
    cmp dl, '{'
    jne is_unbalanced
    jmp scan_loop

end_string:
    cmp sp, bp
    jne is_unbalanced

is_balanced:
    mov sp, bp
    mov byte [02E0h], 1
    mov ax, 1
    xor bx, bx           ; ZF = 1
    hlt

is_unbalanced:
    mov sp, bp           ; Restore SP
    mov byte [02E0h], 0
    mov ax, 0
    or bl, 1             ; ZF = 0
    hlt
