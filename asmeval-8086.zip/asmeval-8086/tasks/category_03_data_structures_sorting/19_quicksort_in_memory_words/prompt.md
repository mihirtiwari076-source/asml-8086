# Task: In-Place Sorting of 16-Bit Words

## Problem Description
Sort an array of 16-bit unsigned integers in-place in ascending order.
- Array location: DS:0200h
- Element count: 16-bit word at DS:01FEh
Exit via INT 21h (AH=4Ch, AL=0).
