BITS 16
ORG 100h

start:
    mov cx, [01FEh]
    cmp cx, 1
    jbe sort_done

    dec cx

outer_loop:
    push cx
    mov si, 0200h

inner_loop:
    mov ax, [si]
    mov bx, [si + 2]
    cmp ax, bx
    jbe no_swap
    mov [si], bx
    mov [si + 2], ax
no_swap:
    add si, 2
    loop inner_loop

    pop cx
    loop outer_loop

sort_done:
    mov ax, 4C00h
    int 21h
