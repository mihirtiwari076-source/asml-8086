# Task: In-Place Singly Linked List Reversal

## Problem Description
Head offset of a singly linked list is at DS:01FEh.
Each node is 4 bytes:
- Word 0 (+0): Next node offset (or 0000h for NULL)
- Word 1 (+2): Data value
Reverse the list in-place (mutate the next pointers).
Write the new head node offset into DS:01FEh.
Exit via INT 21h (AH=4Ch).
