BITS 16
ORG 100h

start:
    mov bx, [01FEh]      ; curr = head
    xor dx, dx           ; prev = NULL

rev_loop:
    cmp bx, 0
    je done_rev

    mov si, [bx]         ; next = curr->next
    mov [bx], dx         ; curr->next = prev
    mov dx, bx           ; prev = curr
    mov bx, si           ; curr = next
    jmp rev_loop

done_rev:
    mov [01FEh], dx      ; head = prev
    mov ax, 4C00h
    int 21h
