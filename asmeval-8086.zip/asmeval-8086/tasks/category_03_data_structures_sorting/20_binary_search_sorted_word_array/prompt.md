# Task: Binary Search on Sorted Word Array

## Problem Description
Sorted word array at DS:0200h, count N at DS:01FEh, search key at DS:01FCh.
Perform binary search.
Store 0-based matching index into word DS:02F0h, or 0xFFFF if key is absent.
Exit via INT 21h (AH=4Ch).
