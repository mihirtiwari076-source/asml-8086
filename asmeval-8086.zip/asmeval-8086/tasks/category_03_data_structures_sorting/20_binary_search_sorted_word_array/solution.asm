BITS 16
ORG 100h

start:
    mov dx, [01FCh]      ; Key
    mov cx, [01FEh]      ; N
    jcxz not_found

    xor si, si           ; low = 0
    mov di, cx
    dec di               ; high = N - 1

bsearch_loop:
    cmp si, di
    ja not_found

    ; mid = (low + high) / 2
    mov bx, si
    add bx, di
    shr bx, 1            ; BX = mid

    ; load array[mid]
    mov bp, bx
    shl bp, 1            ; byte offset = mid * 2
    mov ax, [0200h + bp]

    cmp ax, dx
    je found
    jb search_right

    ; search left: high = mid - 1
    cmp bx, 0
    je not_found
    mov di, bx
    dec di
    jmp bsearch_loop

search_right:
    ; search right: low = mid + 1
    mov si, bx
    inc si
    jmp bsearch_loop

found:
    mov [02F0h], bx
    jmp done_bsearch

not_found:
    mov word [02F0h], 0FFFFh

done_bsearch:
    mov ax, 4C00h
    int 21h
