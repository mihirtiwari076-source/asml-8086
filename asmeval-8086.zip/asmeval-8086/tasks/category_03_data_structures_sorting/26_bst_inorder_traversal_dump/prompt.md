# Task: Binary Search Tree Inorder Traversal Dump

## Problem Description
A binary search tree has root offset at DS:01FEh.
Each node is 6 bytes:
- Offset +0: Left child node offset (0000h = null)
- Offset +2: Right child node offset (0000h = null)
- Offset +4: 16-bit key value
Perform an in-order traversal (left, current, right) using the stack.
Dump keys into sequential words at DS:0300h.
Store total dumped key count at DS:02FEh.
Exit via INT 21h (AH=4Ch).
