BITS 16
ORG 100h

start:
    mov di, 0300h        ; Output buffer
    xor bp, bp           ; Count
    mov bx, [01FEh]      ; Curr = root
    xor dx, dx           ; Stack sentinel = 0
    push dx

traverse_loop:
    cmp bx, 0
    je pop_and_visit

    ; Push curr, move to curr->left
    push bx
    mov bx, [bx]         ; curr = curr->left
    jmp traverse_loop

pop_and_visit:
    pop bx
    cmp bx, 0
    je done_bst

    ; Visit curr: write curr->key to [di]
    mov ax, [bx + 4]
    mov [di], ax
    add di, 2
    inc bp

    ; curr = curr->right
    mov bx, [bx + 2]
    jmp traverse_loop

done_bst:
    mov [02FEh], bp
    mov ax, 4C00h
    int 21h
