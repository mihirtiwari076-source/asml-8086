# Task: Circular FIFO Ring Buffer Enqueue

## Problem Description
Control block at DS:0200h:
- Word 0: Head index
- Word 1: Tail index
- Word 2: Capacity
- Word 3: Count
Data array starts at DS:0208h.
Word to enqueue is at DS:01FCh.
Store word at buffer[tail], update tail = (tail + 1) % capacity, and count = count + 1.
Exit via INT 21h (AH=4Ch).
