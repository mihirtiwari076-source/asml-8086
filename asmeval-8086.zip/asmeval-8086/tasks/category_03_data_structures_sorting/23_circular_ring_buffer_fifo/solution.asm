BITS 16
ORG 100h

start:
    mov dx, [01FCh]      ; Value to enqueue
    mov bx, [0202h]      ; Tail index
    mov cx, [0204h]      ; Capacity

    ; data[tail] = dx
    mov bp, bx
    shl bp, 1
    mov [0208h + bp], dx

    ; tail = (tail + 1) % capacity
    inc bx
    cmp bx, cx
    jb no_wrap
    xor bx, bx
no_wrap:
    mov [0202h], bx      ; Update tail

    ; count += 1
    inc word [0206h]

    mov ax, 4C00h
    int 21h
