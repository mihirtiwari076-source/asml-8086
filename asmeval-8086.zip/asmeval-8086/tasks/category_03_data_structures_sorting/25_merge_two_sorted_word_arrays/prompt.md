# Task: Merge Two Sorted Word Arrays

## Problem Description
Array A is at DS:0200h of length N1 (from DS:01FCh).
Array B is at DS:0240h of length N2 (from DS:01FEh).
Both arrays contain 16-bit unsigned integers in ascending order.
Merge them into DS:0300h in ascending order.
Exit via INT 21h (AH=4Ch).
