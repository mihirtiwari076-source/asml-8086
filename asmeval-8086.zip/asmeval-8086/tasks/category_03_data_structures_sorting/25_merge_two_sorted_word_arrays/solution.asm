BITS 16
ORG 100h

start:
    mov cx, [01FCh]      ; N1
    mov dx, [01FEh]      ; N2
    mov si, 0200h        ; A
    mov di, 0240h        ; B
    mov bx, 0300h        ; Out

merge_loop:
    cmp cx, 0
    je copy_remaining_b
    cmp dx, 0
    je copy_remaining_a

    mov ax, [si]
    mov bp, [di]
    cmp ax, bp
    jbe take_a

take_b:
    mov [bx], bp
    add di, 2
    dec dx
    add bx, 2
    jmp merge_loop

take_a:
    mov [bx], ax
    add si, 2
    dec cx
    add bx, 2
    jmp merge_loop

copy_remaining_a:
    cmp cx, 0
    je done_merge
    mov ax, [si]
    mov [bx], ax
    add si, 2
    add bx, 2
    dec cx
    jmp copy_remaining_a

copy_remaining_b:
    cmp dx, 0
    je done_merge
    mov ax, [di]
    mov [bx], ax
    add di, 2
    add bx, 2
    dec dx
    jmp copy_remaining_b

done_merge:
    mov ax, 4C00h
    int 21h
