# Task: ChaCha Quarter-Round 16-Bit Primitive

## Problem Description
Four 16-bit words at DS:0200h: a (+0), b (+2), c (+4), d (+6).
Perform operations:
1. a += b; d ^= a; d rol 8
2. c += d; b ^= c; b rol 7
3. a += b; d ^= a; d rol 8
4. c += d; b ^= c; b rol 7
Store updated words in-place at DS:0200h.
Exit via INT 21h (AH=4Ch).
