BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; a
    mov bx, [0202h]      ; b
    mov cx, [0204h]      ; c
    mov dx, [0206h]      ; d

    ; Step 1: a += b; d ^= a; d rol 8
    add ax, bx
    xor dx, ax
    rol dx, 8

    ; Step 2: c += d; b ^= c; b rol 7
    add cx, dx
    xor bx, cx
    rol bx, 7

    ; Step 3: a += b; d ^= a; d rol 8
    add ax, bx
    xor dx, ax
    rol dx, 8

    ; Step 4: c += d; b ^= c; b rol 7
    add cx, dx
    xor bx, cx
    rol bx, 7

    mov [0200h], ax
    mov [0202h], bx
    mov [0204h], cx
    mov [0206h], dx

    mov ax, 4C00h
    int 21h
