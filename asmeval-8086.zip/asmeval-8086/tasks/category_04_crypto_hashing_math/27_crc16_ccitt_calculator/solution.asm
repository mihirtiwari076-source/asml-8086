BITS 16
ORG 100h

start:
    mov ax, 0FFFFh
    mov si, 0200h
    mov cx, [01FEh]
    jcxz done_crc

byte_loop:
    mov bh, [si]
    mov bl, 0
    xor ax, bx

    mov dx, 8

bit_loop:
    test ax, 8000h
    jz shift_only
    shl ax, 1
    xor ax, 1021h
    jmp next_bit
shift_only:
    shl ax, 1
next_bit:
    dec dx
    jnz bit_loop

    inc si
    loop byte_loop

done_crc:
    mov [02F0h], ax
    mov ax, 4C00h
    int 21h
