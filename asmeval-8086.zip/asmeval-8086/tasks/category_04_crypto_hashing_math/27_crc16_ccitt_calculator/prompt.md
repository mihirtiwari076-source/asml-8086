# Task: CRC-16-CCITT Checksum Calculation

## Problem Description
Compute CRC-16-CCITT over buffer at DS:0200h (length word at DS:01FEh).
- Polynomial: 0x1021
- Initial CRC: 0xFFFF
Store the 16-bit CRC word at DS:02F0h.
Exit via INT 21h (AH=4Ch).
