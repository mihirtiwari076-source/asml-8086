# Task: Integer Square Root

## Problem Description
Unsigned 16-bit integer X is at DS:0200h.
Compute floor(sqrt(X)).
Store the resulting 16-bit word at DS:0202h.
Exit via INT 21h (AH=4Ch).
