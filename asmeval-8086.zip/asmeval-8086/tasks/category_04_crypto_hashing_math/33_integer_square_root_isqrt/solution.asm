BITS 16
ORG 100h

start:
    mov cx, [0200h]      ; X
    xor bx, bx           ; r = 0

isqrt_loop:
    mov ax, bx
    inc ax
    mul ax               ; DX:AX = (r+1)^2
    cmp dx, 0
    jne found_root
    cmp ax, cx
    ja found_root
    inc bx
    jmp isqrt_loop

found_root:
    mov [0202h], bx
    mov ax, 4C00h
    int 21h
