# Task: Modular Product Primitive

## Problem Description
Compute (A * B) mod M.
- A (16-bit word) at DS:0200h
- B (16-bit word) at DS:0202h
- M (16-bit word) at DS:0204h
Compute 32-bit product with MUL, then divide by M with DIV to obtain remainder.
Store remainder (16-bit word) at DS:0206h.
Exit via INT 21h (AH=4Ch).
