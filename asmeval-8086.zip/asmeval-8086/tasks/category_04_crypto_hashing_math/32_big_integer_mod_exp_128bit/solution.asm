BITS 16
ORG 100h

start:
    mov ax, [0200h]
    mov bx, [0202h]
    mul bx               ; DX:AX = A * B
    mov bx, [0204h]      ; M
    div bx               ; AX = quotient, DX = remainder
    mov [0206h], dx
    mov ax, 4C00h
    int 21h
