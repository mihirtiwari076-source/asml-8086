BITS 16
ORG 100h

start:
    ; CRC low word in AX, CRC high word in DX
    mov ax, 0FFFFh
    mov dx, 0FFFFh

    mov si, 0200h
    mov cx, [01FEh]
    jcxz done_crc32

byte_loop:
    mov bl, [si]
    xor bh, bh
    xor ax, bx           ; CRC low ^= byte

    mov bp, 8            ; 8 bits

bit_loop:
    ; Test bit 0 of CRC (AX bit 0)
    test ax, 1
    jz no_poly

    ; CRC = (CRC >> 1) ^ 0xEDB88320
    ; 0xEDB88320 -> High word 0xEDB8, Low word 0x8320
    shr dx, 1
    rcr ax, 1
    xor dx, 0EDB8h
    xor ax, 8320h
    jmp next_bit

no_poly:
    shr dx, 1
    rcr ax, 1

next_bit:
    dec bp
    jnz bit_loop

    inc si
    loop byte_loop

done_crc32:
    not ax
    not dx
    mov [02F0h], ax
    mov [02F2h], dx
    mov ax, 4C00h
    int 21h
