# Task: 32-bit CRC-32 Calculation

## Problem Description
Compute CRC-32 over buffer at DS:0200h with length at DS:01FEh.
Initial CRC: FFFFFFFFh.
Reflected polynomial: 0xEDB88320.
Bitwise slice-by-one:
For each byte B:
  CRC ^= B
  Repeat 8 times:
    if CRC bit 0 == 1:
      CRC = (CRC >> 1) ^ 0xEDB88320
    else:
      CRC = CRC >> 1
Final CRC ^= 0xFFFFFFFF.
Store 32-bit CRC at DS:02F0h (low word at 02F0h, high word at 02F2h).
Exit via INT 21h (AH=4Ch).
