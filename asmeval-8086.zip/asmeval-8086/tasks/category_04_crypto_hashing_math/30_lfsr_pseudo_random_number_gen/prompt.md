# Task: 16-bit Galois LFSR Generator

## Problem Description
State word is at DS:0200h. Step count K (16-bit word) is at DS:01FEh.
Polynomial: 0xACE1.
For each step:
  lsb = state & 1
  state >>= 1
  if lsb == 1:
    state ^= 0xACE1
Store resulting state word at DS:0200h.
Exit via INT 21h (AH=4Ch).
