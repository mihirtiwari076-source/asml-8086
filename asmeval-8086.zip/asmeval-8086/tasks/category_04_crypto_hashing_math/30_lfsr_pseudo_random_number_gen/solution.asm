BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; State
    mov cx, [01FEh]      ; K
    jcxz done_lfsr

lfsr_step:
    shr ax, 1            ; Shift right, CF = shifted out LSB
    jnc no_xor
    xor ax, 0ACE1h
no_xor:
    loop lfsr_step

done_lfsr:
    mov [0200h], ax
    mov ax, 4C00h
    int 21h
