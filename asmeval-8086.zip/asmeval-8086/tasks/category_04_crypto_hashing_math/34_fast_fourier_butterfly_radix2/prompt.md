# Task: FFT Radix-2 Complex Butterfly Primitive

## Problem Description
Input complex numbers at DS:0200h (four 16-bit signed words):
- +0: Ar
- +2: Ai
- +4: Br
- +6: Bi
Compute:
A'r = Ar + Br
A'i = Ai + Bi
B'r = Ar - Br
B'i = Ai - Bi
Store [A'r, A'i, B'r, B'i] at DS:0210h.
Exit via INT 21h (AH=4Ch).
