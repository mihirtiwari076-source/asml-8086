BITS 16
ORG 100h

start:
    mov ax, [0200h]      ; Ar
    mov bx, [0204h]      ; Br
    mov cx, ax
    add cx, bx           ; A'r = Ar + Br
    sub ax, bx           ; B'r = Ar - Br

    mov [0210h], cx
    mov [0214h], ax

    mov ax, [0202h]      ; Ai
    mov bx, [0206h]      ; Bi
    mov cx, ax
    add cx, bx           ; A'i = Ai + Bi
    sub ax, bx           ; B'i = Ai - Bi

    mov [0212h], cx
    mov [0216h], ax

    mov ax, 4C00h
    int 21h
