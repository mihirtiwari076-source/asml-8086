# Task: MD5 Compression Round Primitive

## Problem Description
Parameters at DS:0200h (seven 16-bit words):
- +0: A
- +2: B
- +4: C
- +6: D
- +8: X (message block word)
- +10: T (constant word)
- +12: S (shift amount 1..15)
F(B, C, D) = (B & C) | ((~B) & D).
Sum = A + F(B, C, D) + X + T.
Rot = (Sum rol S).
New_A = B + Rot.
Store New_A (16-bit word) at DS:0220h.
Exit via INT 21h (AH=4Ch).
