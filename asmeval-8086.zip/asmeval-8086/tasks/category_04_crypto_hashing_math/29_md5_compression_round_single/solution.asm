BITS 16
ORG 100h

start:
    mov bx, [0202h]      ; B
    mov cx, [0204h]      ; C
    mov dx, [0206h]      ; D

    ; F(B, C, D) = (B & C) | (~B & D)
    mov ax, bx
    and ax, cx           ; AX = B & C

    mov si, bx
    not si
    and si, dx           ; SI = ~B & D
    or ax, si            ; AX = F(B, C, D)

    ; Add A + X + T
    add ax, [0200h]      ; + A
    add ax, [0208h]      ; + X
    add ax, [020Ah]      ; + T

    ; rol AX, S
    mov cx, [020Ch]      ; S
    rol ax, cl

    ; Add B
    add ax, bx           ; New_A = B + Rot

    mov [0220h], ax
    mov ax, 4C00h
    int 21h
