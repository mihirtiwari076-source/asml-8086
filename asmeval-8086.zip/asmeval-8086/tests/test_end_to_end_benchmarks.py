"""
End-to-End Enterprise Benchmark Verification Suite.
Discovers and executes all 50 tasks across all 6 categories,
verifying that 100% of reference solutions pass all test vectors.
"""

from pathlib import Path
import pytest

from asmeval.harness.task_loader import load_all_tasks
from asmeval.harness.runner import TaskRunner

REPO_ROOT = Path(__file__).resolve().parent.parent
TASKS_DIR = REPO_ROOT / "tasks"


def test_discover_exact_50_tasks():
    tasks = load_all_tasks(TASKS_DIR)
    assert len(tasks) == 50, f"Expected 50 tasks, found {len(tasks)}"


@pytest.mark.parametrize("category", [
    "category_01_arithmetic_and_bcd",
    "category_02_memory_and_strings",
    "category_03_data_structures_sorting",
    "category_04_crypto_hashing_math",
    "category_05_bit_manipulation_codecs",
    "category_06_low_level_systems_dos",
])
def test_category_suite(category: str):
    cat_dir = TASKS_DIR / category
    tasks = load_all_tasks(cat_dir)
    assert len(tasks) >= 8, f"Category {category} has fewer than expected tasks: {len(tasks)}"

    runner = TaskRunner()
    for task in tasks:
        sol_file = task.directory / "solution.asm"
        report = runner.run_task(task, sol_file)
        assert report.status == "PASSED", f"Task {task.task_id} failed: status={report.status}, errors={report.errors}, mem_diffs={report.memory_diffs}"
        assert report.score == 1.0, f"Task {task.task_id} score is {report.score}"
