"""
Hardware fidelity unit tests for Intel 8086 instructions:
String operations respecting Direction Flag (DF=0 vs DF=1),
DAA and DAS decimal adjustments,
SAR (arithmetic preserving sign) vs SHR (logical zero-fill),
and Stack frame integrity across CALL / RET.
"""

import pytest
from asmeval.compiler.assembler import assemble
from asmeval.emulator.cpu import CPU


def test_string_ops_direction_flag_forward_and_backward():
    """
    Test MOVSB with DF=0 (CLD: forward SI++, DI++) and DF=1 (STD: backward SI--, DI--).
    """
    # 1. Forward copy with CLD (DF = 0)
    code_forward = """
    BITS 16
    ORG 100h
    cld
    mov si, 0200h
    mov di, 0300h
    mov cx, 4
    rep movsb
    hlt
    """
    res = assemble(code_forward)
    assert res.success

    cpu = CPU()
    cpu.memory.write_bytes(0x1000, 0x0200, b"ABCD")
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    cpu.run()

    assert cpu.memory.read_bytes(0x1000, 0x0300, 4) == b"ABCD"
    assert cpu.registers.si == 0x0204
    assert cpu.registers.di == 0x0304

    # 2. Backward copy with STD (DF = 1)
    code_backward = """
    BITS 16
    ORG 100h
    std
    mov si, 0203h        ; Point to end of source
    mov di, 0303h        ; Point to end of destination
    mov cx, 4
    rep movsb
    cld
    hlt
    """
    res2 = assemble(code_backward)
    assert res2.success

    cpu2 = CPU()
    cpu2.memory.write_bytes(0x1000, 0x0200, b"WXYZ")
    cpu2.load_binary(res2.binary, 0x1000, 0x0100)
    cpu2.run()

    assert cpu2.memory.read_bytes(0x1000, 0x0300, 4) == b"WXYZ"
    assert cpu2.registers.si == 0x01FF  # decremented past 0200h
    assert cpu2.registers.di == 0x02FF  # decremented past 0300h


def test_daa_and_das_fidelity():
    """
    Validates decimal adjust for addition (DAA) and subtraction (DAS).
    """
    # DAA: 0x28 + 0x39 = 0x61 -> DAA -> 0x67 (28 + 39 = 67 in BCD)
    code_daa = """
    BITS 16
    ORG 100h
    mov al, 28h
    add al, 39h
    daa
    hlt
    """
    res_daa = assemble(code_daa)
    assert res_daa.success
    cpu = CPU()
    cpu.load_binary(res_daa.binary, 0x1000, 0x0100)
    cpu.run()
    assert cpu.registers.al == 0x67
    assert cpu.flags.af == 1
    assert cpu.flags.cf == 0

    # DAS: 0x82 - 0x27 = 0x5B -> DAS -> 0x55 (82 - 27 = 55 in BCD)
    code_das = """
    BITS 16
    ORG 100h
    mov al, 82h
    sub al, 27h
    das
    hlt
    """
    res_das = assemble(code_das)
    assert res_das.success
    cpu2 = CPU()
    cpu2.load_binary(res_das.binary, 0x1000, 0x0100)
    cpu2.run()
    assert cpu2.registers.al == 0x55
    assert cpu2.flags.af == 1
    assert cpu2.flags.cf == 0


def test_sar_preserves_sign_and_shr_injects_zero():
    """
    SAR (Shift Arithmetic Right) preserves MSB.
    SHR (Shift Logical Right) always shifts in 0 into MSB.
    """
    code = """
    BITS 16
    ORG 100h
    mov ax, 0F000h       ; Negative 16-bit word
    mov bx, 0F000h
    sar ax, 1            ; SAR: should become 0F800h (sign bit preserved)
    shr bx, 1            ; SHR: should become 07800h (zero injected)
    hlt
    """
    res = assemble(code)
    assert res.success
    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    cpu.run()

    assert cpu.registers.ax == 0xF800
    assert cpu.registers.bx == 0x7800


def test_call_ret_stack_frame_integrity():
    """
    Ensures CALL and RET properly manipulate SS:SP and preserve caller registers.
    """
    code = """
    BITS 16
    ORG 100h
    mov sp, 0FFFEh
    mov bp, 1234h
    call my_subroutine
    hlt

my_subroutine:
    push bp
    mov bp, sp
    mov ax, 42
    pop bp
    ret
    """
    res = assemble(code)
    assert res.success
    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    cpu.run()

    assert cpu.registers.ax == 42
    assert cpu.registers.bp == 0x1234
    assert cpu.registers.sp == 0xFFFE
