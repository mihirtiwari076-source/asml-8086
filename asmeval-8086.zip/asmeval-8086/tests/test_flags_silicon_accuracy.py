"""
Comprehensive silicon-accuracy hardware tests for 8086 FLAGS register.
Validates Parity (PF low 8 bits only), Auxiliary Carry (AF nibble carry/borrow),
Overflow (OF signed 2's complement), and Carry Flag (CF preservation on INC/DEC).
"""

import pytest
from asmeval.emulator.flags import Flags


def test_parity_flag_evaluates_only_lowest_8_bits():
    """
    On 8086 hardware, the Parity Flag reflects the parity of the lowest 8 bits only,
    even for 16-bit word operations.
    """
    flags = Flags()

    # Low byte = 0x03 (two 1s -> even parity -> PF=1). High byte = 0x01 (one 1).
    # Total 16-bit word has 3 ones, but low byte has 2 ones -> PF must be 1!
    flags.update_add(0x0100, 0x0003, 0x0103, width=16)
    assert flags.pf == 1
    assert flags.PF == 1

    # Low byte = 0x01 (one 1 -> odd parity -> PF=0). High byte = 0x03 (two 1s).
    # Total 16-bit word has 3 ones, but low byte has 1 one -> PF must be 0!
    flags.update_add(0x0300, 0x0001, 0x0301, width=16)
    assert flags.pf == 0
    assert flags.PF == 0

    # Logic operations must also evaluate low 8 bits only
    flags.update_logic(0xFF03, width=16)  # low byte 0x03 has 2 ones -> PF=1
    assert flags.pf == 1

    flags.update_logic(0xFF01, width=16)  # low byte 0x01 has 1 one -> PF=0
    assert flags.pf == 0


def test_auxiliary_carry_flag_addition():
    """
    AF is set on carry out of bit 3 into bit 4 during addition.
    """
    flags = Flags()

    # 0x0F + 0x01 = 0x10 -> low nibble 0xF + 0x1 = 0x10 > 0xF -> AF=1
    flags.update_add(0x0F, 0x01, 0x10, width=8)
    assert flags.af == 1

    # 0x08 + 0x07 = 0x0F -> low nibble 0x8 + 0x7 = 0xF <= 0xF -> AF=0
    flags.update_add(0x08, 0x07, 0x0F, width=8)
    assert flags.af == 0

    # Addition with carry-in: 0x08 + 0x07 + carry 1 = 0x10 -> AF=1
    flags.update_add(0x08, 0x07, 0x10, width=8, carry_in=1)
    assert flags.af == 1

    # Static method validation
    assert Flags.compute_af_add(0x0F, 0x01) == 1
    assert Flags.compute_af_add(0x07, 0x07) == 0
    assert Flags.compute_af_add(0x08, 0x07, carry_in=1) == 1


def test_auxiliary_carry_flag_subtraction():
    """
    AF is set on borrow from bit 4 into bit 3 during subtraction.
    """
    flags = Flags()

    # 0x10 - 0x01: 0x0 < 0x1 -> borrow from bit 4 -> AF=1
    flags.update_sub(0x10, 0x01, 0x0F, width=8)
    assert flags.af == 1

    # 0x1F - 0x05: 0xF >= 0x5 -> no borrow -> AF=0
    flags.update_sub(0x1F, 0x05, 0x1A, width=8)
    assert flags.af == 0

    # Subtraction with borrow-in: 0x15 - 0x05 - borrow 1 -> 0x5 < 0x5 + 1 -> AF=1
    flags.update_sub(0x15, 0x05, 0x0F, width=8, borrow_in=1)
    assert flags.af == 1

    # Static method validation
    assert Flags.compute_af_sub(0x10, 0x01) == 1
    assert Flags.compute_af_sub(0x15, 0x05) == 0
    assert Flags.compute_af_sub(0x15, 0x05, borrow_in=1) == 1


def test_overflow_flag_signed_twos_complement():
    """
    OF is set when signed 2's complement result exceeds the representable range.
    """
    flags = Flags()

    # 8-bit positive overflow: +127 (0x7F) + 1 = -128 (0x80) -> OF=1
    flags.update_add(0x7F, 0x01, 0x80, width=8)
    assert flags.of == 1
    assert flags.sf == 1

    # 8-bit negative overflow: -128 (0x80) + -1 (0xFF) = +127 (0x7F) -> OF=1
    flags.update_add(0x80, 0xFF, 0x7F, width=8)
    assert flags.of == 1
    assert flags.sf == 0

    # 8-bit non-overflow: +10 + +20 = +30 -> OF=0
    flags.update_add(10, 20, 30, width=8)
    assert flags.of == 0

    # 16-bit positive overflow: +32767 (0x7FFF) + 1 = -32768 (0x8000) -> OF=1
    flags.update_add(0x7FFF, 0x0001, 0x8000, width=16)
    assert flags.of == 1


def test_inc_and_dec_strictly_preserve_carry_flag():
    """
    Crucial Intel 8086 rule: INC and DEC modify OF, SF, ZF, AF, PF,
    but NEVER modify the Carry Flag (CF).
    """
    flags = Flags()

    # Start with CF = 1
    flags.cf = 1

    # INC 0xFF -> 0x00 (wrapped). ZF=1, but CF MUST remain 1!
    flags.update_inc(0xFF, 0x00, width=8)
    assert flags.cf == 1
    assert flags.zf == 1

    # Start with CF = 0
    flags.cf = 0

    # DEC 0x00 -> 0xFF (borrowed). But CF MUST remain 0!
    flags.update_dec(0x00, 0xFF, width=8)
    assert flags.cf == 0
    assert flags.sf == 1
