"""
Unit tests for the AssertionEngine, diff generation, and report export.
"""

import pytest
from asmeval.emulator.cpu import CPU
from asmeval.verifier.assertion_engine import AssertionEngine, parse_numeric_value
from asmeval.verifier.diff_reporter import EvaluationReport


def test_parse_numeric_value():
    assert parse_numeric_value(42) == 42
    assert parse_numeric_value("0x1234") == 0x1234
    assert parse_numeric_value("100h") == 0x100
    assert parse_numeric_value("99") == 99


def test_assertion_registers_and_flags_pass():
    cpu = CPU()
    cpu.registers.ax = 0x1234
    cpu.registers.bx = 0x5678
    cpu.flags.zf = 1
    cpu.flags.cf = 0

    assertions = {
        "registers": {
            "AX": "0x1234",
            "BX": "0x5678",
            "ZF": 1,
            "CF": 0
        },
        "max_cycles": 1000
    }

    report = AssertionEngine.evaluate(cpu, assertions, task_id="TEST-01")
    assert report.status == "PASSED"
    assert report.score == 1.0
    assert report.register_diffs["AX"]["matched"] is True
    assert report.flag_diffs["ZF"]["matched"] is True


def test_assertion_registers_mismatch():
    cpu = CPU()
    cpu.registers.ax = 0x1234

    assertions = {
        "registers": {
            "AX": "0x9999"
        }
    }

    report = AssertionEngine.evaluate(cpu, assertions, task_id="TEST-02")
    assert report.status == "FAILED"
    assert report.score == 0.0
    assert report.register_diffs["AX"]["matched"] is False


def test_assertion_memory_pass():
    cpu = CPU()
    cpu.memory.write_bytes(0x2000, 0x0100, b"Hello World\x00")

    assertions = {
        "memory": [
            {
                "segment": "0x2000",
                "offset": "0x0100",
                "expected_ascii": "Hello World\u0000"
            }
        ]
    }

    report = AssertionEngine.evaluate(cpu, assertions, task_id="TEST-03")
    assert report.status == "PASSED"
    assert report.score == 1.0
    assert len(report.memory_diffs) == 1
    assert report.memory_diffs[0]["matched"] is True


def test_assertion_memory_mismatch():
    cpu = CPU()
    cpu.memory.write_bytes(0x2000, 0x0100, b"Wrong Data")

    assertions = {
        "memory": [
            {
                "segment": "0x2000",
                "offset": "0x0100",
                "expected_ascii": "TargetData"
            }
        ]
    }

    report = AssertionEngine.evaluate(cpu, assertions, task_id="TEST-04")
    assert report.status == "FAILED"
    assert report.score == 0.0
    assert report.memory_diffs[0]["matched"] is False
