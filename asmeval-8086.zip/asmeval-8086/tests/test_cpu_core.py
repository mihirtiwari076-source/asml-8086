"""
Unit tests for CPU instruction fidelity, flag mutations, BCD arithmetic,
stack operations, loops, string instructions, and interrupts.
"""

import pytest
from asmeval.compiler.assembler import assemble
from asmeval.emulator.cpu import CPU
from asmeval.emulator.registers import Registers
from asmeval.emulator.flags import Flags


def test_registers_high_low_mapping():
    r = Registers()
    r.ax = 0x1234
    assert r.ah == 0x12
    assert r.al == 0x34

    r.al = 0x78
    assert r.ax == 0x1278
    r.ah = 0x56
    assert r.ax == 0x5678

    r.set("bx", 0xABCD)
    assert r.get("bh") == 0xAB
    assert r.get("bl") == 0xCD


def test_flags_pack_unpack():
    f = Flags()
    f.cf = 1
    f.zf = 1
    f.df = 1
    packed = f.pack()
    f2 = Flags()
    f2.unpack(packed)
    assert f2.cf == 1
    assert f2.zf == 1
    assert f2.df == 1
    assert f2.sf == 0


def test_flags_inc_dec_preserves_cf():
    f = Flags()
    f.cf = 1  # Carry set
    f.update_inc(0x05, 0x06, width=8)
    assert f.cf == 1  # INC must not modify CF!
    assert f.zf == 0

    f.update_inc(0xFF, 0x00, width=8)
    assert f.cf == 1  # Still preserved
    assert f.zf == 1  # Zero flag set

    f.update_dec(0x01, 0x00, width=8)
    assert f.cf == 1  # DEC must not modify CF!
    assert f.zf == 1


def test_bcd_daa():
    # Example: 35 + 48 in BCD = 83 (0x35 + 0x48 = 0x7D -> DAA -> 0x83)
    code = """
    BITS 16
    ORG 100h
    mov al, 35h
    add al, 48h
    daa
    hlt
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    exec_res = cpu.run()
    assert exec_res["status"] == "PASSED"
    assert cpu.registers.al == 0x83
    assert cpu.flags.af == 1
    assert cpu.flags.cf == 0


def test_bcd_daa_with_carry():
    # Example: 79 + 35 in BCD = 114 (0x79 + 0x35 = 0xAE -> DAA -> AL=0x14, CF=1)
    code = """
    BITS 16
    ORG 100h
    mov al, 79h
    add al, 35h
    daa
    hlt
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    cpu.run()
    assert cpu.registers.al == 0x14
    assert cpu.flags.cf == 1


def test_loop_and_arithmetic():
    # Sum 1..5 in CX loop: 1 + 2 + 3 + 4 + 5 = 15 (0x0F)
    code = """
    BITS 16
    ORG 100h
    xor ax, ax
    mov cx, 5
sum_loop:
    add ax, cx
    loop sum_loop
    hlt
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    exec_res = cpu.run()
    assert exec_res["status"] == "PASSED"
    assert cpu.registers.ax == 15
    assert cpu.registers.cx == 0


def test_call_and_ret():
    code = """
    BITS 16
    ORG 100h
    mov ax, 10
    call square
    hlt

square:
    mov bx, ax
    mul bx
    ret
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    cpu.run()
    assert cpu.registers.ax == 100  # 10 * 10 = 100


def test_rep_movsb():
    # Copy 5 bytes from DS:0200h to ES:0300h
    code = """
    BITS 16
    ORG 100h
    cld
    mov si, 0200h
    mov di, 0300h
    mov cx, 5
    rep movsb
    hlt
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    # Write "ABCDE" to DS:0200h (DS = 0x1000)
    cpu.memory.write_bytes(0x1000, 0x0200, b"ABCDE")
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    cpu.run()

    # Verify destination ES:0300h has "ABCDE"
    dest = cpu.memory.read_bytes(0x1000, 0x0300, 5)
    assert dest == b"ABCDE"
    assert cpu.registers.cx == 0


def test_dos_int21_exit():
    code = """
    BITS 16
    ORG 100h
    mov ax, 4C2Ah  ; Exit code 42 (0x2A)
    int 21h
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    exec_res = cpu.run()
    assert exec_res["status"] == "PASSED"
    assert exec_res["exit_code"] == 42


def test_dos_int21_print_string():
    code = """
    BITS 16
    ORG 100h
    mov dx, msg
    mov ah, 09h
    int 21h
    mov ax, 4C00h
    int 21h

msg:
    db 'Antigravity 8086!$'
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    exec_res = cpu.run()
    assert exec_res["status"] == "PASSED"
    assert exec_res["stdout"] == "Antigravity 8086!"


def test_infinite_loop_timeout_guard():
    code = """
    BITS 16
    ORG 100h
inf:
    jmp inf
    """
    res = assemble(code)
    assert res.success is True

    cpu = CPU()
    cpu.load_binary(res.binary, 0x1000, 0x0100)
    exec_res = cpu.run(max_cycles=1000)
    assert exec_res["status"] == "TIMEOUT"
    assert exec_res["timed_out"] is True
    assert exec_res["cycles_elapsed"] >= 1000
