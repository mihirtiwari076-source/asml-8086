"""
Unit tests for NASM assembler wrapper and error parsing.
"""

import pytest
from asmeval.compiler.assembler import Assembler, assemble
from asmeval.compiler.error_parser import parse_nasm_output, categorize_error_message


def test_error_categorization():
    assert categorize_error_message("mismatch in operand sizes") == "invalid_operand_combination"
    assert categorize_error_message("symbol 'my_var' undefined") == "symbol_undefined"
    assert categorize_error_message("expression syntax error") == "syntax_error"
    assert categorize_error_message("short jump out of range") == "out_of_range"


def test_parse_nasm_output():
    output = """test.asm:14: error: mismatch in operand sizes
test.asm:25: warning: label alone on a line without a colon
test.asm:30: fatal: unable to open include file"""
    errors = parse_nasm_output(output)
    assert len(errors) == 3
    assert errors[0].line == 14
    assert errors[0].error_type == "invalid_operand_combination"
    assert errors[0].severity == "error"
    assert errors[1].line == 25
    assert errors[1].severity == "warning"
    assert errors[2].line == 30
    assert errors[2].severity == "fatal"


def test_assemble_simple_valid_code():
    code = """
    BITS 16
    ORG 100h
    mov ax, 4c00h
    int 21h
    """
    res = assemble(code)
    assert res.success is True
    assert len(res.binary) > 0
    # mov ax, 4c00h -> B8 00 4C
    # int 21h -> CD 21
    assert res.binary == b"\xB8\x00\x4C\xCD\x21"


def test_assemble_syntax_error():
    code = """
    BITS 16
    mov ax, [invalid syntax ???
    """
    res = assemble(code)
    assert res.success is False
    assert len(res.errors) >= 1
    assert any(e.error_type == "syntax_error" or e.severity == "error" for e in res.errors)


def test_assemble_operand_mismatch():
    code = """
    BITS 16
    mov al, bx
    """
    res = assemble(code)
    assert res.success is False
    assert len(res.errors) >= 1
    assert any(e.error_type == "invalid_operand_combination" for e in res.errors)
