"""
Unit tests for 8086 Real Mode Memory Model and Segmentation.
"""

import pytest
from asmeval.emulator.memory import Memory


def test_physical_address_translation():
    assert Memory.calc_physical_address(0x1000, 0x0020) == 0x10020
    assert Memory.calc_physical_address(0x2000, 0x0200) == 0x20200
    assert Memory.calc_physical_address(0x0000, 0x0400) == 0x00400
    # Boundary wrap at 1MB (0xFFFFF)
    assert Memory.calc_physical_address(0xFFFF, 0x0010) == 0x00000
    assert Memory.calc_physical_address(0xFFFF, 0x0011) == 0x00001


def test_byte_read_write():
    mem = Memory()
    mem.write_byte(0x2000, 0x0100, 0xAB)
    assert mem.read_byte(0x2000, 0x0100) == 0xAB
    # Same physical address accessed with different segment:offset
    # 0x2000:0x0100 -> 0x20100 -> 0x2010:0x0000
    assert mem.read_byte(0x2010, 0x0000) == 0xAB


def test_little_endian_word_read_write():
    mem = Memory()
    mem.write_word(0x3000, 0x0050, 0x1234)
    assert mem.read_byte(0x3000, 0x0050) == 0x34  # Low byte
    assert mem.read_byte(0x3000, 0x0051) == 0x12  # High byte
    assert mem.read_word(0x3000, 0x0050) == 0x1234


def test_segment_offset_boundary_wrap():
    mem = Memory()
    # Write word at 0xFFFF in segment 0x1000
    # Byte 0 at 0x1000:0xFFFF, Byte 1 wraps to 0x1000:0x0000
    mem.write_word(0x1000, 0xFFFF, 0xBEEF)
    assert mem.read_byte(0x1000, 0xFFFF) == 0xEF
    assert mem.read_byte(0x1000, 0x0000) == 0xBE
    assert mem.read_word(0x1000, 0xFFFF) == 0xBEEF


def test_memory_patching():
    mem = Memory()
    mem.apply_patch({
        "segment": "0x2000",
        "offset": "0x0200",
        "data_ascii": "Hello 8086\u0000"
    })
    read_back = mem.read_bytes(0x2000, 0x0200, 11)
    assert read_back == b"Hello 8086\x00"

    mem.apply_patch({
        "segment": "0x2000",
        "offset": "0x0300",
        "data_hex": "DE AD BE EF"
    })
    assert mem.read_bytes(0x2000, 0x0300, 4) == bytes([0xDE, 0xAD, 0xBE, 0xEF])
