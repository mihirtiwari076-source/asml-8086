"""
Unit tests for DataVendor Reinforcement Learning Reward Contract.
"""

import pytest
from exports.rewards_contract import compute_agent_reward


def test_reward_zero_on_failure():
    task_spec = {
        "cycle_budget": 1000,
        "memory_budget_bytes": 128,
        "scoring_weights": {"correctness": 0.70, "cycle_efficiency": 0.20, "code_density": 0.10}
    }
    
    # Status FAILED
    res_failed = {"status": "FAILED", "cycles_elapsed": 500, "binary_size_bytes": 50}
    assert compute_agent_reward(res_failed, task_spec) == 0.0

    # Status TIMEOUT
    res_timeout = {"status": "TIMEOUT", "cycles_elapsed": 1000000, "binary_size_bytes": 50}
    assert compute_agent_reward(res_timeout, task_spec) == 0.0

    # Status ASSEMBLY_ERROR
    res_err = {"status": "ASSEMBLY_ERROR", "cycles_elapsed": 0, "binary_size_bytes": 0}
    assert compute_agent_reward(res_err, task_spec) == 0.0


def test_reward_perfect_score():
    task_spec = {
        "cycle_budget": 1000,
        "memory_budget_bytes": 100,
        "scoring_weights": {"correctness": 0.70, "cycle_efficiency": 0.20, "code_density": 0.10}
    }
    res_pass = {"status": "PASSED", "cycles_elapsed": 800, "binary_size_bytes": 64}
    reward = compute_agent_reward(res_pass, task_spec)
    assert reward == 1.0


def test_reward_graceful_decay():
    task_spec = {
        "cycle_budget": 1000,
        "memory_budget_bytes": 100,
        "scoring_weights": {"correctness": 0.70, "cycle_efficiency": 0.20, "code_density": 0.10}
    }
    # 2000 cycles (2x budget -> efficiency = 0.5)
    # 200 bytes (2x budget -> density = 0.5)
    # Total = 0.70*1.0 + 0.20*0.5 + 0.10*0.5 = 0.70 + 0.10 + 0.05 = 0.85
    res_over = {"status": "PASSED", "cycles_elapsed": 2000, "binary_size_bytes": 200}
    reward = compute_agent_reward(res_over, task_spec)
    assert reward == 0.85


def test_reward_floor_minimum():
    task_spec = {
        "cycle_budget": 100,
        "memory_budget_bytes": 10,
        "scoring_weights": {"correctness": 0.70, "cycle_efficiency": 0.20, "code_density": 0.10}
    }
    # Enormous cycles and size decay to 0.1 minimum
    # Total = 0.70*1.0 + 0.20*0.1 + 0.10*0.1 = 0.70 + 0.02 + 0.01 = 0.73
    res_huge = {"status": "PASSED", "cycles_elapsed": 100000, "binary_size_bytes": 50000}
    reward = compute_agent_reward(res_huge, task_spec)
    assert reward == 0.73
