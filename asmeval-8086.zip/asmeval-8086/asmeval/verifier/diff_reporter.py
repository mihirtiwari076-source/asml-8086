"""
Diff generation and structured evaluation export for DataVendor.ai and RL benchmarks.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional


@dataclass
class ValueDiff:
    name: str
    expected: Any
    actual: Any
    matched: bool

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class MemoryDiff:
    location: str  # e.g. "2000:0200"
    expected_hex: str
    actual_hex: str
    matched: bool
    expected_ascii: Optional[str] = None
    actual_ascii: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class EvaluationReport:
    task_id: str
    status: str  # "PASSED", "FAILED", "TIMEOUT", "ASSEMBLY_ERROR", "ERROR"
    score: float  # 0.0 to 1.0
    cycles_elapsed: int = 0
    instructions_executed: int = 0
    binary_size_bytes: int = 0
    max_cycles: int = 1_000_000
    exit_code: Optional[int] = None
    register_diffs: Dict[str, dict] = field(default_factory=dict)
    flag_diffs: Dict[str, dict] = field(default_factory=dict)
    memory_diffs: List[dict] = field(default_factory=list)
    stdout: str = ""
    errors: List[dict] = field(default_factory=list)
    test_case_results: List[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    def format_summary(self) -> str:
        """Pretty summary for console output."""
        lines = [
            "=" * 60,
            f" TASK EVALUATION: {self.task_id}",
            "=" * 60,
            f" Status:        {self.status}",
            f" Score:         {self.score:.2f} / 1.00",
            f" Cycles:        {self.cycles_elapsed} (limit: {self.max_cycles})",
            f" Instructions:  {self.instructions_executed}",
        ]
        if self.exit_code is not None:
            lines.append(f" Exit Code:     {self.exit_code}")
        if self.stdout:
            lines.append(f" Stdout:        {repr(self.stdout)}")

        if self.errors:
            lines.append("-" * 60)
            lines.append(" Errors:")
            for err in self.errors:
                lines.append(f"   [{err.get('error_type', 'error')}] Line {err.get('line', '?')}: {err.get('message', '')}")

        if any(not d["matched"] for d in self.register_diffs.values()):
            lines.append("-" * 60)
            lines.append(" Register Mismatches:")
            for name, d in self.register_diffs.items():
                if not d["matched"]:
                    lines.append(f"   {name}: expected {d['expected']}, actual {d['actual']}")

        if any(not d["matched"] for d in self.flag_diffs.values()):
            lines.append("-" * 60)
            lines.append(" Flag Mismatches:")
            for name, d in self.flag_diffs.items():
                if not d["matched"]:
                    lines.append(f"   {name}: expected {d['expected']}, actual {d['actual']}")

        failed_mem = [d for d in self.memory_diffs if not d["matched"]]
        if failed_mem:
            lines.append("-" * 60)
            lines.append(" Memory Mismatches:")
            for m in failed_mem:
                lines.append(f"   [{m['location']}] Expected: {m['expected_hex']}")
                lines.append(f"                Actual:   {m['actual_hex']}")

        lines.append("=" * 60)
        return "\n".join(lines)
