"""
Assertion Engine for validating post-execution 8086 CPU and memory states against benchmarks.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple, Union

from .diff_reporter import EvaluationReport, MemoryDiff, ValueDiff

if TYPE_CHECKING:
    from ..emulator.cpu import CPU


FLAG_NAMES = {"CF", "PF", "AF", "ZF", "SF", "TF", "IF", "DF", "OF"}


def parse_numeric_value(val: Any) -> int:
    """Parses integer, hex string ('0x1234', '1234h'), or decimal string."""
    if isinstance(val, int):
        return val
    if isinstance(val, str):
        v = val.strip()
        if v.startswith("0x") or v.startswith("0X"):
            return int(v, 16)
        if v.endswith("h") or v.endswith("H"):
            return int(v[:-1], 16)
        return int(v)
    return int(val)


class AssertionEngine:
    """
    Evaluates CPU state, registers, memory blocks, and flags against rubric assertions.
    """

    @staticmethod
    def evaluate(
        cpu: CPU,
        assertions: Dict[str, Any],
        task_id: str = "TASK",
        compilation_errors: Optional[List[dict]] = None,
        exec_error: Optional[str] = None,
        timed_out: bool = False
    ) -> EvaluationReport:
        if compilation_errors:
            return EvaluationReport(
                task_id=task_id,
                status="ASSEMBLY_ERROR",
                score=0.0,
                errors=compilation_errors
            )

        if timed_out:
            return EvaluationReport(
                task_id=task_id,
                status="TIMEOUT",
                score=0.0,
                cycles_elapsed=cpu.cycles,
                instructions_executed=cpu.instruction_count,
                errors=[{"error_type": "timeout", "message": f"Execution exceeded maximum cycles limit"}]
            )

        if exec_error:
            return EvaluationReport(
                task_id=task_id,
                status="ERROR",
                score=0.0,
                cycles_elapsed=cpu.cycles,
                instructions_executed=cpu.instruction_count,
                errors=[{"error_type": "runtime_exception", "message": exec_error}]
            )

        max_cycles = assertions.get("max_cycles", 1_000_000)
        cycles_exceeded = cpu.cycles > max_cycles

        all_matched = not cycles_exceeded
        reg_diffs: Dict[str, dict] = {}
        flag_diffs: Dict[str, dict] = {}
        memory_diffs: List[dict] = []
        errors: List[dict] = []

        if cycles_exceeded:
            errors.append({
                "error_type": "cycle_budget_exceeded",
                "message": f"Cycles {cpu.cycles} exceeded limit of {max_cycles}"
            })

        # 1. Register and Flag Assertions
        reg_assertions = assertions.get("registers", {})
        for name_raw, expected_raw in reg_assertions.items():
            name = name_raw.upper()
            if name in FLAG_NAMES:
                expected_int = 1 if parse_numeric_value(expected_raw) else 0
                actual_int = cpu.flags.get(name)
                matched = (actual_int == expected_int)
                flag_diffs[name] = ValueDiff(
                    name=name,
                    expected=expected_int,
                    actual=actual_int,
                    matched=matched
                ).to_dict()
                if not matched:
                    all_matched = False
            else:
                expected_int = parse_numeric_value(expected_raw)
                try:
                    actual_int = cpu.registers.get(name)
                    matched = (actual_int == expected_int)
                    reg_diffs[name] = ValueDiff(
                        name=name,
                        expected=f"0x{expected_int:04X}" if len(name) == 2 and not name.endswith(("L", "H")) else (f"0x{expected_int:02X}" if name.endswith(("L", "H")) else str(expected_int)),
                        actual=f"0x{actual_int:04X}" if len(name) == 2 and not name.endswith(("L", "H")) else (f"0x{actual_int:02X}" if name.endswith(("L", "H")) else str(actual_int)),
                        matched=matched
                    ).to_dict()
                    if not matched:
                        all_matched = False
                except KeyError:
                    all_matched = False
                    reg_diffs[name] = ValueDiff(
                        name=name,
                        expected=str(expected_raw),
                        actual="UNKNOWN_REGISTER",
                        matched=False
                    ).to_dict()

        # Dedicated flags assertions
        flags_assertions = assertions.get("flags", {})
        for name_raw, expected_raw in flags_assertions.items():
            name = name_raw.upper()
            expected_int = 1 if parse_numeric_value(expected_raw) else 0
            actual_int = cpu.flags.get(name)
            matched = (actual_int == expected_int)
            flag_diffs[name] = ValueDiff(
                name=name,
                expected=expected_int,
                actual=actual_int,
                matched=matched
            ).to_dict()
            if not matched:
                all_matched = False

        # 2. Memory Assertions
        mem_assertions = assertions.get("memory", [])
        for block in mem_assertions:
            seg = parse_numeric_value(block.get("segment", 0))
            offset = parse_numeric_value(block.get("offset", 0))
            loc_str = f"{seg:04X}:{offset:04X}"

            expected_bytes = b""
            if "expected_ascii" in block:
                expected_bytes = block["expected_ascii"].encode("latin1")
            elif "expected_bytes" in block:
                expected_bytes = bytes([parse_numeric_value(b) for b in block["expected_bytes"]])
            elif "expected_hex" in block:
                clean_hex = block["expected_hex"].replace(" ", "").replace("\n", "")
                expected_bytes = bytes.fromhex(clean_hex)
            elif "expected_words" in block:
                words = [parse_numeric_value(w) for w in block["expected_words"]]
                barr = bytearray()
                for w in words:
                    barr.append(w & 0xFF)
                    barr.append((w >> 8) & 0xFF)
                expected_bytes = bytes(barr)

            length = len(expected_bytes)
            actual_bytes = cpu.memory.read_bytes(seg, offset, length)
            matched = (actual_bytes == expected_bytes)

            exp_hex_str = " ".join(f"{b:02X}" for b in expected_bytes)
            act_hex_str = " ".join(f"{b:02X}" for b in actual_bytes)

            diff = MemoryDiff(
                location=loc_str,
                expected_hex=exp_hex_str,
                actual_hex=act_hex_str,
                matched=matched,
                expected_ascii=repr(expected_bytes),
                actual_ascii=repr(actual_bytes)
            )
            memory_diffs.append(diff.to_dict())
            if not matched:
                all_matched = False

        # 3. Exit Code Assertion
        if "exit_code" in assertions:
            expected_exit = parse_numeric_value(assertions["exit_code"])
            actual_exit = cpu.interrupts.exit_code
            if actual_exit != expected_exit:
                all_matched = False
                errors.append({
                    "error_type": "exit_code_mismatch",
                    "message": f"Expected exit code {expected_exit}, got {actual_exit}"
                })

        # 4. Stdout Assertion
        if "stdout" in assertions:
            expected_stdout = assertions["stdout"]
            actual_stdout = cpu.interrupts.get_stdout()
            if actual_stdout != expected_stdout:
                all_matched = False
                errors.append({
                    "error_type": "stdout_mismatch",
                    "message": f"Expected stdout {repr(expected_stdout)}, got {repr(actual_stdout)}"
                })

        status = "PASSED" if all_matched else "FAILED"
        score = 1.0 if all_matched else 0.0

        return EvaluationReport(
            task_id=task_id,
            status=status,
            score=score,
            cycles_elapsed=cpu.cycles,
            instructions_executed=cpu.instruction_count,
            max_cycles=max_cycles,
            exit_code=cpu.interrupts.exit_code,
            register_diffs=reg_diffs,
            flag_diffs=flag_diffs,
            memory_diffs=memory_diffs,
            stdout=cpu.interrupts.get_stdout(),
            errors=errors
        )
