"""
NASM wrapper interface for compiling 16-bit real-mode assembly source to binary images.
"""

from __future__ import annotations
import os
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional, Union

from .error_parser import AssemblyError, parse_nasm_output


@dataclass
class AssemblyResult:
    success: bool
    binary: bytes = b""
    errors: List[AssemblyError] = field(default_factory=list)
    listing: str = ""
    stdout: str = ""
    stderr: str = ""
    output_path: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "binary_length": len(self.binary),
            "errors": [e.to_dict() for e in self.errors],
            "listing": self.listing,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "output_path": self.output_path
        }


def find_nasm_binary() -> Optional[str]:
    """
    Locates the NASM executable from PATH or common operating system locations.
    """
    # 1. Standard PATH lookup
    nasm_path = shutil.which("nasm")
    if nasm_path:
        return nasm_path

    # 2. Windows specific common install locations
    if os.name == "nt":
        candidates = [
            os.path.expandvars(r"%LOCALAPPDATA%\bin\NASM\nasm.exe"),
            os.path.expandvars(r"%ProgramFiles%\NASM\nasm.exe"),
            os.path.expandvars(r"%ProgramFiles(x86)%\NASM\nasm.exe"),
            r"C:\Program Files\NASM\nasm.exe",
            r"C:\Program Files (x86)\NASM\nasm.exe",
        ]
        for candidate in candidates:
            if os.path.isfile(candidate):
                return candidate

    # 3. Unix common paths
    unix_candidates = ["/usr/bin/nasm", "/usr/local/bin/nasm", "/opt/homebrew/bin/nasm"]
    for candidate in unix_candidates:
        if os.path.isfile(candidate):
            return candidate

    return None


class Assembler:
    """
    Wrapper for assembling 16-bit x86 Real Mode source code using NASM.
    """

    def __init__(self, nasm_bin: Optional[str] = None):
        self.nasm_bin = nasm_bin or find_nasm_binary()
        if not self.nasm_bin:
            raise FileNotFoundError(
                "NASM executable could not be found. Please install NASM and add it to your PATH."
            )

    def assemble(
        self,
        source: Union[str, Path],
        output_file: Optional[Union[str, Path]] = None,
        generate_listing: bool = True,
        extra_flags: Optional[List[str]] = None,
        timeout: float = 15.0,
    ) -> AssemblyResult:
        """
        Assembles 16-bit assembly source code to a raw flat binary (.COM/.BIN).
        Source may be passed as raw assembly text or a Path to an .asm file.
        """
        extra_flags = extra_flags or []

        with tempfile.TemporaryDirectory(prefix="asmeval_build_") as tmp_dir:
            tmp_path = Path(tmp_dir)

            if isinstance(source, Path) or (isinstance(source, str) and os.path.isfile(source)):
                src_path = Path(source).resolve()
            else:
                src_path = tmp_path / "input.asm"
                src_path.write_text(source, encoding="utf-8")

            bin_out_path = Path(output_file).resolve() if output_file else tmp_path / "output.com"
            lst_out_path = tmp_path / "listing.lst" if generate_listing else None

            cmd = [
                self.nasm_bin,
                "-f", "bin",
                "-O0",
                str(src_path),
                "-o", str(bin_out_path)
            ]

            if lst_out_path:
                cmd.extend(["-l", str(lst_out_path)])

            cmd.extend(extra_flags)

            try:
                proc = subprocess.run(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=timeout,
                    check=False
                )
            except subprocess.TimeoutExpired as e:
                return AssemblyResult(
                    success=False,
                    errors=[AssemblyError(
                        line=None,
                        error_type="timeout",
                        message=f"NASM execution timed out after {timeout} seconds",
                        raw=str(e)
                    )],
                    stderr="Compilation timed out."
                )
            except Exception as e:
                return AssemblyResult(
                    success=False,
                    errors=[AssemblyError(
                        line=None,
                        error_type="process_error",
                        message=f"Failed to execute NASM: {str(e)}",
                        raw=str(e)
                    )],
                    stderr=str(e)
                )

            stdout = proc.stdout or ""
            stderr = proc.stderr or ""
            combined_output = f"{stdout}\n{stderr}".strip()
            errors = parse_nasm_output(combined_output)

            # Check if binary was created and return code is 0
            if proc.returncode == 0 and bin_out_path.exists():
                binary_data = bin_out_path.read_bytes()
                listing_str = lst_out_path.read_text(encoding="utf-8", errors="replace") if (lst_out_path and lst_out_path.exists()) else ""
                return AssemblyResult(
                    success=True,
                    binary=binary_data,
                    errors=errors,  # may contain warnings
                    listing=listing_str,
                    stdout=stdout,
                    stderr=stderr,
                    output_path=str(bin_out_path) if output_file else None
                )
            else:
                if not errors and proc.returncode != 0:
                    errors.append(AssemblyError(
                        line=None,
                        error_type="general_assembly_error",
                        message=stderr or stdout or f"NASM failed with exit code {proc.returncode}",
                        raw=stderr or stdout
                    ))

                return AssemblyResult(
                    success=False,
                    binary=b"",
                    errors=errors,
                    stdout=stdout,
                    stderr=stderr
                )


def assemble(
    source: Union[str, Path],
    output_file: Optional[Union[str, Path]] = None,
    extra_flags: Optional[List[str]] = None
) -> AssemblyResult:
    """Convenience helper function for assemble()."""
    assembler = Assembler()
    return assembler.assemble(source, output_file=output_file, extra_flags=extra_flags)
