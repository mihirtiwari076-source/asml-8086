"""
Error parsing module for NASM compiler output.
Extracts line numbers, categories, and error descriptions into structured objects.
"""

from __future__ import annotations
import re
from dataclasses import dataclass, asdict
from typing import List, Optional


@dataclass
class AssemblyError:
    line: Optional[int]
    error_type: str
    message: str
    severity: str = "error"
    raw: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def categorize_error_message(message: str) -> str:
    msg_lower = message.lower()
    if any(k in msg_lower for k in ["invalid combination of opcode and operands", "mismatch in operand sizes", "invalid operand", "operation size not specified"]):
        return "invalid_operand_combination"
    if any(k in msg_lower for k in ["symbol", "undefined", "not defined", "undeclared"]):
        return "symbol_undefined"
    if any(k in msg_lower for k in ["expression syntax error", "parser: instruction expected", "syntax error", "comma expected"]):
        return "syntax_error"
    if any(k in msg_lower for k in ["short jump out of range", "value out of range", "byte data exceeds bounds", "word data exceeds bounds"]):
        return "out_of_range"
    if any(k in msg_lower for k in ["segment override", "invalid segment register"]):
        return "segment_override_error"
    if any(k in msg_lower for k in ["instruction not supported in 16-bit mode", "requires cpu"]):
        return "unsupported_instruction"
    return "general_assembly_error"


def parse_nasm_output(output: str) -> List[AssemblyError]:
    """
    Parses the stderr/stdout string from NASM into a list of AssemblyError objects.
    NASM formats typically:
      file.asm:14: error: mismatch in operand sizes
      file.asm:20: warning: ...
      file.asm:5: fatal: ...
    """
    errors: List[AssemblyError] = []
    lines = output.splitlines()

    # Pattern for standard gcc/nasm style diagnostics
    pattern = re.compile(r"^(?:.*?):(\d+):\s*(error|warning|fatal):\s*(.+)$", re.IGNORECASE)
    alt_pattern = re.compile(r"^(?:.*?):(\d+):\s*(.+)$")

    for raw_line in lines:
        line_str = raw_line.strip()
        if not line_str:
            continue

        match = pattern.match(line_str)
        if match:
            line_no = int(match.group(1))
            severity = match.group(2).lower()
            msg = match.group(3).strip()
            err_type = categorize_error_message(msg)
            errors.append(AssemblyError(
                line=line_no,
                error_type=err_type,
                message=msg,
                severity=severity,
                raw=line_str
            ))
            continue

        alt_match = alt_pattern.match(line_str)
        if alt_match:
            try:
                line_no = int(alt_match.group(1))
                msg = alt_match.group(2).strip()
                err_type = categorize_error_message(msg)
                errors.append(AssemblyError(
                    line=line_no,
                    error_type=err_type,
                    message=msg,
                    severity="error",
                    raw=line_str
                ))
                continue
            except ValueError:
                pass

        # Fallback for general unformatted diagnostic lines
        if "error:" in line_str.lower() or "fatal:" in line_str.lower():
            errors.append(AssemblyError(
                line=None,
                error_type=categorize_error_message(line_str),
                message=line_str,
                severity="error",
                raw=line_str
            ))

    return errors
