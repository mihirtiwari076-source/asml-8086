"""
Command Line Interface (CLI) for asmeval-8086.
Provides assemble, run, test, and benchmark commands with JSON and pretty outputs.
"""

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

from asmeval.compiler.assembler import Assembler
from asmeval.emulator.cpu import CPU
from asmeval.harness.task_loader import load_task, load_all_tasks
from asmeval.harness.runner import TaskRunner


def cmd_assemble(args: argparse.Namespace) -> int:
    assembler = Assembler()
    out_file = args.output if args.output else str(Path(args.file).with_suffix(".com"))
    res = assembler.assemble(args.file, output_file=out_file)

    if args.json:
        print(json.dumps(res.to_dict(), indent=2))
    else:
        if res.success:
            print(f"[SUCCESS] Assembled {args.file} -> {out_file} ({len(res.binary)} bytes)")
        else:
            print(f"[FAILED] Assembly failed with {len(res.errors)} error(s):")
            for err in res.errors:
                print(f"  Line {err.line or '?'}: [{err.error_type}] {err.message}")

    return 0 if res.success else 1


def cmd_run(args: argparse.Namespace) -> int:
    bin_path = Path(args.file).resolve()
    if not bin_path.exists():
        print(f"Error: binary file {bin_path} not found.", file=sys.stderr)
        return 1

    binary_data = bin_path.read_bytes()
    cpu = CPU()
    cpu.load_binary(binary_data, segment=0x1000, offset=0x0100)
    result = cpu.run(max_cycles=args.max_cycles)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print("=" * 60)
        print(f" EXECUTION FINISHED: {bin_path.name}")
        print("=" * 60)
        print(f" Status:       {result['status']}")
        print(f" Cycles:       {result['cycles_elapsed']}")
        print(f" Instructions: {result['instructions_executed']}")
        if result["exit_code"] is not None:
            print(f" Exit Code:    {result['exit_code']}")
        if result["stdout"]:
            print(f" Output:       {result['stdout']}")
        if result["error"]:
            print(f" Error:        {result['error']}")
        print("=" * 60)

    return 0 if result["status"] == "PASSED" else 1


def cmd_test(args: argparse.Namespace) -> int:
    task_dir = Path(args.task_dir).resolve()
    sub_path = Path(args.submission).resolve() if args.submission else (task_dir / "solution.asm")

    if not task_dir.exists():
        print(f"Error: Task directory {task_dir} not found.", file=sys.stderr)
        return 1
    if not sub_path.exists():
        print(f"Error: Submission file {sub_path} not found.", file=sys.stderr)
        return 1

    task = load_task(task_dir)
    runner = TaskRunner()
    report = runner.run_task(task, sub_path)

    if args.json:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        print(report.format_summary())

    return 0 if report.status == "PASSED" else 1


def cmd_benchmark(args: argparse.Namespace) -> int:
    tasks_dir = Path(args.tasks_dir).resolve()
    if not tasks_dir.exists():
        print(f"Error: Tasks directory {tasks_dir} not found.", file=sys.stderr)
        return 1

    tasks = load_all_tasks(tasks_dir)
    if not tasks:
        print(f"No valid tasks found under {tasks_dir}", file=sys.stderr)
        return 1

    runner = TaskRunner()
    results = []
    total_passed = 0

    sub_dir = Path(args.submission_dir).resolve() if args.submission_dir else None

    for task in tasks:
        # If submission dir provided, look for <task_id>.asm or <task_dir_name>.asm, else fallback to solution.asm
        if sub_dir:
            cand = sub_dir / f"{task.task_id}.asm"
            if not cand.exists() and task.directory:
                cand = sub_dir / f"{task.directory.name}.asm"
            if not cand.exists():
                cand = task.directory / "solution.asm" if task.directory else None
        else:
            cand = task.directory / "solution.asm" if task.directory else None

        if not cand or not cand.exists():
            print(f"Warning: No submission/solution found for {task.task_id}", file=sys.stderr)
            continue

        report = runner.run_task(task, cand)
        results.append(report)
        if report.status == "PASSED":
            total_passed += 1

    overall_score = float(total_passed) / float(len(results)) if results else 0.0

    if args.json:
        export_data = {
            "benchmark_suite": "asmeval-8086",
            "total_tasks": len(results),
            "passed_tasks": total_passed,
            "overall_score": overall_score,
            "tasks": [r.to_dict() for r in results]
        }
        print(json.dumps(export_data, indent=2))
    else:
        print("=" * 70)
        print(f" ASMEVAL-8086 BENCHMARK SUITE SUMMARY")
        print("=" * 70)
        print(f" Total Tasks Evaluated: {len(results)}")
        print(f" Tasks Passed:          {total_passed} / {len(results)}")
        print(f" Pass Rate:             {overall_score * 100:.1f}%")
        print("-" * 70)
        for r in results:
            mark = "[PASS]" if r.status == "PASSED" else "[FAIL]"
            print(f"  {mark:<7} {r.task_id:<32} Score: {r.score:.2f}  Cycles: {r.cycles_elapsed}")
        print("=" * 70)

    return 0 if total_passed == len(results) else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="asmeval",
        description="Deterministic Headless 8086 Assembly Verification Harness and Evaluation Sandbox."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # assemble
    p_asm = subparsers.add_parser("assemble", help="Assemble an 8086 assembly file to binary")
    p_asm.add_argument("file", help="Path to input .asm file")
    p_asm.add_argument("-o", "--output", help="Path to output .com/.bin file")
    p_asm.add_argument("--json", action="store_true", help="Output result as JSON")

    # run
    p_run = subparsers.add_parser("run", help="Run a compiled flat 16-bit binary headlessly")
    p_run.add_argument("file", help="Path to .com/.bin file")
    p_run.add_argument("--max-cycles", type=int, default=1_000_000, help="Cycle execution budget")
    p_run.add_argument("--json", action="store_true", help="Output execution results as JSON")

    # test
    p_test = subparsers.add_parser("test", help="Test an assembly submission against a task")
    p_test.add_argument("--task-dir", required=True, help="Path to task directory")
    p_test.add_argument("--submission", help="Path to candidate .asm (defaults to task solution.asm)")
    p_test.add_argument("--json", action="store_true", help="Output evaluation report as JSON")

    # benchmark
    p_bench = subparsers.add_parser("benchmark", help="Run the full benchmark suite across all tasks")
    p_bench.add_argument("--tasks-dir", default="tasks", help="Directory containing task definitions")
    p_bench.add_argument("--submission-dir", help="Directory containing candidate .asm solutions")
    p_bench.add_argument("--json", action="store_true", help="Output summary report as JSON")

    parsed_args = parser.parse_args(argv)

    if parsed_args.command == "assemble":
        return cmd_assemble(parsed_args)
    elif parsed_args.command == "run":
        return cmd_run(parsed_args)
    elif parsed_args.command == "test":
        return cmd_test(parsed_args)
    elif parsed_args.command == "benchmark":
        return cmd_benchmark(parsed_args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
