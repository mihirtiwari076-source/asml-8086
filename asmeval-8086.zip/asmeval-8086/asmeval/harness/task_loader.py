"""
Task definition loader and parser for DataVendor.ai benchmark challenges.
"""

from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


@dataclass
class BenchmarkTask:
    task_id: str
    title: str
    difficulty: str
    domain: str
    description: str
    initial_state: Dict[str, Any]
    assertions: Dict[str, Any]
    prompt: str = ""
    template: str = ""
    solution: str = ""
    test_cases: List[Dict[str, Any]] = field(default_factory=list)
    category: str = ""
    cycle_budget: int = 1_000_000
    memory_budget_bytes: int = 256
    scoring_weights: Dict[str, float] = field(default_factory=dict)
    clobber_policy: Dict[str, Any] = field(default_factory=dict)
    directory: Optional[Path] = None

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "title": self.title,
            "category": self.category,
            "difficulty": self.difficulty,
            "domain": self.domain,
            "description": self.description,
            "cycle_budget": self.cycle_budget,
            "initial_state": self.initial_state,
            "assertions": self.assertions,
            "num_test_cases": len(self.test_cases),
            "directory": str(self.directory) if self.directory else None
        }


def load_task(task_dir: Union[str, Path]) -> BenchmarkTask:
    """
    Loads a benchmark task directory containing:
      task.json, prompt.md, template.asm, solution.asm, and test_cases.json
    """
    dir_path = Path(task_dir).resolve()
    if not dir_path.is_dir():
        raise FileNotFoundError(f"Task directory does not exist: {dir_path}")

    task_json_file = dir_path / "task.json"
    if not task_json_file.exists():
        raise FileNotFoundError(f"Missing task.json in {dir_path}")

    with open(task_json_file, "r", encoding="utf-8") as f:
        meta = json.load(f)

    prompt_str = ""
    prompt_file = dir_path / "prompt.md"
    if prompt_file.exists():
        prompt_str = prompt_file.read_text(encoding="utf-8")

    template_str = ""
    template_file = dir_path / "template.asm"
    if template_file.exists():
        template_str = template_file.read_text(encoding="utf-8")

    solution_str = ""
    solution_file = dir_path / "solution.asm"
    if solution_file.exists():
        solution_str = solution_file.read_text(encoding="utf-8")

    test_cases: List[Dict[str, Any]] = []
    test_cases_file = dir_path / "test_cases.json"
    if test_cases_file.exists():
        with open(test_cases_file, "r", encoding="utf-8") as f:
            test_cases = json.load(f)
    elif "eval_vectors" in meta:
        # Convert v2 eval_vectors to test_cases format
        for v in meta["eval_vectors"]:
            test_cases.append({
                "id": v.get("vector_id", "vector"),
                "initial_state": v.get("setup", {}),
                "assertions": v.get("expected", {})
            })

    # Harmonize initial state from v1 or v2 format
    init_state = meta.get("initial_state", {})
    if not init_state and "environment" in meta:
        env = meta["environment"]
        init_state = {
            "registers": env.get("initial_registers", {}),
            "memory_patches": []
        }

    assertions = meta.get("assertions", {})

    return BenchmarkTask(
        task_id=meta.get("task_id", dir_path.name),
        title=meta.get("title", dir_path.name),
        difficulty=meta.get("difficulty", "medium"),
        domain=meta.get("domain", meta.get("category", "systems/assembly/8086")),
        category=meta.get("category", ""),
        description=meta.get("description", ""),
        initial_state=init_state,
        assertions=assertions,
        cycle_budget=meta.get("cycle_budget", assertions.get("max_cycles", 1_000_000)),
        memory_budget_bytes=meta.get("memory_budget_bytes", 256),
        scoring_weights=meta.get("scoring_weights", {}),
        clobber_policy=meta.get("environment", {}).get("clobber_policy", {}),
        prompt=prompt_str,
        template=template_str,
        solution=solution_str,
        test_cases=test_cases,
        directory=dir_path
    )


def load_all_tasks(tasks_dir: Union[str, Path]) -> List[BenchmarkTask]:
    """
    Discovers and loads all task directories recursively under tasks_dir.
    """
    root = Path(tasks_dir).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Tasks directory does not exist: {root}")

    tasks = []
    # Use rglob to recursively discover task.json files
    task_files = sorted(root.rglob("task.json"))
    for tf in task_files:
        tasks.append(load_task(tf.parent))
    return tasks
