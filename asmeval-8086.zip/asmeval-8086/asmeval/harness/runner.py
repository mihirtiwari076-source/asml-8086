"""
Benchmark test runner executing candidate solutions across parameterized test cases.
"""

from __future__ import annotations
import copy
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ..compiler.assembler import Assembler, AssemblyResult
from ..emulator.cpu import CPU
from ..verifier.assertion_engine import AssertionEngine
from ..verifier.diff_reporter import EvaluationReport
from .task_loader import BenchmarkTask


class TaskRunner:
    """
    Orchestrates compiling assembly candidates and verifying them against benchmark test vectors.
    """

    def __init__(self, assembler: Optional[Assembler] = None):
        self.assembler = assembler or Assembler()

    def run_task(
        self,
        task: BenchmarkTask,
        submission_source: Union[str, Path]
    ) -> EvaluationReport:
        # 1. Compile the assembly submission
        asm_res = self.assembler.assemble(submission_source)
        if not asm_res.success:
            return EvaluationReport(
                task_id=task.task_id,
                status="ASSEMBLY_ERROR",
                score=0.0,
                errors=[e.to_dict() for e in asm_res.errors]
            )

        # 2. Build list of test cases to run
        test_cases = task.test_cases if task.test_cases else [
            {"id": "base", "initial_state": task.initial_state, "assertions": task.assertions}
        ]

        tc_reports: List[EvaluationReport] = []
        total_cycles = 0
        total_instructions = 0
        all_passed = True
        overall_timeout = False

        for tc_idx, tc in enumerate(test_cases):
            tc_id = tc.get("id", f"case_{tc_idx + 1}")

            # Merge initial state: base task overridden by test case specific state
            merged_initial = copy.deepcopy(task.initial_state)
            if "initial_state" in tc:
                # Merge registers
                if "registers" in tc["initial_state"]:
                    merged_initial.setdefault("registers", {}).update(tc["initial_state"]["registers"])
                # Merge flags
                if "flags" in tc["initial_state"]:
                    merged_initial.setdefault("flags", {}).update(tc["initial_state"]["flags"])
                # Override memory patches if test case specifies them
                if "memory_patches" in tc["initial_state"]:
                    merged_initial["memory_patches"] = tc["initial_state"]["memory_patches"]

            # Merge assertions: base assertions overridden by test case specific assertions
            merged_assertions = copy.deepcopy(task.assertions)
            if "assertions" in tc:
                if "registers" in tc["assertions"]:
                    merged_assertions.setdefault("registers", {}).update(tc["assertions"]["registers"])
                if "flags" in tc["assertions"]:
                    merged_assertions.setdefault("flags", {}).update(tc["assertions"]["flags"])
                if "memory" in tc["assertions"]:
                    merged_assertions["memory"] = tc["assertions"]["memory"]
                if "max_cycles" in tc["assertions"]:
                    merged_assertions["max_cycles"] = tc["assertions"]["max_cycles"]
                if "exit_code" in tc["assertions"]:
                    merged_assertions["exit_code"] = tc["assertions"]["exit_code"]
                if "stdout" in tc["assertions"]:
                    merged_assertions["stdout"] = tc["assertions"]["stdout"]

            # Initialize CPU and load code
            cpu = CPU()
            # Standard COM entry point: CS = 0x1000, IP = 0x0100, DS = 0x1000, ES = 0x1000
            cpu.load_binary(asm_res.binary, segment=0x1000, offset=0x0100)
            cpu.setup_initial_state(merged_initial)

            max_cyc = merged_assertions.get("max_cycles", 1_000_000)
            exec_res = cpu.run(max_cycles=max_cyc)

            total_cycles += cpu.cycles
            total_instructions += cpu.instruction_count

            if exec_res["timed_out"]:
                overall_timeout = True

            tc_report = AssertionEngine.evaluate(
                cpu=cpu,
                assertions=merged_assertions,
                task_id=f"{task.task_id}[{tc_id}]",
                exec_error=exec_res["error"],
                timed_out=exec_res["timed_out"]
            )

            tc_reports.append(tc_report)
            if tc_report.status != "PASSED":
                all_passed = False

        passed_count = sum(1 for r in tc_reports if r.status == "PASSED")
        score = float(passed_count) / float(len(test_cases)) if test_cases else 0.0

        if all_passed:
            overall_status = "PASSED"
        elif overall_timeout:
            overall_status = "TIMEOUT"
        else:
            overall_status = "FAILED"

        # Aggregate diffs from first failed test case (or last passed)
        primary_report = next((r for r in tc_reports if r.status != "PASSED"), tc_reports[0])

        return EvaluationReport(
            task_id=task.task_id,
            status=overall_status,
            score=score,
            cycles_elapsed=total_cycles,
            instructions_executed=total_instructions,
            binary_size_bytes=len(asm_res.binary),
            max_cycles=task.assertions.get("max_cycles", 1_000_000),
            exit_code=primary_report.exit_code,
            register_diffs=primary_report.register_diffs,
            flag_diffs=primary_report.flag_diffs,
            memory_diffs=primary_report.memory_diffs,
            stdout=primary_report.stdout,
            errors=primary_report.errors,
            test_case_results=[r.to_dict() for r in tc_reports]
        )
