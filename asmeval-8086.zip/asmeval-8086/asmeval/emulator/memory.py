"""
Real-Mode 1MB Memory Model for the Intel 8086 processor.
Implements 20-bit physical addressing: ((segment << 4) + offset) & 0xFFFFF,
with proper 64KB segment wrap semantics and little-endian word operations.
"""

from __future__ import annotations
from typing import Dict, List, Optional, Union, Any


class Memory:
    """
    Simulates the 1,048,576 byte (1MB) Real Mode address space of an 8086 CPU.
    """

    SIZE = 1024 * 1024  # 1 MB

    def __init__(self):
        self._raw = bytearray(self.SIZE)

    def reset(self) -> None:
        self._raw = bytearray(self.SIZE)

    @staticmethod
    def calc_physical_address(segment: int, offset: int) -> int:
        """
        Calculates 20-bit physical address. Wraps at 1MB boundary (0xFFFFF).
        """
        return (((segment & 0xFFFF) << 4) + (offset & 0xFFFF)) & 0xFFFFF

    def to_physical(self, segment: int, offset: int) -> int:
        """
        Instance helper calculating 20-bit physical address. Wraps at 1MB boundary (0xFFFFF).
        """
        return (((segment & 0xFFFF) << 4) + (offset & 0xFFFF)) & 0xFFFFF

    # Byte operations (segment:offset)
    def read_byte(self, segment: int, offset: int) -> int:
        addr = self.calc_physical_address(segment, offset)
        return self._raw[addr]

    def write_byte(self, segment: int, offset: int, value: int) -> None:
        addr = self.calc_physical_address(segment, offset)
        self._raw[addr] = value & 0xFF

    # 16-bit Little-Endian Word operations (segment:offset)
    def read_word(self, segment: int, offset: int) -> int:
        """
        Reads a 16-bit little-endian word.
        Crucial 8086 detail: if offset == 0xFFFF, byte 1 is read from offset 0x0000 of same segment.
        """
        low = self.read_byte(segment, offset)
        high = self.read_byte(segment, (offset + 1) & 0xFFFF)
        return (high << 8) | low

    def write_word(self, segment: int, offset: int, value: int) -> None:
        """
        Writes a 16-bit little-endian word.
        Crucial 8086 detail: if offset == 0xFFFF, byte 1 is written to offset 0x0000 of same segment.
        """
        self.write_byte(segment, offset, value & 0xFF)
        self.write_byte(segment, (offset + 1) & 0xFFFF, (value >> 8) & 0xFF)

    # Physical Address Direct Operations
    def read_phys_byte(self, addr: int) -> int:
        return self._raw[addr & 0xFFFFF]

    def write_phys_byte(self, addr: int, value: int) -> None:
        self._raw[addr & 0xFFFFF] = value & 0xFF

    def read_phys_word(self, addr: int) -> int:
        low = self._raw[addr & 0xFFFFF]
        high = self._raw[(addr + 1) & 0xFFFFF]
        return (high << 8) | low

    def write_phys_word(self, addr: int, value: int) -> None:
        self._raw[addr & 0xFFFFF] = value & 0xFF
        self._raw[(addr + 1) & 0xFFFFF] = (value >> 8) & 0xFF

    # Bulk Block Read / Write
    def read_bytes(self, segment: int, offset: int, length: int) -> bytes:
        """
        Reads a sequence of contiguous bytes starting at segment:offset.
        """
        out = bytearray(length)
        cur_offset = offset & 0xFFFF
        for i in range(length):
            out[i] = self.read_byte(segment, cur_offset)
            cur_offset = (cur_offset + 1) & 0xFFFF
        return bytes(out)

    def write_bytes(self, segment: int, offset: int, data: Union[bytes, bytearray, List[int]]) -> None:
        """
        Writes a sequence of contiguous bytes starting at segment:offset.
        """
        cur_offset = offset & 0xFFFF
        for b in data:
            self.write_byte(segment, cur_offset, b)
            cur_offset = (cur_offset + 1) & 0xFFFF

    # Memory Patching Support
    def apply_patch(self, patch: Dict[str, Any]) -> None:
        """
        Applies a memory patch dictionary from task.json or test cases.
        Expected format:
        {
          "segment": "0x2000" or 0x2000,
          "offset": "0x0200" or 0x0200,
          "data_hex": "48656c6c6f",
          "data_ascii": "Hello\0",
          "data_bytes": [0x48, 0x65],
          "data_words": [0x1234, 0x5678]
        }
        """
        def parse_val(v: Any) -> int:
            if isinstance(v, str):
                return int(v, 16) if (v.startswith("0x") or v.startswith("0X") or v.endswith("h") or v.endswith("H")) else int(v)
            return int(v)

        segment = parse_val(patch.get("segment", 0))
        offset = parse_val(patch.get("offset", 0))

        if "data_hex" in patch or "bytes_hex" in patch:
            hex_str = patch.get("data_hex", patch.get("bytes_hex", "")).replace(" ", "").replace("\n", "")
            data = bytes.fromhex(hex_str)
            self.write_bytes(segment, offset, data)
        elif "data_ascii" in patch:
            # Handle escaped characters like \0, \n, \r
            raw_str = patch["data_ascii"]
            # Convert python string to bytes (handling ascii and null bytes)
            data = raw_str.encode("latin1")
            self.write_bytes(segment, offset, data)
        elif "data_bytes" in patch:
            bytes_list = [parse_val(x) for x in patch["data_bytes"]]
            self.write_bytes(segment, offset, bytes_list)
        elif "data_words" in patch:
            words = [parse_val(x) for x in patch["data_words"]]
            cur = offset
            for w in words:
                self.write_word(segment, cur, w)
                cur = (cur + 2) & 0xFFFF

    def dump_hex(self, segment: int, offset: int, length: int) -> str:
        """Helper to dump formatted hex view of memory region."""
        data = self.read_bytes(segment, offset, length)
        lines = []
        for i in range(0, len(data), 16):
            chunk = data[i:i+16]
            hex_part = " ".join(f"{b:02X}" for b in chunk)
            ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
            lines.append(f"{segment:04X}:{(offset + i) & 0xFFFF:04X}  {hex_part:<48}  |{ascii_part}|")
        return "\n".join(lines)
