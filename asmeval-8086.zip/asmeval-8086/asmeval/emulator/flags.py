"""
FLAGS register implementation with exact 8086 arithmetic flag behaviors:
Parity, Carry, Auxiliary Carry (BCD), Overflow, Zero, and Sign.
"""

from __future__ import annotations
from typing import Dict


# Precompute 256-element parity table:
# Intel 8086 Parity Flag is 1 if the least significant 8 bits contain an EVEN number of 1-bits.
PARITY_TABLE = [
    1 if (bin(i).count('1') % 2 == 0) else 0
    for i in range(256)
]


class Flags:
    """
    Manages the 16-bit FLAGS register of the 8086.
    """

    __slots__ = (
        "cf",  # Bit 0: Carry
        "pf",  # Bit 2: Parity
        "af",  # Bit 4: Auxiliary Carry
        "zf",  # Bit 6: Zero
        "sf",  # Bit 7: Sign
        "tf",  # Bit 8: Trap
        "if_", # Bit 9: Interrupt Enable
        "df",  # Bit 10: Direction
        "of",  # Bit 11: Overflow
    )

    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self.cf = 0
        self.pf = 0
        self.af = 0
        self.zf = 0
        self.sf = 0
        self.tf = 0
        self.if_ = 1  # Interrupts enabled by default in real mode setup
        self.df = 0  # 0: Up (increment SI/DI), 1: Down (decrement SI/DI)
        self.of = 0

    @property
    def if_flag(self) -> int:
        return self.if_

    @if_flag.setter
    def if_flag(self, val: int) -> None:
        self.if_ = 1 if val else 0

    # Uppercase aliases for 8086 standard notation
    @property
    def CF(self) -> int: return self.cf
    @CF.setter
    def CF(self, val: int) -> None: self.cf = 1 if val else 0

    @property
    def PF(self) -> int: return self.pf
    @PF.setter
    def PF(self, val: int) -> None: self.pf = 1 if val else 0

    @property
    def AF(self) -> int: return self.af
    @AF.setter
    def AF(self, val: int) -> None: self.af = 1 if val else 0

    @property
    def ZF(self) -> int: return self.zf
    @ZF.setter
    def ZF(self, val: int) -> None: self.zf = 1 if val else 0

    @property
    def SF(self) -> int: return self.sf
    @SF.setter
    def SF(self, val: int) -> None: self.sf = 1 if val else 0

    @property
    def TF(self) -> int: return self.tf
    @TF.setter
    def TF(self, val: int) -> None: self.tf = 1 if val else 0

    @property
    def IF(self) -> int: return self.if_
    @IF.setter
    def IF(self, val: int) -> None: self.if_ = 1 if val else 0

    @property
    def DF(self) -> int: return self.df
    @DF.setter
    def DF(self, val: int) -> None: self.df = 1 if val else 0

    @property
    def OF(self) -> int: return self.of
    @OF.setter
    def OF(self, val: int) -> None: self.of = 1 if val else 0

    @staticmethod
    def compute_af_add(op1: int, op2: int, res: int = 0, carry_in: int = 0) -> int:
        return 1 if (((op1 & 0x0F) + (op2 & 0x0F) + carry_in) > 0x0F) else 0

    @staticmethod
    def compute_af_sub(op1: int, op2: int, res: int = 0, borrow_in: int = 0) -> int:
        return 1 if ((op1 & 0x0F) < ((op2 & 0x0F) + borrow_in)) else 0

    def update_szp_byte(self, val: int) -> None:
        v = val & 0xFF
        self.sf = 1 if (v & 0x80) else 0
        self.zf = 1 if (v == 0) else 0
        self.pf = self.compute_parity(v)

    def update_szp_word(self, val: int) -> None:
        v = val & 0xFFFF
        self.sf = 1 if (v & 0x8000) else 0
        self.zf = 1 if (v == 0) else 0
        self.pf = self.compute_parity(v)  # Low 8 bits for PF!

    def compute_parity(self, val: int) -> int:
        """Computes parity flag over lowest 8 bits."""
        return PARITY_TABLE[val & 0xFF]

    def pack(self) -> int:
        """
        Packs flags into a 16-bit word format matching 8086 stack pushf.
        On 8086, bit 1 is always 1, bits 3, 5 are 0, bits 12-15 are 1.
        """
        val = 0xF002  # bits 12-15 = 1, bit 1 = 1
        if self.cf: val |= (1 << 0)
        if self.pf: val |= (1 << 2)
        if self.af: val |= (1 << 4)
        if self.zf: val |= (1 << 6)
        if self.sf: val |= (1 << 7)
        if self.tf: val |= (1 << 8)
        if self.if_: val |= (1 << 9)
        if self.df: val |= (1 << 10)
        if self.of: val |= (1 << 11)
        return val & 0xFFFF

    def unpack(self, val: int) -> None:
        """
        Unpacks flags from a 16-bit word format (e.g. popf / iret).
        """
        self.cf = 1 if (val & (1 << 0)) else 0
        self.pf = 1 if (val & (1 << 2)) else 0
        self.af = 1 if (val & (1 << 4)) else 0
        self.zf = 1 if (val & (1 << 6)) else 0
        self.sf = 1 if (val & (1 << 7)) else 0
        self.tf = 1 if (val & (1 << 8)) else 0
        self.if_ = 1 if (val & (1 << 9)) else 0
        self.df = 1 if (val & (1 << 10)) else 0
        self.of = 1 if (val & (1 << 11)) else 0

    # Arithmetic flag update helpers
    def update_add(self, a: int, b: int, result: int, width: int = 8, carry_in: int = 0) -> None:
        """Updates flags after ADD / ADC."""
        mask = 0xFF if width == 8 else 0xFFFF
        sign_bit = 0x80 if width == 8 else 0x8000
        max_val = 0xFF if width == 8 else 0xFFFF

        # Raw mathematical sum:
        raw_sum = a + b + carry_in
        res = raw_sum & mask

        self.cf = 1 if raw_sum > max_val else 0
        # Signed overflow: operands of same sign produced result of different sign
        self.of = 1 if (((a ^ res) & (b ^ res) & sign_bit) != 0) else 0
        self.sf = 1 if (res & sign_bit) != 0 else 0
        self.zf = 1 if res == 0 else 0
        self.pf = self.compute_parity(res)
        # AF: Carry from bit 3 to bit 4
        self.af = 1 if (((a & 0x0F) + (b & 0x0F) + carry_in) > 0x0F) else 0

    def update_sub(self, a: int, b: int, result: int, width: int = 8, borrow_in: int = 0) -> None:
        """Updates flags after SUB / SBB / CMP."""
        mask = 0xFF if width == 8 else 0xFFFF
        sign_bit = 0x80 if width == 8 else 0x8000

        # Mathematical difference:
        raw_diff = a - b - borrow_in
        res = raw_diff & mask

        self.cf = 1 if raw_diff < 0 else 0
        # Signed overflow: operands of different signs produced unexpected sign
        self.of = 1 if (((a ^ b) & (a ^ res) & sign_bit) != 0) else 0
        self.sf = 1 if (res & sign_bit) != 0 else 0
        self.zf = 1 if res == 0 else 0
        self.pf = self.compute_parity(res)
        # AF: Borrow from bit 4 into bit 3
        self.af = 1 if ((a & 0x0F) < ((b & 0x0F) + borrow_in)) else 0

    def update_inc(self, a: int, result: int, width: int = 8) -> None:
        """
        Updates flags after INC.
        IMPORTANT: INC alters OF, SF, ZF, AF, PF, but DOES NOT alter CF!
        """
        mask = 0xFF if width == 8 else 0xFFFF
        sign_bit = 0x80 if width == 8 else 0x8000
        res = result & mask

        # Overflow occurs if INC on max signed value (0x7F -> 0x80 or 0x7FFF -> 0x8000)
        self.of = 1 if a == (sign_bit - 1) else 0
        self.sf = 1 if (res & sign_bit) != 0 else 0
        self.zf = 1 if res == 0 else 0
        self.pf = self.compute_parity(res)
        self.af = 1 if ((a & 0x0F) == 0x0F) else 0

    def update_dec(self, a: int, result: int, width: int = 8) -> None:
        """
        Updates flags after DEC.
        IMPORTANT: DEC alters OF, SF, ZF, AF, PF, but DOES NOT alter CF!
        """
        mask = 0xFF if width == 8 else 0xFFFF
        sign_bit = 0x80 if width == 8 else 0x8000
        res = result & mask

        # Overflow occurs if DEC on min signed value (0x80 -> 0x7F or 0x8000 -> 0x7FFF)
        self.of = 1 if a == sign_bit else 0
        self.sf = 1 if (res & sign_bit) != 0 else 0
        self.zf = 1 if res == 0 else 0
        self.pf = self.compute_parity(res)
        self.af = 1 if ((a & 0x0F) == 0x00) else 0

    def update_neg(self, a: int, result: int, width: int = 8) -> None:
        """Updates flags after NEG."""
        mask = 0xFF if width == 8 else 0xFFFF
        sign_bit = 0x80 if width == 8 else 0x8000
        res = result & mask

        self.cf = 1 if a != 0 else 0
        self.of = 1 if a == sign_bit else 0
        self.sf = 1 if (res & sign_bit) != 0 else 0
        self.zf = 1 if res == 0 else 0
        self.pf = self.compute_parity(res)
        self.af = 1 if (a & 0x0F) != 0 else 0

    def update_logic(self, result: int, width: int = 8) -> None:
        """Updates flags after AND / OR / XOR / TEST."""
        mask = 0xFF if width == 8 else 0xFFFF
        sign_bit = 0x80 if width == 8 else 0x8000
        res = result & mask

        self.cf = 0
        self.of = 0
        self.af = 0
        self.sf = 1 if (res & sign_bit) != 0 else 0
        self.zf = 1 if res == 0 else 0
        self.pf = self.compute_parity(res)

    def get(self, name: str) -> int:
        n = name.lower()
        if n == "cf": return self.cf
        if n == "pf": return self.pf
        if n == "af": return self.af
        if n == "zf": return self.zf
        if n == "sf": return self.sf
        if n == "tf": return self.tf
        if n in ("if", "if_"): return self.if_
        if n == "df": return self.df
        if n == "of": return self.of
        raise KeyError(f"Unknown flag name: {name}")

    def set(self, name: str, val: int) -> None:
        n = name.lower()
        v = 1 if val else 0
        if n == "cf": self.cf = v
        elif n == "pf": self.pf = v
        elif n == "af": self.af = v
        elif n == "zf": self.zf = v
        elif n == "sf": self.sf = v
        elif n == "tf": self.tf = v
        elif n in ("if", "if_"): self.if_ = v
        elif n == "df": self.df = v
        elif n == "of": self.of = v
        else:
            raise KeyError(f"Unknown flag name: {name}")

    def to_dict(self) -> Dict[str, int]:
        return {
            "CF": self.cf,
            "PF": self.pf,
            "AF": self.af,
            "ZF": self.zf,
            "SF": self.sf,
            "TF": self.tf,
            "IF": self.if_,
            "DF": self.df,
            "OF": self.of,
        }

    def copy(self) -> Flags:
        f = Flags()
        f.cf = self.cf
        f.pf = self.pf
        f.af = self.af
        f.zf = self.zf
        f.sf = self.sf
        f.tf = self.tf
        f.if_ = self.if_
        f.df = self.df
        f.of = self.of
        return f
