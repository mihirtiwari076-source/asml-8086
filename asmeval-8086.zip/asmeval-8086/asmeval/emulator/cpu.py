"""
Headless CPU Execution Core for the Intel 8086 Processor in Real Mode.
Includes step hooks, cycle counting, memory segmentation, infinite loop guards,
and complete state inspection.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from .registers import Registers
from .flags import Flags
from .memory import Memory
from .interrupts import InterruptHandler
from .instructions import execute_instruction


@dataclass
class CPUTraceStep:
    cs: int
    ip: int
    opcode: int
    cycles: int
    registers: Dict[str, str]
    flags: Dict[str, int]


class CPU:
    """
    Simulates a Real Mode Intel 8086 microprocessor.
    """

    def __init__(self):
        self.registers = Registers()
        self.flags = Flags()
        self.memory = Memory()
        self.interrupts = InterruptHandler(self)

        self.cycles: int = 0
        self.instruction_count: int = 0
        self.halted: bool = False
        self.trace_enabled: bool = False
        self.trace_history: List[CPUTraceStep] = []
        self.step_hooks: List[Callable[[CPU], None]] = []

    def reset(self) -> None:
        self.registers.reset()
        self.flags.reset()
        self.memory.reset()
        self.interrupts.reset()
        self.cycles = 0
        self.instruction_count = 0
        self.halted = False
        self.trace_history.clear()

    # Code stream fetching
    def fetch_byte(self) -> int:
        b = self.memory.read_byte(self.registers.cs, self.registers.ip)
        self.registers.ip = (self.registers.ip + 1) & 0xFFFF
        return b

    def fetch_word(self) -> int:
        low = self.fetch_byte()
        high = self.fetch_byte()
        return (high << 8) | low

    def fetch_signed_byte(self) -> int:
        b = self.fetch_byte()
        return (b - 256) if (b & 0x80) else b

    def fetch_signed_word(self) -> int:
        w = self.fetch_word()
        return (w - 65536) if (w & 0x8000) else w

    # Stack operations (SS:SP)
    def push_word(self, val: int) -> None:
        self.registers.sp = (self.registers.sp - 2) & 0xFFFF
        self.memory.write_word(self.registers.ss, self.registers.sp, val)

    def pop_word(self) -> int:
        val = self.memory.read_word(self.registers.ss, self.registers.sp)
        self.registers.sp = (self.registers.sp + 2) & 0xFFFF
        return val

    # Binary loader
    def load_binary(
        self,
        data: bytes,
        segment: int = 0x1000,
        offset: int = 0x0100,
        set_ip: bool = True
    ) -> None:
        """Loads a raw binary into memory and sets CS:IP."""
        self.memory.write_bytes(segment, offset, data)
        if set_ip:
            self.registers.cs = segment
            self.registers.ip = offset
            self.registers.ds = segment
            self.registers.es = segment

    def add_step_hook(self, hook: Callable[[CPU], None]) -> None:
        self.step_hooks.append(hook)

    def step(self) -> int:
        """
        Executes a single instruction. Returns cycles consumed.
        """
        if self.halted:
            return 0

        current_cs = self.registers.cs
        current_ip = self.registers.ip

        for hook in self.step_hooks:
            hook(self)

        cycles_taken = execute_instruction(self)
        self.cycles += cycles_taken
        self.instruction_count += 1

        if self.trace_enabled:
            self.trace_history.append(CPUTraceStep(
                cs=current_cs,
                ip=current_ip,
                opcode=self.memory.read_byte(current_cs, current_ip),
                cycles=self.cycles,
                registers=self.registers.to_dict(),
                flags=self.flags.to_dict()
            ))

        return cycles_taken

    def run(self, max_cycles: int = 1_000_000) -> Dict[str, Any]:
        """
        Runs execution until halted or max_cycles is reached.
        """
        timed_out = False
        error_msg: Optional[str] = None

        try:
            while not self.halted and self.cycles < max_cycles:
                self.step()

            if not self.halted and self.cycles >= max_cycles:
                timed_out = True

        except Exception as e:
            error_msg = f"{type(e).__name__}: {str(e)}"
            self.halted = True

        return {
            "status": "TIMEOUT" if timed_out else ("ERROR" if error_msg else "PASSED"),
            "cycles_elapsed": self.cycles,
            "instructions_executed": self.instruction_count,
            "halted": self.halted,
            "timed_out": timed_out,
            "exit_code": self.interrupts.exit_code,
            "stdout": self.interrupts.get_stdout(),
            "error": error_msg,
            "final_registers": self.registers.to_dict(),
            "final_flags": self.flags.to_dict()
        }

    def setup_initial_state(self, initial_state: Dict[str, Any]) -> None:
        """
        Configures initial registers and memory patches from task definition.
        """
        def parse_num(v: Any) -> int:
            if isinstance(v, str):
                v_strip = v.strip()
                if v_strip.startswith("0x") or v_strip.startswith("0X"):
                    return int(v_strip, 16)
                if v_strip.endswith("h") or v_strip.endswith("H"):
                    return int(v_strip[:-1], 16)
                return int(v_strip)
            return int(v)

        # 1. Registers
        regs_dict = initial_state.get("registers", {})
        for name, val in regs_dict.items():
            self.registers.set(name, parse_num(val))

        # 2. Flags
        flags_dict = initial_state.get("flags", {})
        for name, val in flags_dict.items():
            self.flags.set(name, parse_num(val))

        # 3. Memory Patches
        patches = initial_state.get("memory_patches", [])
        for patch in patches:
            self.memory.apply_patch(patch)

    def snapshot(self) -> Dict[str, Any]:
        """Returns complete snapshot of CPU state."""
        return {
            "cycles": self.cycles,
            "instructions": self.instruction_count,
            "halted": self.halted,
            "exit_code": self.interrupts.exit_code,
            "registers": self.registers.to_dict(),
            "flags": self.flags.to_dict()
        }
