"""
Intel 8086 Instruction Set Decoder and Execution Handlers.
Covers Data Transfer, Arithmetic, Logic, Bit Shifts/Rotates, Strings,
Control Flow, Flags, and System Instructions.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Tuple

if TYPE_CHECKING:
    from .cpu import CPU


# Cycle estimates for nominal 8086 timing
CYCLE_MAP = {
    "alu_rr": 3,
    "alu_rm": 16,
    "alu_mr": 16,
    "alu_ri": 4,
    "alu_mi": 17,
    "mov_rr": 2,
    "mov_rm": 8,
    "mov_mr": 9,
    "mov_ri": 4,
    "mov_mi": 10,
    "mov_acc_m": 10,
    "mov_m_acc": 10,
    "inc_r": 2,
    "dec_r": 2,
    "inc_m": 15,
    "dec_m": 15,
    "push_r": 11,
    "pop_r": 8,
    "push_m": 16,
    "pop_m": 12,
    "jmp_direct": 15,
    "jmp_cond_taken": 16,
    "jmp_cond_not_taken": 4,
    "loop_taken": 17,
    "loop_not_taken": 5,
    "call_near": 19,
    "ret_near": 16,
    "int_call": 51,
    "iret": 32,
    "nop": 3,
    "string_single": 17,
    "default": 4
}


def decode_modrm(cpu: CPU, seg_override: int | None = None) -> Tuple[bool, int, int, int, int]:
    """
    Decodes the ModR/M byte.
    Returns: (is_reg, reg, rm, ea_segment, ea_offset)
    """
    b = cpu.fetch_byte()
    mod = (b >> 6) & 3
    reg = (b >> 3) & 7
    rm = b & 7

    if mod == 3:
        # Register addressing mode
        return True, reg, rm, 0, 0

    # Memory addressing mode: calculate effective address
    regs = cpu.registers
    ea_offset = 0
    default_seg = regs.ds

    if rm == 0:
        ea_offset = regs.bx + regs.si
    elif rm == 1:
        ea_offset = regs.bx + regs.di
    elif rm == 2:
        ea_offset = regs.bp + regs.si
        default_seg = regs.ss
    elif rm == 3:
        ea_offset = regs.bp + regs.di
        default_seg = regs.ss
    elif rm == 4:
        ea_offset = regs.si
    elif rm == 5:
        ea_offset = regs.di
    elif rm == 6:
        if mod == 0:
            # Direct 16-bit address
            ea_offset = cpu.fetch_word()
            default_seg = regs.ds
        else:
            ea_offset = regs.bp
            default_seg = regs.ss
    elif rm == 7:
        ea_offset = regs.bx

    # Apply displacement
    if mod == 1:
        disp8 = cpu.fetch_signed_byte()
        ea_offset += disp8
    elif mod == 2:
        disp16 = cpu.fetch_word()
        ea_offset += disp16

    ea_offset &= 0xFFFF
    seg = seg_override if seg_override is not None else default_seg
    return False, reg, rm, seg, ea_offset


def read_operand8(cpu: CPU, is_reg: bool, rm: int, seg: int, offset: int) -> int:
    if is_reg:
        return cpu.registers.get_reg8(rm)
    return cpu.memory.read_byte(seg, offset)


def write_operand8(cpu: CPU, is_reg: bool, rm: int, seg: int, offset: int, val: int) -> None:
    if is_reg:
        cpu.registers.set_reg8(rm, val)
    else:
        cpu.memory.write_byte(seg, offset, val)


def read_operand16(cpu: CPU, is_reg: bool, rm: int, seg: int, offset: int) -> int:
    if is_reg:
        return cpu.registers.get_reg16(rm)
    return cpu.memory.read_word(seg, offset)


def write_operand16(cpu: CPU, is_reg: bool, rm: int, seg: int, offset: int, val: int) -> None:
    if is_reg:
        cpu.registers.set_reg16(rm, val)
    else:
        cpu.memory.write_word(seg, offset, val)


def execute_alu8(cpu: CPU, op: int, dst: int, src: int) -> int:
    """Executes 8-bit ALU operation (0: ADD, 1: OR, 2: ADC, 3: SBB, 4: AND, 5: SUB, 6: XOR, 7: CMP)."""
    flags = cpu.flags
    match op:
        case 0:  # ADD
            res = (dst + src) & 0xFF
            flags.update_add(dst, src, res, width=8, carry_in=0)
            return res
        case 1:  # OR
            res = (dst | src) & 0xFF
            flags.update_logic(res, width=8)
            return res
        case 2:  # ADC
            c = flags.cf
            res = (dst + src + c) & 0xFF
            flags.update_add(dst, src, res, width=8, carry_in=c)
            return res
        case 3:  # SBB
            b = flags.cf
            res = (dst - src - b) & 0xFF
            flags.update_sub(dst, src, res, width=8, borrow_in=b)
            return res
        case 4:  # AND
            res = (dst & src) & 0xFF
            flags.update_logic(res, width=8)
            return res
        case 5:  # SUB
            res = (dst - src) & 0xFF
            flags.update_sub(dst, src, res, width=8, borrow_in=0)
            return res
        case 6:  # XOR
            res = (dst ^ src) & 0xFF
            flags.update_logic(res, width=8)
            return res
        case 7:  # CMP
            res = (dst - src) & 0xFF
            flags.update_sub(dst, src, res, width=8, borrow_in=0)
            return dst  # CMP does not write back
    return dst


def execute_alu16(cpu: CPU, op: int, dst: int, src: int) -> int:
    """Executes 16-bit ALU operation."""
    flags = cpu.flags
    match op:
        case 0:  # ADD
            res = (dst + src) & 0xFFFF
            flags.update_add(dst, src, res, width=16, carry_in=0)
            return res
        case 1:  # OR
            res = (dst | src) & 0xFFFF
            flags.update_logic(res, width=16)
            return res
        case 2:  # ADC
            c = flags.cf
            res = (dst + src + c) & 0xFFFF
            flags.update_add(dst, src, res, width=16, carry_in=c)
            return res
        case 3:  # SBB
            b = flags.cf
            res = (dst - src - b) & 0xFFFF
            flags.update_sub(dst, src, res, width=16, borrow_in=b)
            return res
        case 4:  # AND
            res = (dst & src) & 0xFFFF
            flags.update_logic(res, width=16)
            return res
        case 5:  # SUB
            res = (dst - src) & 0xFFFF
            flags.update_sub(dst, src, res, width=16, borrow_in=0)
            return res
        case 6:  # XOR
            res = (dst ^ src) & 0xFFFF
            flags.update_logic(res, width=16)
            return res
        case 7:  # CMP
            res = (dst - src) & 0xFFFF
            flags.update_sub(dst, src, res, width=16, borrow_in=0)
            return dst  # CMP does not write back
    return dst


def execute_shift_rotate8(cpu: CPU, op: int, val: int, count: int) -> int:
    """Executes 8-bit shift or rotate."""
    if count == 0:
        return val
    flags = cpu.flags
    res = val & 0xFF
    for _ in range(count):
        last_cf = flags.cf
        match op:
            case 0:  # ROL
                flags.cf = (res >> 7) & 1
                res = ((res << 1) | flags.cf) & 0xFF
                if count == 1:
                    flags.of = ((res >> 7) & 1) ^ flags.cf
            case 1:  # ROR
                flags.cf = res & 1
                res = ((res >> 1) | (flags.cf << 7)) & 0xFF
                if count == 1:
                    flags.of = ((res >> 7) & 1) ^ ((res >> 6) & 1)
            case 2:  # RCL
                c = flags.cf
                flags.cf = (res >> 7) & 1
                res = ((res << 1) | c) & 0xFF
                if count == 1:
                    flags.of = ((res >> 7) & 1) ^ flags.cf
            case 3:  # RCR
                c = flags.cf
                flags.cf = res & 1
                res = ((res >> 1) | (c << 7)) & 0xFF
                if count == 1:
                    flags.of = ((res >> 7) & 1) ^ ((res >> 6) & 1)
            case 4 | 6:  # SHL / SAL
                flags.cf = (res >> 7) & 1
                res = (res << 1) & 0xFF
                if count == 1:
                    flags.of = ((res >> 7) & 1) ^ flags.cf
            case 5:  # SHR
                flags.cf = res & 1
                orig_msb = (res >> 7) & 1
                res = (res >> 1) & 0xFF
                if count == 1:
                    flags.of = orig_msb
            case 7:  # SAR
                flags.cf = res & 1
                msb = res & 0x80
                res = (res >> 1) | msb
                if count == 1:
                    flags.of = 0

    if op in (4, 5, 6, 7):
        flags.sf = 1 if (res & 0x80) else 0
        flags.zf = 1 if res == 0 else 0
        flags.pf = flags.compute_parity(res)
    return res


def execute_shift_rotate16(cpu: CPU, op: int, val: int, count: int) -> int:
    """Executes 16-bit shift or rotate."""
    if count == 0:
        return val
    flags = cpu.flags
    res = val & 0xFFFF
    for _ in range(count):
        match op:
            case 0:  # ROL
                flags.cf = (res >> 15) & 1
                res = ((res << 1) | flags.cf) & 0xFFFF
                if count == 1:
                    flags.of = ((res >> 15) & 1) ^ flags.cf
            case 1:  # ROR
                flags.cf = res & 1
                res = ((res >> 1) | (flags.cf << 15)) & 0xFFFF
                if count == 1:
                    flags.of = ((res >> 15) & 1) ^ ((res >> 14) & 1)
            case 2:  # RCL
                c = flags.cf
                flags.cf = (res >> 15) & 1
                res = ((res << 1) | c) & 0xFFFF
                if count == 1:
                    flags.of = ((res >> 15) & 1) ^ flags.cf
            case 3:  # RCR
                c = flags.cf
                flags.cf = res & 1
                res = ((res >> 1) | (c << 15)) & 0xFFFF
                if count == 1:
                    flags.of = ((res >> 15) & 1) ^ ((res >> 14) & 1)
            case 4 | 6:  # SHL / SAL
                flags.cf = (res >> 15) & 1
                res = (res << 1) & 0xFFFF
                if count == 1:
                    flags.of = ((res >> 15) & 1) ^ flags.cf
            case 5:  # SHR
                flags.cf = res & 1
                orig_msb = (res >> 15) & 1
                res = (res >> 1) & 0xFFFF
                if count == 1:
                    flags.of = orig_msb
            case 7:  # SAR
                flags.cf = res & 1
                msb = res & 0x8000
                res = (res >> 1) | msb
                if count == 1:
                    flags.of = 0

    if op in (4, 5, 6, 7):
        flags.sf = 1 if (res & 0x8000) else 0
        flags.zf = 1 if res == 0 else 0
        flags.pf = flags.compute_parity(res)
    return res


def execute_instruction(cpu: CPU) -> int:
    """
    Decodes and executes a single 8086 instruction from CS:IP.
    Returns the cycle count taken.
    """
    regs = cpu.registers
    mem = cpu.memory
    flags = cpu.flags

    seg_override: int | None = None
    rep_prefix: int | None = None  # 0xF3 (REP/REPE), 0xF2 (REPNE)

    # Decode prefixes
    while True:
        opcode = cpu.fetch_byte()
        if opcode == 0x26:  # ES:
            seg_override = regs.es
        elif opcode == 0x2E:  # CS:
            seg_override = regs.cs
        elif opcode == 0x36:  # SS:
            seg_override = regs.ss
        elif opcode == 0x3E:  # DS:
            seg_override = regs.ds
        elif opcode == 0xF3:  # REP / REPE / REPZ
            rep_prefix = 0xF3
        elif opcode == 0xF2:  # REPNE / REPNZ
            rep_prefix = 0xF2
        elif opcode == 0xF0:  # LOCK
            pass
        else:
            break

    # Source segment for memory reads
    eff_ds = seg_override if seg_override is not None else regs.ds

    # --- 1. ALU Operations (ADD, OR, ADC, SBB, AND, SUB, XOR, CMP) ---
    # 00-05: ADD
    # 08-0D: OR
    # 10-15: ADC
    # 18-1D: SBB
    # 20-25: AND
    # 28-2D: SUB
    # 30-35: XOR
    # 38-3D: CMP
    if (opcode & 0xC4) == 0x00 and (opcode & 0x38) in (0x00, 0x08, 0x10, 0x18, 0x20, 0x28, 0x30, 0x38):
        alu_op = (opcode >> 3) & 7
        dir_to_reg = (opcode >> 1) & 1
        is_word = opcode & 1

        is_reg, reg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if not is_word:
            r_val = regs.get_reg8(reg_idx)
            rm_val = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            if dir_to_reg:
                res = execute_alu8(cpu, alu_op, r_val, rm_val)
                if alu_op != 7:
                    regs.set_reg8(reg_idx, res)
            else:
                res = execute_alu8(cpu, alu_op, rm_val, r_val)
                if alu_op != 7:
                    write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
            return CYCLE_MAP["alu_rr"] if is_reg else CYCLE_MAP["alu_rm"]
        else:
            r_val = regs.get_reg16(reg_idx)
            rm_val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            if dir_to_reg:
                res = execute_alu16(cpu, alu_op, r_val, rm_val)
                if alu_op != 7:
                    regs.set_reg16(reg_idx, res)
            else:
                res = execute_alu16(cpu, alu_op, rm_val, r_val)
                if alu_op != 7:
                    write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
            return CYCLE_MAP["alu_rr"] if is_reg else CYCLE_MAP["alu_rm"]

    # ALU with Immediate to Accumulator: 04, 05, 0C, 0D, 14, 15, 1C, 1D, 24, 25, 2C, 2D, 34, 35, 3C, 3D
    if (opcode & 0xC6) == 0x04:
        alu_op = (opcode >> 3) & 7
        is_word = opcode & 1
        if not is_word:
            imm8 = cpu.fetch_byte()
            res = execute_alu8(cpu, alu_op, regs.al, imm8)
            if alu_op != 7:
                regs.al = res
        else:
            imm16 = cpu.fetch_word()
            res = execute_alu16(cpu, alu_op, regs.ax, imm16)
            if alu_op != 7:
                regs.ax = res
        return CYCLE_MAP["alu_ri"]

    # Segment Register Pushes & Pops: PUSH sreg (06, 0E, 16, 1E), POP sreg (07, 17, 1F)
    if (opcode & 0xE7) == 0x06:
        sreg_idx = (opcode >> 3) & 3
        cpu.push_word(regs.get_sreg(sreg_idx))
        return CYCLE_MAP["push_r"]
    if (opcode & 0xE7) == 0x07:
        sreg_idx = (opcode >> 3) & 3
        regs.set_sreg(sreg_idx, cpu.pop_word())
        return CYCLE_MAP["pop_r"]

    # DAA, DAS, AAA, AAS
    if opcode == 0x27:  # DAA
        al = regs.al
        old_al = al
        old_cf = flags.cf
        flags.cf = 0
        if (al & 0x0F) > 9 or flags.af:
            al = (al + 6) & 0xFF
            flags.af = 1
        else:
            flags.af = 0
        if old_al > 0x99 or old_cf:
            al = (al + 0x60) & 0xFF
            flags.cf = 1
        else:
            flags.cf = 0
        regs.al = al
        flags.sf = 1 if (al & 0x80) else 0
        flags.zf = 1 if al == 0 else 0
        flags.pf = flags.compute_parity(al)
        return CYCLE_MAP["default"]

    if opcode == 0x2F:  # DAS
        al = regs.al
        old_al = al
        old_cf = flags.cf
        flags.cf = 0
        if (al & 0x0F) > 9 or flags.af:
            al = (al - 6) & 0xFF
            flags.af = 1
        else:
            flags.af = 0
        if old_al > 0x99 or old_cf:
            al = (al - 0x60) & 0xFF
            flags.cf = 1
        else:
            flags.cf = 0
        regs.al = al
        flags.sf = 1 if (al & 0x80) else 0
        flags.zf = 1 if al == 0 else 0
        flags.pf = flags.compute_parity(al)
        return CYCLE_MAP["default"]

    if opcode == 0x37:  # AAA
        if (regs.al & 0x0F) > 9 or flags.af:
            regs.al = (regs.al + 6) & 0x0F
            regs.ah = (regs.ah + 1) & 0xFF
            flags.af = 1
            flags.cf = 1
        else:
            regs.al = regs.al & 0x0F
            flags.af = 0
            flags.cf = 0
        return CYCLE_MAP["default"]

    if opcode == 0x3F:  # AAS
        if (regs.al & 0x0F) > 9 or flags.af:
            regs.al = (regs.al - 6) & 0x0F
            regs.ah = (regs.ah - 1) & 0xFF
            flags.af = 1
            flags.cf = 1
        else:
            regs.al = regs.al & 0x0F
            flags.af = 0
            flags.cf = 0
        return CYCLE_MAP["default"]

    # INC r16 (40 - 47) & DEC r16 (48 - 4F)
    if (opcode & 0xF8) == 0x40:
        reg_idx = opcode & 7
        val = regs.get_reg16(reg_idx)
        res = (val + 1) & 0xFFFF
        flags.update_inc(val, res, width=16)
        regs.set_reg16(reg_idx, res)
        return CYCLE_MAP["inc_r"]
    if (opcode & 0xF8) == 0x48:
        reg_idx = opcode & 7
        val = regs.get_reg16(reg_idx)
        res = (val - 1) & 0xFFFF
        flags.update_dec(val, res, width=16)
        regs.set_reg16(reg_idx, res)
        return CYCLE_MAP["dec_r"]

    # PUSH r16 (50 - 57) & POP r16 (58 - 5F)
    if (opcode & 0xF8) == 0x50:
        reg_idx = opcode & 7
        cpu.push_word(regs.get_reg16(reg_idx))
        return CYCLE_MAP["push_r"]
    if (opcode & 0xF8) == 0x58:
        reg_idx = opcode & 7
        regs.set_reg16(reg_idx, cpu.pop_word())
        return CYCLE_MAP["pop_r"]

    # PUSH imm16 (68) & PUSH imm8 (6A)
    if opcode == 0x68:
        imm16 = cpu.fetch_word()
        cpu.push_word(imm16)
        return CYCLE_MAP["push_r"]
    if opcode == 0x6A:
        imm8 = cpu.fetch_signed_byte()
        cpu.push_word(imm8 & 0xFFFF)
        return CYCLE_MAP["push_r"]

    # Short Conditional Jumps (70 - 7F)
    if (opcode & 0xF0) == 0x70:
        disp8 = cpu.fetch_signed_byte()
        cond = False
        match opcode & 0x0F:
            case 0x0: cond = flags.of == 1                        # JO
            case 0x1: cond = flags.of == 0                        # JNO
            case 0x2: cond = flags.cf == 1                        # JB / JC / JNAE
            case 0x3: cond = flags.cf == 0                        # JNB / JNC / JAE
            case 0x4: cond = flags.zf == 1                        # JZ / JE
            case 0x5: cond = flags.zf == 0                        # JNZ / JNE
            case 0x6: cond = (flags.cf == 1 or flags.zf == 1)     # JBE / JNA
            case 0x7: cond = (flags.cf == 0 and flags.zf == 0)    # JNBE / JA
            case 0x8: cond = flags.sf == 1                        # JS
            case 0x9: cond = flags.sf == 0                        # JNS
            case 0xA: cond = flags.pf == 1                        # JP / JPE
            case 0xB: cond = flags.pf == 0                        # JNP / JPO
            case 0xC: cond = (flags.sf != flags.of)               # JL / JNGE
            case 0xD: cond = (flags.sf == flags.of)               # JNL / JGE
            case 0xE: cond = (flags.zf == 1 or flags.sf != flags.of) # JLE / JNG
            case 0xF: cond = (flags.zf == 0 and flags.sf == flags.of) # JNLE / JG

        if cond:
            regs.ip = (regs.ip + disp8) & 0xFFFF
            return CYCLE_MAP["jmp_cond_taken"]
        return CYCLE_MAP["jmp_cond_not_taken"]

    # Grp1: 80, 81, 82, 83 (ALU rm, imm)
    if opcode in (0x80, 0x81, 0x82, 0x83):
        is_reg, alu_op, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if opcode in (0x80, 0x82):
            dst = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            imm8 = cpu.fetch_byte()
            res = execute_alu8(cpu, alu_op, dst, imm8)
            if alu_op != 7:
                write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
            return CYCLE_MAP["alu_ri"] if is_reg else CYCLE_MAP["alu_mi"]
        elif opcode == 0x81:
            dst = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            imm16 = cpu.fetch_word()
            res = execute_alu16(cpu, alu_op, dst, imm16)
            if alu_op != 7:
                write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
            return CYCLE_MAP["alu_ri"] if is_reg else CYCLE_MAP["alu_mi"]
        elif opcode == 0x83:
            dst = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            # Sign extend 8-bit immediate to 16 bits
            imm_signed = cpu.fetch_signed_byte()
            imm16 = imm_signed & 0xFFFF
            res = execute_alu16(cpu, alu_op, dst, imm16)
            if alu_op != 7:
                write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
            return CYCLE_MAP["alu_ri"] if is_reg else CYCLE_MAP["alu_mi"]

    # TEST rm, r (84, 85)
    if opcode in (0x84, 0x85):
        is_word = opcode & 1
        is_reg, reg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if not is_word:
            r_val = regs.get_reg8(reg_idx)
            rm_val = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            flags.update_logic((r_val & rm_val) & 0xFF, width=8)
        else:
            r_val = regs.get_reg16(reg_idx)
            rm_val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            flags.update_logic((r_val & rm_val) & 0xFFFF, width=16)
        return CYCLE_MAP["alu_rr"] if is_reg else CYCLE_MAP["alu_rm"]

    # XCHG rm, r (86, 87)
    if opcode in (0x86, 0x87):
        is_word = opcode & 1
        is_reg, reg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if not is_word:
            r_val = regs.get_reg8(reg_idx)
            rm_val = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            regs.set_reg8(reg_idx, rm_val)
            write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, r_val)
        else:
            r_val = regs.get_reg16(reg_idx)
            rm_val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            regs.set_reg16(reg_idx, rm_val)
            write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, r_val)
        return CYCLE_MAP["mov_rr"] if is_reg else CYCLE_MAP["mov_mr"]

    # MOV rm, r & r, rm (88 - 8B)
    if (opcode & 0xFC) == 0x88:
        dir_to_reg = (opcode >> 1) & 1
        is_word = opcode & 1
        is_reg, reg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if not is_word:
            if dir_to_reg:
                val = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
                regs.set_reg8(reg_idx, val)
                return CYCLE_MAP["mov_rr"] if is_reg else CYCLE_MAP["mov_rm"]
            else:
                val = regs.get_reg8(reg_idx)
                write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, val)
                return CYCLE_MAP["mov_rr"] if is_reg else CYCLE_MAP["mov_mr"]
        else:
            if dir_to_reg:
                val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
                regs.set_reg16(reg_idx, val)
                return CYCLE_MAP["mov_rr"] if is_reg else CYCLE_MAP["mov_rm"]
            else:
                val = regs.get_reg16(reg_idx)
                write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, val)
                return CYCLE_MAP["mov_rr"] if is_reg else CYCLE_MAP["mov_mr"]

    # MOV rm16, sreg (8C) & MOV sreg, rm16 (8E)
    if opcode == 0x8C:
        is_reg, sreg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        val = regs.get_sreg(sreg_idx)
        write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, val)
        return CYCLE_MAP["mov_rr"] if is_reg else CYCLE_MAP["mov_mr"]
    if opcode == 0x8E:
        is_reg, sreg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
        regs.set_sreg(sreg_idx, val)
        return CYCLE_MAP["mov_rr"] if is_reg else CYCLE_MAP["mov_rm"]

    # LEA r16, m (8D)
    if opcode == 0x8D:
        is_reg, reg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        regs.set_reg16(reg_idx, ea_offset)
        return CYCLE_MAP["alu_rr"]

    # POP rm16 (8F)
    if opcode == 0x8F:
        is_reg, _, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        val = cpu.pop_word()
        write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, val)
        return CYCLE_MAP["pop_r"] if is_reg else CYCLE_MAP["pop_m"]

    # NOP / XCHG AX, r16 (90 - 97)
    if (opcode & 0xF8) == 0x90:
        reg_idx = opcode & 7
        if reg_idx == 0:
            return CYCLE_MAP["nop"]  # NOP
        val = regs.get_reg16(reg_idx)
        regs.set_reg16(reg_idx, regs.ax)
        regs.ax = val
        return CYCLE_MAP["mov_rr"]

    # CBW (98) & CWD (99)
    if opcode == 0x98:  # CBW
        regs.ax = (regs.al | 0xFF00) if (regs.al & 0x80) else regs.al
        return CYCLE_MAP["default"]
    if opcode == 0x99:  # CWD
        regs.dx = 0xFFFF if (regs.ax & 0x8000) else 0x0000
        return CYCLE_MAP["default"]

    # CALL far direct (9A)
    if opcode == 0x9A:
        new_ip = cpu.fetch_word()
        new_cs = cpu.fetch_word()
        cpu.push_word(regs.cs)
        cpu.push_word(regs.ip)
        regs.cs = new_cs
        regs.ip = new_ip
        return CYCLE_MAP["call_near"] + 10

    # WAIT (9B)
    if opcode == 0x9B:
        return CYCLE_MAP["default"]

    # PUSHF (9C) & POPF (9D)
    if opcode == 0x9C:
        cpu.push_word(flags.pack())
        return CYCLE_MAP["push_r"]
    if opcode == 0x9D:
        flags.unpack(cpu.pop_word())
        return CYCLE_MAP["pop_r"]

    # SAHF (9E) & LAHF (9F)
    if opcode == 0x9E:  # SAHF
        # Load SF, ZF, AF, PF, CF from AH
        ah = regs.ah
        flags.sf = 1 if (ah & 0x80) else 0
        flags.zf = 1 if (ah & 0x40) else 0
        flags.af = 1 if (ah & 0x10) else 0
        flags.pf = 1 if (ah & 0x04) else 0
        flags.cf = 1 if (ah & 0x01) else 0
        return CYCLE_MAP["default"]
    if opcode == 0x9F:  # LAHF
        # Load AH from flags
        ah = 0x02  # bit 1 always 1
        if flags.sf: ah |= 0x80
        if flags.zf: ah |= 0x40
        if flags.af: ah |= 0x10
        if flags.pf: ah |= 0x04
        if flags.cf: ah |= 0x01
        regs.ah = ah
        return CYCLE_MAP["default"]

    # MOV AL/AX, [disp16] and [disp16], AL/AX (A0 - A3)
    if opcode == 0xA0:
        addr = cpu.fetch_word()
        regs.al = mem.read_byte(eff_ds, addr)
        return CYCLE_MAP["mov_acc_m"]
    if opcode == 0xA1:
        addr = cpu.fetch_word()
        regs.ax = mem.read_word(eff_ds, addr)
        return CYCLE_MAP["mov_acc_m"]
    if opcode == 0xA2:
        addr = cpu.fetch_word()
        mem.write_byte(eff_ds, addr, regs.al)
        return CYCLE_MAP["mov_m_acc"]
    if opcode == 0xA3:
        addr = cpu.fetch_word()
        mem.write_word(eff_ds, addr, regs.ax)
        return CYCLE_MAP["mov_m_acc"]

    # String Operations: MOVSB, MOVSW, CMPSB, CMPSW, STOSB, STOSW, LODSB, LODSW, SCASB, SCASW (A4 - AF)
    if opcode in (0xA4, 0xA5, 0xA6, 0xA7, 0xAA, 0xAB, 0xAC, 0xAD, 0xAE, 0xAF):
        delta = -1 if flags.df else 1
        delta_w = -2 if flags.df else 2

        def execute_single_str_op():
            nonlocal delta, delta_w
            if opcode == 0xA4:  # MOVSB
                b = mem.read_byte(eff_ds, regs.si)
                mem.write_byte(regs.es, regs.di, b)
                regs.si = (regs.si + delta) & 0xFFFF
                regs.di = (regs.di + delta) & 0xFFFF
            elif opcode == 0xA5:  # MOVSW
                w = mem.read_word(eff_ds, regs.si)
                mem.write_word(regs.es, regs.di, w)
                regs.si = (regs.si + delta_w) & 0xFFFF
                regs.di = (regs.di + delta_w) & 0xFFFF
            elif opcode == 0xA6:  # CMPSB
                b1 = mem.read_byte(eff_ds, regs.si)
                b2 = mem.read_byte(regs.es, regs.di)
                execute_alu8(cpu, 7, b1, b2)  # CMP sets flags
                regs.si = (regs.si + delta) & 0xFFFF
                regs.di = (regs.di + delta) & 0xFFFF
            elif opcode == 0xA7:  # CMPSW
                w1 = mem.read_word(eff_ds, regs.si)
                w2 = mem.read_word(regs.es, regs.di)
                execute_alu16(cpu, 7, w1, w2)
                regs.si = (regs.si + delta_w) & 0xFFFF
                regs.di = (regs.di + delta_w) & 0xFFFF
            elif opcode == 0xAA:  # STOSB
                mem.write_byte(regs.es, regs.di, regs.al)
                regs.di = (regs.di + delta) & 0xFFFF
            elif opcode == 0xAB:  # STOSW
                mem.write_word(regs.es, regs.di, regs.ax)
                regs.di = (regs.di + delta_w) & 0xFFFF
            elif opcode == 0xAC:  # LODSB
                regs.al = mem.read_byte(eff_ds, regs.si)
                regs.si = (regs.si + delta) & 0xFFFF
            elif opcode == 0xAD:  # LODSW
                regs.ax = mem.read_word(eff_ds, regs.si)
                regs.si = (regs.si + delta_w) & 0xFFFF
            elif opcode == 0xAE:  # SCASB
                b = mem.read_byte(regs.es, regs.di)
                execute_alu8(cpu, 7, regs.al, b)
                regs.di = (regs.di + delta) & 0xFFFF
            elif opcode == 0xAF:  # SCASW
                w = mem.read_word(regs.es, regs.di)
                execute_alu16(cpu, 7, regs.ax, w)
                regs.di = (regs.di + delta_w) & 0xFFFF

        if rep_prefix is None:
            execute_single_str_op()
            return CYCLE_MAP["string_single"]
        else:
            total_cycles = 0
            while regs.cx != 0:
                execute_single_str_op()
                regs.cx = (regs.cx - 1) & 0xFFFF
                total_cycles += CYCLE_MAP["string_single"]

                # CMPS / SCAS conditionals:
                if opcode in (0xA6, 0xA7, 0xAE, 0xAF):
                    if rep_prefix == 0xF3 and flags.zf == 0:  # REPE / REPZ
                        break
                    elif rep_prefix == 0xF2 and flags.zf == 1:  # REPNE / REPNZ
                        break
            return max(total_cycles, CYCLE_MAP["default"])

    # TEST AL/AX, imm (A8, A9)
    if opcode == 0xA8:
        imm = cpu.fetch_byte()
        flags.update_logic((regs.al & imm) & 0xFF, width=8)
        return CYCLE_MAP["alu_ri"]
    if opcode == 0xA9:
        imm = cpu.fetch_word()
        flags.update_logic((regs.ax & imm) & 0xFFFF, width=16)
        return CYCLE_MAP["alu_ri"]

    # MOV r8, imm8 (B0 - B7)
    if (opcode & 0xF8) == 0xB0:
        reg_idx = opcode & 7
        imm8 = cpu.fetch_byte()
        regs.set_reg8(reg_idx, imm8)
        return CYCLE_MAP["mov_ri"]

    # MOV r16, imm16 (B8 - BF)
    if (opcode & 0xF8) == 0xB8:
        reg_idx = opcode & 7
        imm16 = cpu.fetch_word()
        regs.set_reg16(reg_idx, imm16)
        return CYCLE_MAP["mov_ri"]

    # RET near imm16 (C2) & RET near (C3)
    if opcode == 0xC2:
        imm = cpu.fetch_word()
        regs.ip = cpu.pop_word()
        regs.sp = (regs.sp + imm) & 0xFFFF
        return CYCLE_MAP["ret_near"]
    if opcode == 0xC3:
        regs.ip = cpu.pop_word()
        return CYCLE_MAP["ret_near"]

    # LES (C4) & LDS (C5)
    if opcode in (0xC4, 0xC5):
        is_reg, reg_idx, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        ptr_offset = mem.read_word(ea_seg, ea_offset)
        ptr_seg = mem.read_word(ea_seg, (ea_offset + 2) & 0xFFFF)
        regs.set_reg16(reg_idx, ptr_offset)
        if opcode == 0xC4:
            regs.es = ptr_seg
        else:
            regs.ds = ptr_seg
        return CYCLE_MAP["mov_rm"] + 8

    # MOV rm, imm (C6: rm8, imm8; C7: rm16, imm16)
    if opcode in (0xC6, 0xC7):
        is_word = opcode & 1
        is_reg, _, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if not is_word:
            imm8 = cpu.fetch_byte()
            write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, imm8)
            return CYCLE_MAP["mov_ri"] if is_reg else CYCLE_MAP["mov_mi"]
        else:
            imm16 = cpu.fetch_word()
            write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, imm16)
            return CYCLE_MAP["mov_ri"] if is_reg else CYCLE_MAP["mov_mi"]

    # RET far imm16 (CA) & RET far (CB)
    if opcode == 0xCA:
        imm = cpu.fetch_word()
        regs.ip = cpu.pop_word()
        regs.cs = cpu.pop_word()
        regs.sp = (regs.sp + imm) & 0xFFFF
        return CYCLE_MAP["ret_near"] + 4
    if opcode == 0xCB:
        regs.ip = cpu.pop_word()
        regs.cs = cpu.pop_word()
        return CYCLE_MAP["ret_near"] + 4

    # INT 3 (CC) & INT imm8 (CD) & INTO (CE) & IRET (CF)
    if opcode == 0xCC:
        cpu.interrupts.handle_interrupt(3)
        return CYCLE_MAP["int_call"]
    if opcode == 0xCD:
        vec = cpu.fetch_byte()
        cpu.interrupts.handle_interrupt(vec)
        return CYCLE_MAP["int_call"]
    if opcode == 0xCE:
        if flags.of == 1:
            cpu.interrupts.handle_interrupt(4)
            return CYCLE_MAP["int_call"]
        return CYCLE_MAP["default"]
    if opcode == 0xCF:  # IRET
        regs.ip = cpu.pop_word()
        regs.cs = cpu.pop_word()
        flags.unpack(cpu.pop_word())
        return CYCLE_MAP["iret"]

    # Grp2 Shifts & Rotates (D0, D1, D2, D3, and 186+ C0, C1)
    if opcode in (0xD0, 0xD1, 0xD2, 0xD3, 0xC0, 0xC1):
        is_word = opcode & 1
        is_reg, shift_op, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if opcode in (0xC0, 0xC1):
            count = cpu.fetch_byte() & 0x1F
        elif opcode in (0xD0, 0xD1):
            count = 1
        else:
            count = regs.cl

        if not is_word:
            val = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            res = execute_shift_rotate8(cpu, shift_op, val, count)
            write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
        else:
            val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            res = execute_shift_rotate16(cpu, shift_op, val, count)
            write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
        return CYCLE_MAP["alu_rr"] if is_reg else CYCLE_MAP["alu_rm"]

    # AAM (D4) & AAD (D5)
    if opcode == 0xD4:
        base = cpu.fetch_byte()
        if base == 0:
            cpu.interrupts.handle_interrupt(0)  # Divide error
        else:
            al = regs.al
            regs.ah = (al // base) & 0xFF
            regs.al = (al % base) & 0xFF
            flags.sf = 1 if (regs.al & 0x80) else 0
            flags.zf = 1 if regs.al == 0 else 0
            flags.pf = flags.compute_parity(regs.al)
        return CYCLE_MAP["default"] + 10
    if opcode == 0xD5:
        base = cpu.fetch_byte()
        regs.al = (regs.al + regs.ah * base) & 0xFF
        regs.ah = 0
        flags.sf = 1 if (regs.al & 0x80) else 0
        flags.zf = 1 if regs.al == 0 else 0
        flags.pf = flags.compute_parity(regs.al)
        return CYCLE_MAP["default"] + 10

    # XLATB (D7)
    if opcode == 0xD7:
        addr = (regs.bx + regs.al) & 0xFFFF
        regs.al = mem.read_byte(eff_ds, addr)
        return CYCLE_MAP["default"] + 7

    # LOOPNE (E0), LOOPE (E1), LOOP (E2), JCXZ (E3)
    if opcode == 0xE0:  # LOOPNE / LOOPNZ
        disp8 = cpu.fetch_signed_byte()
        regs.cx = (regs.cx - 1) & 0xFFFF
        if regs.cx != 0 and flags.zf == 0:
            regs.ip = (regs.ip + disp8) & 0xFFFF
            return CYCLE_MAP["loop_taken"]
        return CYCLE_MAP["loop_not_taken"]
    if opcode == 0xE1:  # LOOPE / LOOPZ
        disp8 = cpu.fetch_signed_byte()
        regs.cx = (regs.cx - 1) & 0xFFFF
        if regs.cx != 0 and flags.zf == 1:
            regs.ip = (regs.ip + disp8) & 0xFFFF
            return CYCLE_MAP["loop_taken"]
        return CYCLE_MAP["loop_not_taken"]
    if opcode == 0xE2:  # LOOP
        disp8 = cpu.fetch_signed_byte()
        regs.cx = (regs.cx - 1) & 0xFFFF
        if regs.cx != 0:
            regs.ip = (regs.ip + disp8) & 0xFFFF
            return CYCLE_MAP["loop_taken"]
        return CYCLE_MAP["loop_not_taken"]
    if opcode == 0xE3:  # JCXZ
        disp8 = cpu.fetch_signed_byte()
        if regs.cx == 0:
            regs.ip = (regs.ip + disp8) & 0xFFFF
            return CYCLE_MAP["jmp_cond_taken"]
        return CYCLE_MAP["jmp_cond_not_taken"]

    # IN / OUT (E4 - E7, EC - EF) - stubbed
    if opcode in (0xE4, 0xE5, 0xE6, 0xE7, 0xEC, 0xED, 0xEE, 0xEF):
        if opcode in (0xE4, 0xE5, 0xE6, 0xE7):
            _ = cpu.fetch_byte()  # consume port
        if opcode in (0xE4, 0xEC):
            regs.al = 0xFF
        elif opcode in (0xE5, 0xED):
            regs.ax = 0xFFFF
        return CYCLE_MAP["default"]

    # CALL near disp16 (E8)
    if opcode == 0xE8:
        disp16 = cpu.fetch_signed_word()
        cpu.push_word(regs.ip)
        regs.ip = (regs.ip + disp16) & 0xFFFF
        return CYCLE_MAP["call_near"]

    # JMP near disp16 (E9)
    if opcode == 0xE9:
        disp16 = cpu.fetch_signed_word()
        regs.ip = (regs.ip + disp16) & 0xFFFF
        return CYCLE_MAP["jmp_direct"]

    # JMP far ptr16:16 (EA)
    if opcode == 0xEA:
        new_ip = cpu.fetch_word()
        new_cs = cpu.fetch_word()
        regs.ip = new_ip
        regs.cs = new_cs
        return CYCLE_MAP["jmp_direct"]

    # JMP short disp8 (EB)
    if opcode == 0xEB:
        disp8 = cpu.fetch_signed_byte()
        regs.ip = (regs.ip + disp8) & 0xFFFF
        return CYCLE_MAP["jmp_direct"]

    # Processor control: HLT (F4), CMC (F5), CLC (F8), STC (F9), CLI (FA), STI (FB), CLD (FC), STD (FD)
    if opcode == 0xF4:
        cpu.halted = True
        return CYCLE_MAP["default"]
    if opcode == 0xF5:
        flags.cf = 1 if flags.cf == 0 else 0
        return CYCLE_MAP["default"]
    if opcode == 0xF8:
        flags.cf = 0
        return CYCLE_MAP["default"]
    if opcode == 0xF9:
        flags.cf = 1
        return CYCLE_MAP["default"]
    if opcode == 0xFA:
        flags.if_ = 0
        return CYCLE_MAP["default"]
    if opcode == 0xFB:
        flags.if_ = 1
        return CYCLE_MAP["default"]
    if opcode == 0xFC:
        flags.df = 0
        return CYCLE_MAP["default"]
    if opcode == 0xFD:
        flags.df = 1
        return CYCLE_MAP["default"]

    # Grp3: F6, F7 (TEST, NOT, NEG, MUL, IMUL, DIV, IDIV)
    if opcode in (0xF6, 0xF7):
        is_word = opcode & 1
        is_reg, grp_op, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        if not is_word:
            val = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            match grp_op:
                case 0 | 1:  # TEST imm8
                    imm8 = cpu.fetch_byte()
                    flags.update_logic((val & imm8) & 0xFF, width=8)
                case 2:  # NOT
                    res = (~val) & 0xFF
                    write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
                case 3:  # NEG
                    res = (0 - val) & 0xFF
                    flags.update_neg(val, res, width=8)
                    write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
                case 4:  # MUL rm8 (AX = AL * rm8)
                    prod = regs.al * val
                    regs.ax = prod & 0xFFFF
                    cf_of = 1 if (regs.ah != 0) else 0
                    flags.cf = cf_of
                    flags.of = cf_of
                case 5:  # IMUL rm8 (AX = AL * rm8 signed)
                    s_al = (regs.al - 256) if (regs.al & 0x80) else regs.al
                    s_val = (val - 256) if (val & 0x80) else val
                    prod = s_al * s_val
                    regs.ax = prod & 0xFFFF
                    # CF/OF set if high half is not sign extension of low half
                    is_sign_ext = (regs.ah == 0x00 and (regs.al & 0x80) == 0) or (regs.ah == 0xFF and (regs.al & 0x80) != 0)
                    cf_of = 0 if is_sign_ext else 1
                    flags.cf = cf_of
                    flags.of = cf_of
                case 6:  # DIV rm8
                    if val == 0:
                        cpu.interrupts.handle_interrupt(0)
                    else:
                        quot = regs.ax // val
                        rem = regs.ax % val
                        if quot > 255:
                            cpu.interrupts.handle_interrupt(0)
                        else:
                            regs.al = quot & 0xFF
                            regs.ah = rem & 0xFF
                case 7:  # IDIV rm8
                    s_val = (val - 256) if (val & 0x80) else val
                    if s_val == 0:
                        cpu.interrupts.handle_interrupt(0)
                    else:
                        s_ax = (regs.ax - 65536) if (regs.ax & 0x8000) else regs.ax
                        quot = int(s_ax / s_val)
                        rem = s_ax % s_val
                        if quot < -128 or quot > 127:
                            cpu.interrupts.handle_interrupt(0)
                        else:
                            regs.al = quot & 0xFF
                            regs.ah = rem & 0xFF
            return CYCLE_MAP["alu_rr"] if is_reg else CYCLE_MAP["alu_rm"]
        else:
            val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
            match grp_op:
                case 0 | 1:  # TEST imm16
                    imm16 = cpu.fetch_word()
                    flags.update_logic((val & imm16) & 0xFFFF, width=16)
                case 2:  # NOT
                    res = (~val) & 0xFFFF
                    write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
                case 3:  # NEG
                    res = (0 - val) & 0xFFFF
                    flags.update_neg(val, res, width=16)
                    write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
                case 4:  # MUL rm16 (DX:AX = AX * rm16)
                    prod = regs.ax * val
                    regs.ax = prod & 0xFFFF
                    regs.dx = (prod >> 16) & 0xFFFF
                    cf_of = 1 if (regs.dx != 0) else 0
                    flags.cf = cf_of
                    flags.of = cf_of
                case 5:  # IMUL rm16
                    s_ax = (regs.ax - 65536) if (regs.ax & 0x8000) else regs.ax
                    s_val = (val - 65536) if (val & 0x8000) else val
                    prod = s_ax * s_val
                    regs.ax = prod & 0xFFFF
                    regs.dx = (prod >> 16) & 0xFFFF
                    is_sign_ext = (regs.dx == 0x0000 and (regs.ax & 0x8000) == 0) or (regs.dx == 0xFFFF and (regs.ax & 0x8000) != 0)
                    cf_of = 0 if is_sign_ext else 1
                    flags.cf = cf_of
                    flags.of = cf_of
                case 6:  # DIV rm16 (DX:AX / rm16)
                    if val == 0:
                        cpu.interrupts.handle_interrupt(0)
                    else:
                        dividend = (regs.dx << 16) | regs.ax
                        quot = dividend // val
                        rem = dividend % val
                        if quot > 65535:
                            cpu.interrupts.handle_interrupt(0)
                        else:
                            regs.ax = quot & 0xFFFF
                            regs.dx = rem & 0xFFFF
                case 7:  # IDIV rm16
                    s_val = (val - 65536) if (val & 0x8000) else val
                    if s_val == 0:
                        cpu.interrupts.handle_interrupt(0)
                    else:
                        dividend = (regs.dx << 16) | regs.ax
                        if dividend & 0x80000000:
                            dividend -= 0x100000000
                        quot = int(dividend / s_val)
                        rem = dividend % s_val
                        if quot < -32768 or quot > 32767:
                            cpu.interrupts.handle_interrupt(0)
                        else:
                            regs.ax = quot & 0xFFFF
                            regs.dx = rem & 0xFFFF
            return CYCLE_MAP["alu_rr"] if is_reg else CYCLE_MAP["alu_rm"]

    # Grp4: FE (INC rm8, DEC rm8)
    if opcode == 0xFE:
        is_reg, grp_op, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        val = read_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset)
        if grp_op == 0:  # INC
            res = (val + 1) & 0xFF
            flags.update_inc(val, res, width=8)
            write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
            return CYCLE_MAP["inc_r"] if is_reg else CYCLE_MAP["inc_m"]
        elif grp_op == 1:  # DEC
            res = (val - 1) & 0xFF
            flags.update_dec(val, res, width=8)
            write_operand8(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
            return CYCLE_MAP["dec_r"] if is_reg else CYCLE_MAP["dec_m"]
        else:
            raise NotImplementedError(f"Unsupported Grp4 subcode: {grp_op}")

    # Grp5: FF (INC, DEC, CALL near ind, CALL far ind, JMP near ind, JMP far ind, PUSH rm16)
    if opcode == 0xFF:
        is_reg, grp_op, rm_idx, ea_seg, ea_offset = decode_modrm(cpu, seg_override)
        match grp_op:
            case 0:  # INC rm16
                val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
                res = (val + 1) & 0xFFFF
                flags.update_inc(val, res, width=16)
                write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
                return CYCLE_MAP["inc_r"] if is_reg else CYCLE_MAP["inc_m"]
            case 1:  # DEC rm16
                val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
                res = (val - 1) & 0xFFFF
                flags.update_dec(val, res, width=16)
                write_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset, res)
                return CYCLE_MAP["dec_r"] if is_reg else CYCLE_MAP["dec_m"]
            case 2:  # CALL near indirect
                target_ip = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
                cpu.push_word(regs.ip)
                regs.ip = target_ip
                return CYCLE_MAP["call_near"]
            case 3:  # CALL far indirect
                target_ip = mem.read_word(ea_seg, ea_offset)
                target_cs = mem.read_word(ea_seg, (ea_offset + 2) & 0xFFFF)
                cpu.push_word(regs.cs)
                cpu.push_word(regs.ip)
                regs.cs = target_cs
                regs.ip = target_ip
                return CYCLE_MAP["call_near"] + 10
            case 4:  # JMP near indirect
                target_ip = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
                regs.ip = target_ip
                return CYCLE_MAP["jmp_direct"]
            case 5:  # JMP far indirect
                target_ip = mem.read_word(ea_seg, ea_offset)
                target_cs = mem.read_word(ea_seg, (ea_offset + 2) & 0xFFFF)
                regs.cs = target_cs
                regs.ip = target_ip
                return CYCLE_MAP["jmp_direct"] + 10
            case 6:  # PUSH rm16
                val = read_operand16(cpu, is_reg, rm_idx, ea_seg, ea_offset)
                cpu.push_word(val)
                return CYCLE_MAP["push_r"] if is_reg else CYCLE_MAP["push_m"]
            case _:
                raise NotImplementedError(f"Unsupported Grp5 subcode: {grp_op}")

    raise NotImplementedError(f"Opcode 0x{opcode:02X} at {regs.cs:04X}:{(regs.ip - 1) & 0xFFFF:04X} not implemented")
