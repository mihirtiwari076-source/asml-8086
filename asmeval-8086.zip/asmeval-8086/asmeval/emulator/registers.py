"""
Register file implementation for the Intel 8086 processor.
Includes 16-bit general registers with 8-bit views, pointer/index registers,
segment registers, and instruction pointer.
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any


class Registers:
    """
    Simulates the 8086 register state with proper 8-bit / 16-bit mappings.
    """

    __slots__ = (
        "_ax", "_bx", "_cx", "_dx",
        "_sp", "_bp", "_si", "_di",
        "_ip",
        "_cs", "_ds", "_ss", "_es"
    )

    def __init__(self):
        self.reset()

    def reset(self) -> None:
        self._ax = 0
        self._bx = 0
        self._cx = 0
        self._dx = 0
        self._sp = 0xFFFE
        self._bp = 0
        self._si = 0
        self._di = 0
        self._ip = 0x0100
        self._cs = 0x1000
        self._ds = 0x1000
        self._ss = 0x1000
        self._es = 0x1000

    # 16-bit General Registers
    @property
    def ax(self) -> int:
        return self._ax

    @ax.setter
    def ax(self, val: int) -> None:
        self._ax = val & 0xFFFF

    @property
    def bx(self) -> int:
        return self._bx

    @bx.setter
    def bx(self, val: int) -> None:
        self._bx = val & 0xFFFF

    @property
    def cx(self) -> int:
        return self._cx

    @cx.setter
    def cx(self, val: int) -> None:
        self._cx = val & 0xFFFF

    @property
    def dx(self) -> int:
        return self._dx

    @dx.setter
    def dx(self, val: int) -> None:
        self._dx = val & 0xFFFF

    # 8-bit Low/High Register Views
    @property
    def al(self) -> int:
        return self._ax & 0xFF

    @al.setter
    def al(self, val: int) -> None:
        self._ax = (self._ax & 0xFF00) | (val & 0xFF)

    @property
    def ah(self) -> int:
        return (self._ax >> 8) & 0xFF

    @ah.setter
    def ah(self, val: int) -> None:
        self._ax = (self._ax & 0x00FF) | ((val & 0xFF) << 8)

    @property
    def bl(self) -> int:
        return self._bx & 0xFF

    @bl.setter
    def bl(self, val: int) -> None:
        self._bx = (self._bx & 0xFF00) | (val & 0xFF)

    @property
    def bh(self) -> int:
        return (self._bx >> 8) & 0xFF

    @bh.setter
    def bh(self, val: int) -> None:
        self._bx = (self._bx & 0x00FF) | ((val & 0xFF) << 8)

    @property
    def cl(self) -> int:
        return self._cx & 0xFF

    @cl.setter
    def cl(self, val: int) -> None:
        self._cx = (self._cx & 0xFF00) | (val & 0xFF)

    @property
    def ch(self) -> int:
        return (self._cx >> 8) & 0xFF

    @ch.setter
    def ch(self, val: int) -> None:
        self._cx = (self._cx & 0x00FF) | ((val & 0xFF) << 8)

    @property
    def dl(self) -> int:
        return self._dx & 0xFF

    @dl.setter
    def dl(self, val: int) -> None:
        self._dx = (self._dx & 0xFF00) | (val & 0xFF)

    @property
    def dh(self) -> int:
        return (self._dx >> 8) & 0xFF

    @dh.setter
    def dh(self, val: int) -> None:
        self._dx = (self._dx & 0x00FF) | ((val & 0xFF) << 8)

    # Pointer & Index Registers
    @property
    def sp(self) -> int:
        return self._sp

    @sp.setter
    def sp(self, val: int) -> None:
        self._sp = val & 0xFFFF

    @property
    def bp(self) -> int:
        return self._bp

    @bp.setter
    def bp(self, val: int) -> None:
        self._bp = val & 0xFFFF

    @property
    def si(self) -> int:
        return self._si

    @si.setter
    def si(self, val: int) -> None:
        self._si = val & 0xFFFF

    @property
    def di(self) -> int:
        return self._di

    @di.setter
    def di(self, val: int) -> None:
        self._di = val & 0xFFFF

    @property
    def ip(self) -> int:
        return self._ip

    @ip.setter
    def ip(self, val: int) -> None:
        self._ip = val & 0xFFFF

    # Segment Registers
    @property
    def cs(self) -> int:
        return self._cs

    @cs.setter
    def cs(self, val: int) -> None:
        self._cs = val & 0xFFFF

    @property
    def ds(self) -> int:
        return self._ds

    @ds.setter
    def ds(self, val: int) -> None:
        self._ds = val & 0xFFFF

    @property
    def ss(self) -> int:
        return self._ss

    @ss.setter
    def ss(self, val: int) -> None:
        self._ss = val & 0xFFFF

    @property
    def es(self) -> int:
        return self._es

    @es.setter
    def es(self, val: int) -> None:
        self._es = val & 0xFFFF

    # Dynamic Access by Name
    def get(self, name: str) -> int:
        reg_name = name.lower()
        if hasattr(self, reg_name):
            return getattr(self, reg_name)
        raise KeyError(f"Unknown register name: {name}")

    def set(self, name: str, value: int) -> None:
        reg_name = name.lower()
        if hasattr(self, reg_name):
            setattr(self, reg_name, value)
        else:
            raise KeyError(f"Unknown register name: {name}")

    # Indexed 16-bit register access for ModR/M reg field
    def get_reg16(self, idx: int) -> int:
        # 0: AX, 1: CX, 2: DX, 3: BX, 4: SP, 5: BP, 6: SI, 7: DI
        match idx & 7:
            case 0: return self._ax
            case 1: return self._cx
            case 2: return self._dx
            case 3: return self._bx
            case 4: return self._sp
            case 5: return self._bp
            case 6: return self._si
            case 7: return self._di

    def set_reg16(self, idx: int, val: int) -> None:
        val &= 0xFFFF
        match idx & 7:
            case 0: self._ax = val
            case 1: self._cx = val
            case 2: self._dx = val
            case 3: self._bx = val
            case 4: self._sp = val
            case 5: self._bp = val
            case 6: self._si = val
            case 7: self._di = val

    # Indexed 8-bit register access for ModR/M reg field
    def get_reg8(self, idx: int) -> int:
        # 0: AL, 1: CL, 2: DL, 3: BL, 4: AH, 5: CH, 6: DH, 7: BH
        match idx & 7:
            case 0: return self.al
            case 1: return self.cl
            case 2: return self.dl
            case 3: return self.bl
            case 4: return self.ah
            case 5: return self.ch
            case 6: return self.dh
            case 7: return self.bh

    def set_reg8(self, idx: int, val: int) -> None:
        val &= 0xFF
        match idx & 7:
            case 0: self.al = val
            case 1: self.cl = val
            case 2: self.dl = val
            case 3: self.bl = val
            case 4: self.ah = val
            case 5: self.ch = val
            case 6: self.dh = val
            case 7: self.bh = val

    # Segment register access (2-bit index)
    def get_sreg(self, idx: int) -> int:
        # 0: ES, 1: CS, 2: SS, 3: DS
        match idx & 3:
            case 0: return self._es
            case 1: return self._cs
            case 2: return self._ss
            case 3: return self._ds

    def set_sreg(self, idx: int, val: int) -> None:
        val &= 0xFFFF
        match idx & 3:
            case 0: self._es = val
            case 1: self._cs = val
            case 2: self._ss = val
            case 3: self._ds = val

    def to_dict(self) -> Dict[str, str]:
        return {
            "AX": f"0x{self._ax:04X}",
            "BX": f"0x{self._bx:04X}",
            "CX": f"0x{self._cx:04X}",
            "DX": f"0x{self._dx:04X}",
            "SP": f"0x{self._sp:04X}",
            "BP": f"0x{self._bp:04X}",
            "SI": f"0x{self._si:04X}",
            "DI": f"0x{self._di:04X}",
            "IP": f"0x{self._ip:04X}",
            "CS": f"0x{self._cs:04X}",
            "DS": f"0x{self._ds:04X}",
            "SS": f"0x{self._ss:04X}",
            "ES": f"0x{self._es:04X}",
        }

    def copy(self) -> Registers:
        r = Registers()
        r._ax = self._ax
        r._bx = self._bx
        r._cx = self._cx
        r._dx = self._dx
        r._sp = self._sp
        r._bp = self._bp
        r._si = self._si
        r._di = self._di
        r._ip = self._ip
        r._cs = self._cs
        r._ds = self._ds
        r._ss = self._ss
        r._es = self._es
        return r
