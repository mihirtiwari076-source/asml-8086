"""
Interrupt handling and DOS/BIOS emulation stubs for the 8086 processor.
Supports INT 20h, INT 21h (4Ch, 02h, 09h, 01h, 06h, 25h, 35h, 30h), and IVT dispatch.
"""

from __future__ import annotations
from typing import TYPE_CHECKING, Callable, Dict, Optional, Tuple

if TYPE_CHECKING:
    from .cpu import CPU


class InterruptHandler:
    """
    Handles hardware and software interrupts, including DOS API emulation.
    """

    def __init__(self, cpu: CPU):
        self.cpu = cpu
        self.stdout_buffer: list[str] = []
        self.stdin_buffer: str = ""
        self.stdin_idx: int = 0
        self.exit_code: Optional[int] = None
        self.custom_hooks: Dict[int, Callable[[CPU], bool]] = {}

    def reset(self) -> None:
        self.stdout_buffer.clear()
        self.stdin_buffer = ""
        self.stdin_idx = 0
        self.exit_code = None

    def register_hook(self, vector: int, callback: Callable[[CPU], bool]) -> None:
        """Registers a custom Python handler for interrupt vector. Return True if handled."""
        self.custom_hooks[vector] = callback

    def get_stdout(self) -> str:
        return "".join(self.stdout_buffer)

    def set_stdin(self, text: str) -> None:
        self.stdin_buffer = text
        self.stdin_idx = 0

    def handle_interrupt(self, vector: int) -> bool:
        """
        Executes interrupt. Returns True if execution should continue,
        or False if CPU should halt (e.g. exit 4Ch).
        """
        # Check custom hooks
        if vector in self.custom_hooks:
            handled = self.custom_hooks[vector](self.cpu)
            if handled:
                return not self.cpu.halted

        # INT 20h: DOS Program Terminate
        if vector == 0x20:
            self.exit_code = 0
            self.cpu.halted = True
            return False

        # INT 21h: DOS Function Calls
        if vector == 0x21:
            return self._handle_int21()

        # INT 10h: BIOS Video Services (Basic support)
        if vector == 0x10:
            ah = self.cpu.registers.ah
            if ah == 0x0E:  # Teletype output
                ch = chr(self.cpu.registers.al)
                self.stdout_buffer.append(ch)
            return True

        # INT 03h: Breakpoint
        if vector == 0x03:
            # By default do not halt unless hooked
            return True

        # Fallback: Real Mode IVT (Interrupt Vector Table at 0000:0000 - 0000:03FF)
        # Push FLAGS, CS, IP, and jump to vector
        self._dispatch_ivt(vector)
        return True

    def _handle_int21(self) -> bool:
        ah = self.cpu.registers.ah

        if ah == 0x4C:
            # Terminate process with exit code in AL
            self.exit_code = self.cpu.registers.al
            self.cpu.halted = True
            return False

        elif ah == 0x02:
            # Display character in DL
            char_code = self.cpu.registers.dl
            self.stdout_buffer.append(chr(char_code))
            self.cpu.registers.al = char_code  # Returns last char in AL
            return True

        elif ah == 0x09:
            # Display $-terminated string at DS:DX
            ds = self.cpu.registers.ds
            dx = self.cpu.registers.dx
            offset = dx
            # Read until '$' (0x24) or maximum 64KB guard
            for _ in range(65536):
                b = self.cpu.memory.read_byte(ds, offset)
                if b == 0x24:  # '$'
                    break
                self.stdout_buffer.append(chr(b))
                offset = (offset + 1) & 0xFFFF
            self.cpu.registers.al = 0x24
            return True

        elif ah == 0x01:
            # Read character with echo
            if self.stdin_idx < len(self.stdin_buffer):
                ch = ord(self.stdin_buffer[self.stdin_idx])
                self.stdin_idx += 1
            else:
                ch = 0x0D  # Return CR on EOF
            self.cpu.registers.al = ch
            self.stdout_buffer.append(chr(ch))
            return True

        elif ah == 0x06:
            # Direct console I/O
            dl = self.cpu.registers.dl
            if dl == 0xFF:
                # Input
                if self.stdin_idx < len(self.stdin_buffer):
                    ch = ord(self.stdin_buffer[self.stdin_idx])
                    self.stdin_idx += 1
                    self.cpu.flags.zf = 0
                    self.cpu.registers.al = ch
                else:
                    self.cpu.flags.zf = 1
                    self.cpu.registers.al = 0
            else:
                # Output char in DL
                self.stdout_buffer.append(chr(dl))
            return True

        elif ah == 0x25:
            # Set Interrupt Vector: AL = Vector, DS:DX = ISR address
            vec = self.cpu.registers.al
            self.cpu.memory.write_word(0x0000, vec * 4, self.cpu.registers.dx)
            self.cpu.memory.write_word(0x0000, vec * 4 + 2, self.cpu.registers.ds)
            return True

        elif ah == 0x35:
            # Get Interrupt Vector: AL = Vector, returns ES:BX = ISR address
            vec = self.cpu.registers.al
            ip_val = self.cpu.memory.read_word(0x0000, vec * 4)
            cs_val = self.cpu.memory.read_word(0x0000, vec * 4 + 2)
            self.cpu.registers.bx = ip_val
            self.cpu.registers.es = cs_val
            return True

        elif ah == 0x30:
            # Get DOS Version -> Return 5.00
            self.cpu.registers.al = 5
            self.cpu.registers.ah = 0
            self.cpu.registers.bx = 0
            self.cpu.registers.cx = 0
            return True

        elif ah == 0x2A:
            # Get System Date -> Return 2026-11-08 (CX=2026, DH=11, DL=8, AL=day-of-week)
            self.cpu.registers.cx = 2026
            self.cpu.registers.dh = 11
            self.cpu.registers.dl = 8
            self.cpu.registers.al = 0  # Sunday
            return True

        elif ah == 0x2C:
            # Get System Time -> 12:00:00.00
            self.cpu.registers.ch = 12
            self.cpu.registers.cl = 0
            self.cpu.registers.dh = 0
            self.cpu.registers.dl = 0
            return True

        # Unimplemented DOS subfunctions
        return True

    def _dispatch_ivt(self, vector: int) -> None:
        """Dispatches through IVT table in Real Mode memory."""
        # Push FLAGS
        self.cpu.push_word(self.cpu.flags.pack())
        # Push CS, IP
        self.cpu.push_word(self.cpu.registers.cs)
        self.cpu.push_word(self.cpu.registers.ip)
        # Clear IF and TF
        self.cpu.flags.if_ = 0
        self.cpu.flags.tf = 0
        # Load new IP and CS from IVT table at 0000:(vector*4)
        new_ip = self.cpu.memory.read_word(0x0000, vector * 4)
        new_cs = self.cpu.memory.read_word(0x0000, vector * 4 + 2)
        self.cpu.registers.ip = new_ip
        self.cpu.registers.cs = new_cs
