"""
asmeval-8086 Standardized Reward Function for Reinforcement Learning Agents.
Computes a normalized reward scalar in range [0.0, 1.0].
"""

from typing import Dict, Any


def compute_agent_reward(eval_result: Dict[str, Any], task_spec: Dict[str, Any]) -> float:
    """
    Compute a normalized scalar reward [0.0, 1.0] for an agent submission.

    Args:
        eval_result: Dictionary reporting evaluation outcome from TaskRunner / EvaluationReport.
                     Expected keys: status, cycles_elapsed, binary_size_bytes.
        task_spec: Dictionary containing task specification and constraints.
                   Expected keys: scoring_weights, cycle_budget, memory_budget_bytes.

    Returns:
        float: Reward scalar between 0.0 and 1.0 (rounded to 4 decimal places).
    """
    # Failure states receive 0.0 reward
    if eval_result.get("status") != "PASSED":
        return 0.0

    weights = task_spec.get("scoring_weights", {
        "correctness": 0.70,
        "cycle_efficiency": 0.20,
        "code_density": 0.10,
    })

    # Correctness is binary: 1.0 if all test vectors pass
    correctness_score = 1.0

    # Cycle efficiency score: penalize if cycles exceed target budget
    actual_cycles = eval_result.get("cycles_elapsed", 0)
    cycle_budget = task_spec.get("cycle_budget", actual_cycles)
    if cycle_budget and actual_cycles > 0:
        if actual_cycles <= cycle_budget:
            efficiency_score = 1.0
        else:
            # Graceful decay down to minimum 0.1
            efficiency_score = max(0.1, cycle_budget / actual_cycles)
    else:
        efficiency_score = 1.0

    # Code density score: smaller binary size yields higher score
    binary_size = eval_result.get("binary_size_bytes", 0)
    max_bytes = task_spec.get("memory_budget_bytes", binary_size)
    if max_bytes and binary_size > 0:
        if binary_size <= max_bytes:
            density_score = 1.0
        else:
            density_score = max(0.1, max_bytes / binary_size)
    else:
        density_score = 1.0

    total_reward = (
        (correctness_score * weights.get("correctness", 0.70)) +
        (efficiency_score * weights.get("cycle_efficiency", 0.20)) +
        (density_score * weights.get("code_density", 0.10))
    )

    return round(float(total_reward), 4)
