# asmeval-8086: Deterministic Headless 8086 Assembly Verification Harness & RL Benchmark Suite

[![Python: 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Architecture: Intel 8086 Real Mode](https://img.shields.io/badge/architecture-i8086%20Real%20Mode-red.svg)](#)
[![Format: DataVendor.ai Asset](https://img.shields.io/badge/asset%20format-DataVendor.ai%20v2.0-green.svg)](#)
[![Benchmarks: 50/50 Passed](https://img.shields.io/badge/benchmarks-50%2F50%20(100%25)-brightgreen.svg)](#)

A deterministic, zero-dependency, headless Intel 8086 processor simulator, execution engine, compiler toolchain, and state verification harness. Built specifically for evaluating frontier Large Language Models (LLMs) and autonomous software agents on low-level systems programming in real-mode x86 assembly.

---

## 1. Architectural Overview

```
+===================================================================================================================+
|                                  AGENT SUBMISSION OR BENCHMARK HARNESS RUNNER                                     |
|                                        (Autonomous Agent / Eval Script)                                           |
+=========================================================+=========================================================+
                                                          |
                                                          v
+===================================================================================================================+
|                                              STAGE 1: INGESTION & AUDIT                                           |
|  - CLI / Harness Ingestion (asmeval/cli.py, asmeval/harness/runner.py)                                            |
|  - Schema Validation via JSONSchema against v2 Task Specifications                                                |
|  - Pre-execution Static Analysis: Disallow 32/64-bit mnemonics (EAX, R8, etc.), enforce pure 16-bit Real Mode      |
+=========================================================+=========================================================+
                                                          |
                                                          v
+===================================================================================================================+
|                                        STAGE 2: ISOLATED ASSEMBLY TOOLCHAIN                                       |
|                                            (asmeval/compiler/assembler.py)                                        |
|  +----------------------------+     +-----------------------------+     +---------------------------------------+ |
|  | Input: Candidate ASM Source| --> | NASM Worker Subprocess      | --> | Artifact Extractor:                   | |
|  | + Task Scaffolding Wrapper |     | (Flags: -f bin -O0 -w+all)  |     | - Flat Binary (.COM / .BIN)           | |
|  +----------------------------+     +-----------------------------+     | - Symbol / Listing Map (.LST)         | |
|                                                                         +---------------------------------------+ |
|                                                                                             |                     |
|                                                  [On Syntax / Assembly Error]               v                     |
|                                                  ---------------------------> +---------------------------------+ |
|                                                                               | Error Categorization Engine     | |
|                                                                               | (asmeval/compiler/error_parser) | |
|                                                                               +---------------------------------+ |
+=========================================================+=========================================================+
                                                          | (Verified Executable Binary)
                                                          v
+===================================================================================================================+
|                                    STAGE 3: HARMONIZED 8086 EXECUTION CORE                                        |
|                                          (asmeval/emulator/cpu.py)                                                |
|  +-------------------------------------------------------------------------------------------------------------+  |
|  | REAL-MODE 1MB MEMORY SUBSYSTEM (asmeval/emulator/memory.py)                                                 |  |
|  | - 1,048,576 Byte Flat Linear Array [00000h - FFFFFh]                                                        |  |
|  | - Segment Math Engine: Physical Addr = ((Segment * 16) + Offset) & 0xFFFFF                                   |  |
|  | - Strict 64KB Segment Wraparound Enforcement for SP/IP & Pointer Arithmetic                                 |  |
|  | - Hardware Mappings: IVT (0000h-03FFh), BDA (0400h-04FFh), Execution Buffer (1000h:0100h)                     |  |
|  +-------------------------------------------------------------------------------------------------------------+  |
|  | REGISTER BANK & FLAG UNIT (asmeval/emulator/registers.py, asmeval/emulator/flags.py)                         |  |
|  | - Word/Byte Synchronized: AX(AH/AL), BX(BH/BL), CX(CH/CL), DX(DH/DL)                                        |  |
|  | - Index & Pointer: SP, BP, SI, DI, IP                                                                       |  |
|  | - Segments: CS, DS, SS, ES                                                                                  |  |
|  | - Fully Verified FLAGS Logic: CF, PF (low 8-bit), AF (nibble BCD), ZF, SF, OF (2's comp), DF, IF, TF           |  |
|  +-------------------------------------------------------------------------------------------------------------+  |
|  | STEPPER, INSTRUCTION DECODER & HARDWARE HOOKS (asmeval/emulator/instructions.py)                          |  |
|  | - Cycle-Accurate Execution Stepper with Exact Penalty Modeling                                              |  |
|  | - String Ops Pipeline: MOVS, LODS, STOS, CMPS, SCAS with REP/REPE/REPNE + DF Increment/Decrement             |  |
|  | - DOS Interrupt Emulation Trap: INT 20h (Exit), INT 21h (AH=02h, 09h, 4Ch, 01h, 08h)                        |  |
|  | - Circuit Breakers: Max Cycle Guard (Configurable, default 1,000,000 cycles)                                |  |
|  | - Memory Access Violation & Undefined Opcode Traps                                                          |  |
|  +-------------------------------------------------------------------------------------------------------------+  |
+=========================================================+=========================================================+
                                                          |
                                                          v
+===================================================================================================================+
|                                   STAGE 4: VERIFICATION & MULTI-METRIC SCORING                                   |
|                                         (asmeval/verifier/assertion_engine.py)                                    |
|  - State Capture: Final Registers, Flag Bits, Active Memory Windows, Full Instruction Count, Elapsed Cycles      |
|  - Assertion Checking: Equivalence checks against exact task test_cases.json invariants                           |
|  - Memory Range Diffs: Hex-dump visualization & structural array parity verifications                           |
|  - Performance Profiler: Benchmarks cycle efficiency vs. Ground-Truth reference solution                         |
+=========================================================+=========================================================+
                                                          |
                                                          v
+===================================================================================================================+
|                                     STAGE 5: ENTERPRISE DATA ARTIFACT EXPORT                                      |
|                                          (asmeval/verifier/diff_reporter.py)                                      |
|  - Produces RFC-compliant, machine-readable JSON evaluation traces for RL training & DataVendor packaging        |
|  - Direct export formats: Human-readable markdown reports, JSONL event streams, or reward signals (0.0 to 1.0)   |
+===================================================================================================================+
```

---

## 2. Key Capabilities & Silicon Accuracy

1. **Deterministic 16-Bit Real-Mode CPU Simulator:**
   - 100% pure Python 3.10+ standard library execution.
   - Exact 20-bit segmentation: `((Segment << 4) + Offset) & 0xFFFFF` with 64KB segment boundary wrapping and 1MB A20 wrap.
   - Complete 8086 register bank with dual-view 8-bit/16-bit mappings (`AX`/`AH`/`AL`, etc.).
   - Silicon-accurate flag mechanics:
     - `PF` evaluates parity over the lowest 8 bits exclusively.
     - `AF` accurately tracks nibble carries and borrows across addition and subtraction.
     - `OF` detects two's-complement signed overflow.
     - `INC` and `DEC` strictly preserve `CF`.
     - BCD arithmetic instructions (`DAA`, `DAS`, `AAA`, `AAS`) match Intel 8086 specifications.
     - String operations (`MOVSB`, `LODSB`, `STOSB`, `CMPSB`, `SCASB`) support Direction Flag (`DF`) forward and backward stepping.
     - Arithmetic bit shifts (`SAR`) preserve sign while logical shifts (`SHR`) inject zero.

2. **Automated NASM Toolchain Wrapper:**
   - Headless invocation of `nasm -f bin -O0`.
   - Automatic binary path discovery across Linux, macOS, and Windows.
   - Structured error diagnostic parser categorizing compiler diagnostics (syntax errors, invalid operand combinations, undefined symbols, out-of-range jumps).

3. **Built-In DOS API & BIOS Hooks:**
   - `INT 20h` (Process terminate).
   - `INT 21h` (Functions `4Ch` exit code, `02h` character output, `09h` `$`-string print, `01h` input, `2Ah`/`2Ch` system clock).
   - Interrupt Vector Table (IVT) dispatch at `0000:0000` - `0000:03FF`.

4. **Institutional DataVendor.ai Benchmark Corpus:**
   - **50 curated ground-truth tasks** spanning 6 foundational categories.
   - Parameterized test vectors for edge cases, null strings, array reversals, and boundary wraps.
   - Standardized JSON schema output for reinforcement learning (RL) training loops and automated leaderboards.

---

## 3. Directory Layout

```
asmeval-8086/
├── datavendor_manifest.json          # Marketplace metadata, licensing, and asset description
├── benchmark_schema.json             # Formal draft-07 JSONSchema validating task specifications
├── Dockerfile                        # Containerized OCI execution environment
├── README.md                         # Comprehensive system documentation
├── pyproject.toml                    # Python package metadata & scripts
├── requirements.txt                  # Development dependencies
├── Makefile                          # Build, test, and benchmark shortcuts
├── asmeval/                          # Core Python engine
│   ├── __init__.py
│   ├── cli.py                        # Multi-command CLI entry point
│   ├── compiler/
│   │   ├── __init__.py
│   │   ├── assembler.py              # Subprocess NASM runner
│   │   └── error_parser.py           # Structured diagnostic parser
│   ├── emulator/
│   │   ├── __init__.py
│   │   ├── cpu.py                    # Instruction stepper & trace recorder
│   │   ├── memory.py                 # 1MB Real-Mode flat address space
│   │   ├── registers.py              # 16-bit / 8-bit register bank
│   │   ├── flags.py                  # Precise flag calculation
│   │   ├── instructions.py           # Full 8086 instruction decoder
│   │   └── interrupts.py             # DOS & BIOS interrupt handling
│   ├── verifier/
│   │   ├── __init__.py
│   │   ├── assertion_engine.py       # State validator against rubric
│   │   └── diff_reporter.py          # Structured JSON & CLI diff generator
│   └── harness/
│       ├── __init__.py
│       ├── task_loader.py            # Benchmark task & test case loader
│       └── runner.py                 # Automated candidate evaluator
├── exports/                          # DataVendor & RL Deliverables
│   ├── asmeval_8086_tasks_v2.jsonl   # Consolidated 50-task dataset for LLM training/eval
│   └── rewards_contract.py           # Standardized RL reward function [0.0, 1.0]
├── tasks/                            # 50 Ground-Truth Benchmark Tasks
│   ├── category_01_arithmetic_and_bcd/      # Tasks 01 - 08
│   ├── category_02_memory_and_strings/      # Tasks 09 - 18
│   ├── category_03_data_structures_sorting/ # Tasks 19 - 26
│   ├── category_04_crypto_hashing_math/     # Tasks 27 - 34
│   ├── category_05_bit_manipulation_codecs/ # Tasks 35 - 42
│   └── category_06_low_level_systems_dos/   # Tasks 43 - 50
└── tests/                            # 46 Comprehensive Unit & Integration Tests
    ├── test_assembler.py
    ├── test_cpu_core.py
    ├── test_flags_silicon_accuracy.py
    ├── test_instruction_fidelity.py
    ├── test_memory_segmentation.py
    ├── test_rewards_contract.py
    ├── test_verifier.py
    └── test_end_to_end_benchmarks.py
```

---

## 4. Quickstart & Installation

### Option A: Local Installation

**Prerequisites:**
- Python 3.10 or higher
- NASM assembler (`nasm`)

```bash
# Clone the repository
git clone https://github.com/datavendor-ai/asmeval-8086.git
cd asmeval-8086

# Install the package locally in editable mode
pip install -e .
```

### Option B: Docker Container

```bash
# Build the Docker image
docker build -t asmeval-8086 .

# Run the benchmark suite inside Docker
docker run --rm asmeval-8086 benchmark --tasks-dir tasks/
```

---

## 5. CLI Usage Guide

The `asmeval` CLI provides 4 main commands:

### 1. Assemble Assembly Source
```bash
# Assemble code into a flat 16-bit binary
asmeval assemble program.asm -o program.com

# Emit assembly diagnostic status as JSON
asmeval assemble program.asm --json
```

### 2. Headless Binary Execution
```bash
# Execute a binary headlessly with a cycle cap
asmeval run program.com --max-cycles 50000

# Export execution traces and registers as JSON
asmeval run program.com --json
```

### 3. Evaluate a Single Task
```bash
# Test candidate code against a benchmark task directory
asmeval test --task-dir tasks/category_01_arithmetic_and_bcd/01_bcd_multibyte_addition --submission solution.asm

# Output full structured evaluation report as JSON
asmeval test --task-dir tasks/category_02_memory_and_strings/09_inplace_string_reverse --json
```

### 4. Run the Full Benchmark Suite
```bash
# Run all 50 benchmark tasks with visual summaries
asmeval benchmark --tasks-dir tasks/

# Run against a directory of agent submissions with JSON output
asmeval benchmark --tasks-dir tasks/ --submission-dir ./submissions/ --json
```

---

## 6. 50-Task Benchmark Corpus Overview

The benchmark suite is partitioned into 6 domain-specific categories:

| Category | Task Range | Core Focus Areas | Key Instructions & Concepts |
| :--- | :--- | :--- | :--- |
| **Category 1: Arithmetic & BCD** | Tasks 01–08 | Multi-byte BCD, signed division, 64-bit math, Horner polynomial | `DAA`, `DAS`, `AAA`, `AAS`, `ADC`, `SBB`, `IDIV`, `IMUL` |
| **Category 2: Memory & Strings** | Tasks 09–18 | String reversal, overlap-safe memmove, tokenization, Levenshtein | `MOVSB`, `LODSB`, `STOSB`, `CMPSB`, `SCASB`, `STD`, `CLD` |
| **Category 3: Data Structures & Sorting** | Tasks 19–26 | Quicksort, binary search, binary heap, linked list, ring buffer, BST | Pointer chasing, stack frames, recursions, binary trees |
| **Category 4: Cryptography & Math** | Tasks 27–34 | CRC-16, CRC-32, MD5 round, LFSR, ChaCha20 quarter-round, integer sqrt | Polynomial division, bit shifts, modular exponentiation, FFT |
| **Category 5: Bit Manipulation & Codecs**| Tasks 35–42 | Base64 encoder/decoder, bit array, Hamming weight, Gray code, Varint | Bit shifts, masks, Huffman decoding, variable-length quantities |
| **Category 6: Low-Level Systems & DOS** | Tasks 43–50 | PSP command-line parser, IVT hook, coroutine switcher, LBA to CHS | `INT 21h`, interrupt vectors, segment arithmetic, UART, relocations |

---

## 7. DataVendor.ai Integration & RL Rewards

### Marketplace Deliverables
- `datavendor_manifest.json`: Asset specifications, domain classification, and OCI container targets.
- `benchmark_schema.json`: Formal draft-07 JSONSchema validating all task definitions.
- `exports/asmeval_8086_tasks_v2.jsonl`: Consolidated 50-task dataset for instruction fine-tuning and evaluation.
- `exports/rewards_contract.py`: Standardized multi-objective reward calculation.

### Reinforcement Learning Reward Contract
Autonomous agents evaluated with `asmeval` receive a normalized scalar reward $R \in [0.0, 1.0]$:

$$R = (w_{\text{correct}} \times S_{\text{correct}}) + (w_{\text{cycles}} \times S_{\text{cycles}}) + (w_{\text{density}} \times S_{\text{density}})$$

```python
from exports.rewards_contract import compute_agent_reward

# Calculate agent reward from execution results
reward = compute_agent_reward(eval_result, task_spec)
```

---

## 8. Verification & Testing

Run the complete test suite:

```bash
# Run all unit tests, silicon flag tests, and end-to-end task validations
pytest -v tests/

# Execute the 50-task benchmark CLI runner
asmeval benchmark --tasks-dir tasks/
```

**Verification Results:**
- 46 unit and integration tests passing.
- 50 / 50 benchmark tasks passing (100.0% pass rate).

---

## 9. License

This project is licensed under the MIT License - see the `LICENSE` file for details.
